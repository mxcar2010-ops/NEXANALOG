import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import type { CelestialBodyId, RegionRecord } from '../shared/types';
import {
  createPlanetaryTextures,
  latLonToVector3,
  vector3ToLatLon,
} from '../three/planetaryTextures';
import { buildRegionalTerrainPatch } from '../three/regionalTerrainPatches';

export interface GlobeHoverCoords {
  lat: number;
  lon: number;
  lonDisplay: string;
}

export interface CameraSphericalState {
  theta: number;
  phi: number;
  radius: number;
}

interface GlobeViewportProps {
  body: CelestialBodyId;
  regions: RegionRecord[];
  selectedRegionId: string | null;
  onSelectRegion?: (regionId: string) => void;
  onHoverCoords?: (coords: GlobeHoverCoords | null) => void;
  focusTarget?: { lat: number; lon: number; distance?: number; key: number } | null;
  zoomCommand?: { delta: number; key: number } | null;
  showBoundary?: boolean;
  showClouds?: boolean;
  showMolaElevation?: boolean;
  showObservationOverlay?: boolean;
  welcomeMode?: boolean;
  enteringSystem?: boolean;
  autoRotate?: boolean;
  syncSpherical?: CameraSphericalState | null;
  onCameraSphericalChange?: (state: CameraSphericalState) => void;
  className?: string;
}

const GLOBE_RADIUS = 1.0;

function detectSoftwareWebGL(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

function createStarfield(): THREE.Points {
  const count = 1600;
  const positions = new Float32Array(count * 3);
  const colors = new Float32Array(count * 3);

  for (let i = 0; i < count; i++) {
    const u = ((i * 7919) % 10000) / 10000;
    const v = ((i * 6271) % 10000) / 10000;
    const theta = 2 * Math.PI * u;
    const phi = Math.acos(2 * v - 1);
    const r = 35 + (i % 25);

    positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
    positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
    positions[i * 3 + 2] = r * Math.cos(phi);

    const tint = 0.72 + ((i * 37) % 28) / 100;
    colors[i * 3] = tint;
    colors[i * 3 + 1] = tint * (i % 5 === 0 ? 0.92 : 0.98);
    colors[i * 3 + 2] = Math.min(1, tint + (i % 3 === 0 ? 0.12 : 0.02));
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

  const material = new THREE.PointsMaterial({
    size: 0.11,
    vertexColors: true,
    transparent: true,
    opacity: 0.85,
    sizeAttenuation: true,
    depthWrite: false,
  });

  return new THREE.Points(geometry, material);
}

function createAtmosphereMesh(body: CelestialBodyId): THREE.Mesh | null {
  if (body === 'moon') return null;

  const rimColor =
    body === 'earth' ? new THREE.Color(0x38bdf8) : new THREE.Color(0xf97316);
  const intensity = body === 'earth' ? 0.52 : 0.34;

  const geometry = new THREE.SphereGeometry(GLOBE_RADIUS * 1.045, 64, 48);
  const material = new THREE.ShaderMaterial({
    uniforms: {
      uColor: { value: rimColor },
      uIntensity: { value: intensity },
    },
    vertexShader: `
      varying vec3 vNormal;
      varying vec3 vViewDir;
      void main() {
        vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
        vNormal = normalize(normalMatrix * normal);
        vViewDir = normalize(-mvPosition.xyz);
        gl_Position = projectionMatrix * mvPosition;
      }
    `,
    fragmentShader: `
      uniform vec3 uColor;
      uniform float uIntensity;
      varying vec3 vNormal;
      varying vec3 vViewDir;
      void main() {
        float fresnel = pow(1.0 - max(0.0, dot(vNormal, vViewDir)), 3.2);
        gl_FragColor = vec4(uColor, fresnel * uIntensity);
      }
    `,
    transparent: true,
    blending: THREE.AdditiveBlending,
    side: THREE.FrontSide,
    depthWrite: false,
  });

  return new THREE.Mesh(geometry, material);
}

function buildRegionMarkerGroup(
  region: RegionRecord,
  isSelected: boolean,
  showBoundary: boolean,
): THREE.Group {
  const group = new THREE.Group();
  group.userData.regionId = region.id;

  const centerVec = latLonToVector3(region.centerLat, region.centerLon, GLOBE_RADIUS * 1.006);

  // Hit target sphere for reliable raycast clicking
  const hitGeo = new THREE.SphereGeometry(0.065, 16, 16);
  const hitMat = new THREE.MeshBasicMaterial({ visible: false });
  const hitMesh = new THREE.Mesh(hitGeo, hitMat);
  hitMesh.position.copy(centerVec);
  hitMesh.userData.regionId = region.id;
  group.add(hitMesh);

  // Beacon core
  const beaconColor = isSelected
    ? 0x22d3ee
    : region.status === 'staged_srtm'
      ? 0xfbbf24
      : region.status === 'staged_lola'
        ? 0xcbd5e1
        : region.body === 'mars'
          ? 0xf59e0b
          : 0x38bdf8;
  const dotGeo = new THREE.SphereGeometry(isSelected ? 0.022 : 0.015, 16, 16);
  const dotMat = new THREE.MeshBasicMaterial({ color: beaconColor });
  const dotMesh = new THREE.Mesh(dotGeo, dotMat);
  dotMesh.position.copy(centerVec);
  dotMesh.userData.regionId = region.id;
  dotMesh.userData.scaleWithAlt = true;
  group.add(dotMesh);

  // Surface ring aligned to sphere normal
  const normal = centerVec.clone().normalize();
  const ringGeo = new THREE.RingGeometry(0.03, 0.039, 32);
  const ringMat = new THREE.MeshBasicMaterial({
    color: beaconColor,
    side: THREE.DoubleSide,
    transparent: true,
    opacity: isSelected ? 0.95 : 0.65,
  });
  const ringMesh = new THREE.Mesh(ringGeo, ringMat);
  ringMesh.position.copy(normal.clone().multiplyScalar(GLOBE_RADIUS * 1.008));
  ringMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal);
  ringMesh.userData.regionId = region.id;
  ringMesh.userData.scaleWithAlt = true;
  group.add(ringMesh);

  // 25 x 25 km exploratory window wireframe footprint (visibly scaled for planetary context)
  if (showBoundary) {
    const halfSpanDeg = region.body === 'mars' ? 1.8 : 1.35;
    const corners: Array<[number, number]> = [
      [region.centerLat - halfSpanDeg, region.centerLon - halfSpanDeg],
      [region.centerLat - halfSpanDeg, region.centerLon + halfSpanDeg],
      [region.centerLat + halfSpanDeg, region.centerLon + halfSpanDeg],
      [region.centerLat + halfSpanDeg, region.centerLon - halfSpanDeg],
      [region.centerLat - halfSpanDeg, region.centerLon - halfSpanDeg],
    ];
    const pts = corners.map(([lat, lon]) =>
      latLonToVector3(lat, lon, GLOBE_RADIUS * 1.011),
    );
    const lineGeo = new THREE.BufferGeometry().setFromPoints(pts);
    const lineMat = new THREE.LineBasicMaterial({
      color: isSelected ? 0x22d3ee : 0xf8fafc,
      transparent: true,
      opacity: isSelected ? 0.95 : 0.72,
    });
    const borderLine = new THREE.Line(lineGeo, lineMat);
    borderLine.userData.isBoundaryLine = true;
    borderLine.userData.baseOpacity = isSelected ? 0.95 : 0.72;
    group.add(borderLine);
  }

  return group;
}

function disposeTerrainPatchesGroup(group: THREE.Group) {
  group.children.forEach((child) => {
    if (child instanceof THREE.Mesh) {
      child.geometry.dispose();
      const mat = child.material as THREE.MeshStandardMaterial;
      mat.map?.dispose();
      mat.dispose();
    }
  });
  group.clear();
}

export function GlobeViewport({
  body,
  regions,
  selectedRegionId,
  onSelectRegion,
  onHoverCoords,
  focusTarget,
  zoomCommand,
  showBoundary = true,
  showClouds = true,
  showMolaElevation = false,
  showObservationOverlay = false,
  welcomeMode = false,
  enteringSystem = false,
  autoRotate = false,
  syncSpherical = null,
  onCameraSphericalChange,
  className = '',
}: GlobeViewportProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [contextLost, setContextLost] = useState(false);

  const onSelectRegionRef = useRef(onSelectRegion);
  const onHoverCoordsRef = useRef(onHoverCoords);
  const onCameraSphericalChangeRef = useRef(onCameraSphericalChange);
  const bodyRef = useRef(body);
  const showCloudsRef = useRef(showClouds);
  const welcomeModeRef = useRef(welcomeMode);
  const enteringSystemRef = useRef(enteringSystem);
  const autoRotateRef = useRef(autoRotate);

  onSelectRegionRef.current = onSelectRegion;
  onHoverCoordsRef.current = onHoverCoords;
  onCameraSphericalChangeRef.current = onCameraSphericalChange;
  bodyRef.current = body;
  showCloudsRef.current = showClouds;
  welcomeModeRef.current = welcomeMode;
  enteringSystemRef.current = enteringSystem;
  autoRotateRef.current = autoRotate;

  // Imperative refs to update planet textures/markers without tearing down WebGL context
  const sceneObjectsRef = useRef<{
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    controls: OrbitControls;
    globeMesh: THREE.Mesh<THREE.SphereGeometry, THREE.MeshStandardMaterial>;
    cloudMesh: THREE.Mesh<THREE.SphereGeometry, THREE.MeshStandardMaterial>;
    atmosphereGroup: THREE.Group;
    terrainPatchesGroup: THREE.Group;
    markersGroup: THREE.Group;
    maxAniso: number;
    flyTarget: THREE.Vector3 | null;
    isSyncApplying: boolean;
  } | null>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareWebGL();
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance',
        alpha: false,
      });
    } catch {
      setContextLost(true);
      return;
    }

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    renderer.setClearColor(0x060911, 1);

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const handleContextLost = (e: Event) => {
      e.preventDefault();
      setContextLost(true);
    };
    const handleContextRestored = () => {
      setContextLost(false);
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);
    renderer.domElement.addEventListener('webglcontextrestored', handleContextRestored);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x060911);

    const camera = new THREE.PerspectiveCamera(40, width / height, 0.002, 120);
    // Start facing Americas/Uyuni on Earth or welcome orbit
    const initPos = latLonToVector3(-14, -62, welcomeMode ? 3.45 : 3.0);
    camera.position.copy(initPos);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.06;
    controls.enablePan = false;
    controls.minDistance = 1.038;
    controls.maxDistance = 5.2;
    controls.rotateSpeed = 0.65;
    controls.zoomSpeed = 0.85;
    controls.enabled = !welcomeMode;

    // Three-point + hemisphere space illumination
    const hemiLight = new THREE.HemisphereLight(0xcbe8ff, 0x101828, 0.72);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfff6ea, 2.15);
    keyLight.position.set(5, 3, 5);
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x38bdf8, 0.65);
    rimLight.position.set(-5, -2, -4);
    scene.add(rimLight);

    // Starfield
    const stars = createStarfield();
    scene.add(stars);

    // Planet sphere (high-segment mesh with albedo, elevation bump & surface roughness)
    const maxAniso = Math.min(8, renderer.capabilities.getMaxAnisotropy());
    const globeGeo = new THREE.SphereGeometry(GLOBE_RADIUS, 128, 96);
    const initialTexSet = createPlanetaryTextures(body, {
      showMolaElevation,
      showObservationOverlay,
    });
    initialTexSet.map.anisotropy = maxAniso;
    initialTexSet.bumpMap.anisotropy = maxAniso;

    const globeMat = new THREE.MeshStandardMaterial({
      map: initialTexSet.map,
      bumpMap: initialTexSet.bumpMap,
      bumpScale: body === 'earth' ? 0.032 : body === 'mars' ? 0.044 : 0.052,
      roughnessMap: initialTexSet.roughnessMap,
      roughness: 1.0,
      metalness: body === 'earth' ? 0.08 : 0.03,
    });
    const globeMesh = new THREE.Mesh(globeGeo, globeMat);
    scene.add(globeMesh);

    // Translucent drifting cloud sphere for Earth
    const cloudGeo = new THREE.SphereGeometry(GLOBE_RADIUS * 1.016, 72, 54);
    const cloudMat = new THREE.MeshStandardMaterial({
      map: initialTexSet.cloudMap ?? null,
      transparent: true,
      opacity: body === 'earth' && showClouds ? 0.68 : 0,
      depthWrite: false,
      roughness: 0.9,
      metalness: 0,
    });
    const cloudMesh = new THREE.Mesh(cloudGeo, cloudMat);
    cloudMesh.visible = body === 'earth' && showClouds && Boolean(initialTexSet.cloudMap);
    scene.add(cloudMesh);

    // Atmosphere, 3D Regional Terrain Patches & Markers groups
    const atmosphereGroup = new THREE.Group();
    const initialAtmos = createAtmosphereMesh(body);
    if (initialAtmos) atmosphereGroup.add(initialAtmos);
    scene.add(atmosphereGroup);

    const terrainPatchesGroup = new THREE.Group();
    scene.add(terrainPatchesGroup);

    const markersGroup = new THREE.Group();
    scene.add(markersGroup);

    sceneObjectsRef.current = {
      scene,
      camera,
      controls,
      globeMesh,
      cloudMesh,
      atmosphereGroup,
      terrainPatchesGroup,
      markersGroup,
      maxAniso,
      flyTarget: null,
      isSyncApplying: false,
    };

    // Cancel fly-to when user grabs controls
    const handleControlStart = () => {
      if (sceneObjectsRef.current) {
        sceneObjectsRef.current.flyTarget = null;
      }
    };
    controls.addEventListener('start', handleControlStart);

    // Raycaster for hover coordinates & marker clicks
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    let lastHoverTs = 0;

    const updatePointer = (ev: PointerEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((ev.clientY - rect.top) / rect.height) * 2 + 1;
    };

    const handlePointerMove = (ev: PointerEvent) => {
      if (welcomeModeRef.current || !onHoverCoordsRef.current) return;
      const now = performance.now();
      if (now - lastHoverTs < 40) return;
      lastHoverTs = now;

      updatePointer(ev);
      raycaster.setFromCamera(pointer, camera);

      const markerHits = raycaster.intersectObjects(markersGroup.children, true);
      const patchHits = raycaster.intersectObjects(terrainPatchesGroup.children, false);
      renderer.domElement.style.cursor =
        markerHits.length > 0 || patchHits.length > 0 ? 'pointer' : 'crosshair';

      const surfaceHits = raycaster.intersectObjects(
        [globeMesh, ...terrainPatchesGroup.children],
        false,
      );
      if (surfaceHits.length > 0) {
        const localPoint = globeMesh.worldToLocal(surfaceHits[0].point.clone());
        onHoverCoordsRef.current(vector3ToLatLon(localPoint, bodyRef.current));
      } else {
        onHoverCoordsRef.current(null);
      }
    };

    const handlePointerLeave = () => {
      if (onHoverCoordsRef.current) onHoverCoordsRef.current(null);
    };

    let pointerDownPos = { x: 0, y: 0 };
    const handlePointerDown = (ev: PointerEvent) => {
      pointerDownPos = { x: ev.clientX, y: ev.clientY };
    };

    const handlePointerUp = (ev: PointerEvent) => {
      if (welcomeModeRef.current || !onSelectRegionRef.current) return;
      const dx = ev.clientX - pointerDownPos.x;
      const dy = ev.clientY - pointerDownPos.y;
      if (Math.hypot(dx, dy) > 6) return; // drag, not click

      updatePointer(ev);
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects(
        [...markersGroup.children, ...terrainPatchesGroup.children],
        true,
      );
      if (hits.length > 0) {
        let obj: THREE.Object3D | null = hits[0].object;
        while (obj && !obj.userData.regionId) {
          obj = obj.parent;
        }
        if (obj?.userData.regionId) {
          onSelectRegionRef.current(obj.userData.regionId as string);
        }
      }
    };

    renderer.domElement.addEventListener('pointermove', handlePointerMove);
    renderer.domElement.addEventListener('pointerleave', handlePointerLeave);
    renderer.domElement.addEventListener('pointerdown', handlePointerDown);
    renderer.domElement.addEventListener('pointerup', handlePointerUp);

    // ResizeObserver for container responsiveness
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const w = Math.max(100, entry.contentRect.width);
        const h = Math.max(100, entry.contentRect.height);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      }
    });
    resizeObserver.observe(container);

    // Animation loop with Software WebGL pacing
    let frameId = 0;
    let disposed = false;
    const clock = new THREE.Clock();
    const sphericalHelper = new THREE.Spherical();

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (gl && typeof gl.fenceSync === 'function') {
        const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
        gl.flush();
        const poll = () => {
          if (disposed) return;
          const state = sync ? gl.getSyncParameter(sync, gl.SYNC_STATUS) : gl.SIGNALED;
          if (state === gl.UNSIGNALED) {
            frameId = window.setTimeout(poll, 5);
          } else {
            if (sync) gl.deleteSync(sync);
            frameId = window.setTimeout(cb, 65);
          }
        };
        frameId = window.setTimeout(poll, 5);
      } else {
        frameId = window.setTimeout(cb, 65);
      }
    }

    const handleControlChange = () => {
      const obj = sceneObjectsRef.current;
      if (!obj || obj.isSyncApplying || !onCameraSphericalChangeRef.current) return;
      sphericalHelper.setFromVector3(camera.position);
      onCameraSphericalChangeRef.current({
        theta: sphericalHelper.theta,
        phi: sphericalHelper.phi,
        radius: sphericalHelper.radius,
      });
    };
    controls.addEventListener('change', handleControlChange);

    function tick() {
      if (disposed) return;
      const delta = Math.min(clock.getDelta(), 0.1);
      const obj = sceneObjectsRef.current;

      const camDist = camera.position.length();
      const altitude = Math.max(0.025, camDist - GLOBE_RADIUS);

      // Altitude-adaptive rotation speed & close-up cloud clearing
      controls.rotateSpeed = THREE.MathUtils.clamp(altitude * 0.45, 0.055, 0.72);
      controls.zoomSpeed = THREE.MathUtils.clamp(altitude * 0.68, 0.22, 0.95);

      if (cloudMesh.visible) {
        cloudMesh.rotation.y += delta * 0.014;
        if (bodyRef.current === 'earth' && showCloudsRef.current) {
          cloudMesh.material.opacity = THREE.MathUtils.clamp((camDist - 1.15) / 0.36, 0.03, 0.64);
        }
      }

      // Shrink marker dots/rings & soften wireframe opacity when zooming very close to 3D terrain patches
      const markerScale = THREE.MathUtils.clamp(altitude * 0.65, 0.14, 1.0);
      const boundaryFactor = camDist < 1.24 ? THREE.MathUtils.clamp((camDist - 1.04) / 0.2, 0.35, 1.0) : 1.0;
      markersGroup.traverse((c) => {
        if (c.userData.scaleWithAlt) {
          c.scale.setScalar(markerScale);
        } else if (c.userData.isBoundaryLine && c instanceof THREE.Line) {
          const mat = c.material as THREE.LineBasicMaterial;
          mat.opacity = (c.userData.baseOpacity as number) * boundaryFactor;
        }
      });

      if (welcomeModeRef.current) {
        // Gentle orbital drift on Welcome Screen
        const angle = delta * 0.085;
        camera.position.applyAxisAngle(new THREE.Vector3(0, 1, 0), angle);
        if (enteringSystemRef.current) {
          const targetLen = 1.9;
          const curLen = camera.position.length();
          const nextLen = THREE.MathUtils.damp(curLen, targetLen, 4.5, delta);
          camera.position.setLength(nextLen);
        }
        camera.lookAt(0, 0, 0);
      } else {
        if (autoRotateRef.current && obj && !obj.flyTarget) {
          camera.position.applyAxisAngle(new THREE.Vector3(0, 1, 0), delta * 0.12);
        }
        if (obj?.flyTarget) {
          camera.position.x = THREE.MathUtils.damp(camera.position.x, obj.flyTarget.x, 4.8, delta);
          camera.position.y = THREE.MathUtils.damp(camera.position.y, obj.flyTarget.y, 4.8, delta);
          camera.position.z = THREE.MathUtils.damp(camera.position.z, obj.flyTarget.z, 4.8, delta);
          if (camera.position.distanceTo(obj.flyTarget) < 0.008) {
            obj.flyTarget = null;
          }
        }
        controls.update();
      }

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      resizeObserver.disconnect();
      controls.removeEventListener('start', handleControlStart);
      controls.removeEventListener('change', handleControlChange);
      controls.dispose();
      renderer.domElement.removeEventListener('pointermove', handlePointerMove);
      renderer.domElement.removeEventListener('pointerleave', handlePointerLeave);
      renderer.domElement.removeEventListener('pointerdown', handlePointerDown);
      renderer.domElement.removeEventListener('pointerup', handlePointerUp);
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      renderer.domElement.removeEventListener('webglcontextrestored', handleContextRestored);

      globeGeo.dispose();
      globeMat.map?.dispose();
      globeMat.bumpMap?.dispose();
      globeMat.roughnessMap?.dispose();
      globeMat.dispose();
      cloudGeo.dispose();
      cloudMat.map?.dispose();
      cloudMat.dispose();
      stars.geometry.dispose();
      (stars.material as THREE.Material).dispose();
      atmosphereGroup.children.forEach((c) => {
        if (c instanceof THREE.Mesh) {
          c.geometry.dispose();
          (c.material as THREE.Material).dispose();
        }
      });
      disposeTerrainPatchesGroup(terrainPatchesGroup);
      markersGroup.children.forEach((g) => {
        g.traverse((c) => {
          if (c instanceof THREE.Mesh || c instanceof THREE.Line) {
            c.geometry.dispose();
            (c.material as THREE.Material).dispose();
          }
        });
      });

      renderer.dispose();
      sceneObjectsRef.current = null;
    };
  }, []);

  // Update planet textures, relief maps, clouds & atmosphere when body or scientific overlays change
  useEffect(() => {
    const obj = sceneObjectsRef.current;
    if (!obj) return;

    const nextSet = createPlanetaryTextures(body, {
      showMolaElevation,
      showObservationOverlay,
    });
    nextSet.map.anisotropy = obj.maxAniso;
    nextSet.bumpMap.anisotropy = obj.maxAniso;

    const oldMap = obj.globeMesh.material.map;
    const oldBump = obj.globeMesh.material.bumpMap;
    const oldRough = obj.globeMesh.material.roughnessMap;
    const oldCloud = obj.cloudMesh.material.map;

    obj.globeMesh.material.map = nextSet.map;
    obj.globeMesh.material.bumpMap = nextSet.bumpMap;
    obj.globeMesh.material.bumpScale = body === 'earth' ? 0.032 : body === 'mars' ? 0.044 : 0.052;
    obj.globeMesh.material.roughnessMap = nextSet.roughnessMap;
    obj.globeMesh.material.roughness = 1.0;
    obj.globeMesh.material.metalness = body === 'earth' ? 0.08 : 0.03;
    obj.globeMesh.material.needsUpdate = true;

    obj.cloudMesh.material.map = nextSet.cloudMap ?? null;
    obj.cloudMesh.material.opacity = body === 'earth' && showClouds ? 0.68 : 0;
    obj.cloudMesh.visible = body === 'earth' && showClouds && Boolean(nextSet.cloudMap);
    obj.cloudMesh.material.needsUpdate = true;

    oldMap?.dispose();
    oldBump?.dispose();
    oldRough?.dispose();
    oldCloud?.dispose();

    // Update atmosphere mesh
    obj.atmosphereGroup.children.forEach((c) => {
      if (c instanceof THREE.Mesh) {
        c.geometry.dispose();
        (c.material as THREE.Material).dispose();
      }
    });
    obj.atmosphereGroup.clear();
    const nextAtmos = createAtmosphereMesh(body);
    if (nextAtmos) obj.atmosphereGroup.add(nextAtmos);
  }, [body, showClouds, showMolaElevation, showObservationOverlay]);

  // Build 3D displaced regional terrain meshes for close-up inspection
  useEffect(() => {
    const obj = sceneObjectsRef.current;
    if (!obj) return;

    disposeTerrainPatchesGroup(obj.terrainPatchesGroup);
    const bodyRegions = regions.filter((r) => r.body === body);
    bodyRegions.forEach((region) => {
      const patch = buildRegionalTerrainPatch(region, {
        showObservationOverlay: body === 'mars' && showObservationOverlay,
      });
      const mat = patch.material as THREE.MeshStandardMaterial;
      if (mat.map) mat.map.anisotropy = obj.maxAniso;
      obj.terrainPatchesGroup.add(patch);
    });
  }, [body, regions, showObservationOverlay]);

  // Update study region 3D markers & bounding windows
  useEffect(() => {
    const obj = sceneObjectsRef.current;
    if (!obj) return;

    obj.markersGroup.children.forEach((g) => {
      g.traverse((c) => {
        if (c instanceof THREE.Mesh || c instanceof THREE.Line) {
          c.geometry.dispose();
          (c.material as THREE.Material).dispose();
        }
      });
    });
    obj.markersGroup.clear();

    const bodyRegions = regions.filter((r) => r.body === body);
    bodyRegions.forEach((region) => {
      const markerGroup = buildRegionMarkerGroup(
        region,
        region.id === selectedRegionId,
        showBoundary,
      );
      obj.markersGroup.add(markerGroup);
    });
  }, [body, regions, selectedRegionId, showBoundary]);

  // Fly camera to focusTarget smoothly
  useEffect(() => {
    const obj = sceneObjectsRef.current;
    if (!obj || !focusTarget) return;
    const dist = focusTarget.distance ?? 2.05;
    obj.flyTarget = latLonToVector3(focusTarget.lat, focusTarget.lon, dist);
  }, [focusTarget]);

  // Step camera zoom in/out smoothly via UI zoom controls
  useEffect(() => {
    const obj = sceneObjectsRef.current;
    if (!obj || !zoomCommand) return;
    const basePos = obj.flyTarget ? obj.flyTarget.clone() : obj.camera.position.clone();
    const curLen = basePos.length();
    const nextLen = THREE.MathUtils.clamp(curLen + zoomCommand.delta, 1.042, 4.8);
    obj.flyTarget = basePos.setLength(nextLen);
  }, [zoomCommand]);

  // Apply synchronized camera state from paired globe (in Analog Comparison view)
  useEffect(() => {
    const obj = sceneObjectsRef.current;
    if (!obj || !syncSpherical) return;
    obj.isSyncApplying = true;
    obj.flyTarget = null;
    const sph = new THREE.Spherical(
      syncSpherical.radius,
      syncSpherical.phi,
      syncSpherical.theta,
    );
    obj.camera.position.setFromSpherical(sph);
    obj.camera.lookAt(0, 0, 0);
    obj.controls.update();
    obj.isSyncApplying = false;
  }, [syncSpherical]);

  if (contextLost) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-[#060911] border border-slate-800 text-slate-300 p-6 ${className}`}
      >
        <p className="font-display text-base font-semibold text-slate-100">
          Visor 3D WebGL no disponible
        </p>
        <p className="mt-2 max-w-md text-center text-sm text-slate-400">
          No se pudo inicializar el contexto WebGL en este dispositivo. Los datos, métricas y el
          cálculo ACI siguen disponibles en los paneles.
        </p>
      </div>
    );
  }

  return <div ref={mountRef} className={`w-full h-full relative select-none ${className}`} />;
}
