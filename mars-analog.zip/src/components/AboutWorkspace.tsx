import { useEffect, useState } from 'react';
import { AlertTriangle, CheckCircle2, Clock, ShieldAlert } from 'lucide-react';
import { fetchLimitations, fetchProjectStatus } from '../api/client';
import type { LimitationItem, ProjectTaskItem } from '../shared/types';

const TEAM_MEMBERS = [
  { name: 'Octavio Andrés Pereyra', role: 'Exploración planetaria e investigación' },
  { name: 'Cesar Martin Pereyra', role: 'Backend y cálculo topográfico' },
  { name: 'Danily Castro Navarro', role: 'Curación y validación de datos' },
  { name: 'Fabricio Quiroz Montaño', role: 'Visualización 3D y mapas' },
  { name: 'Warren Clarkson', role: 'Asesoría científica' },
];

const SEVERITY_CONFIG: Record<
  LimitationItem['severity'],
  { label: string; textClass: string; borderClass: string }
> = {
  critical: {
    label: 'Crítica',
    textClass: 'text-rose-300',
    borderClass: 'border-rose-800/60',
  },
  warning: {
    label: 'Advertencia',
    textClass: 'text-amber-300',
    borderClass: 'border-amber-800/60',
  },
  info: {
    label: 'Nota técnica',
    textClass: 'text-cyan-300',
    borderClass: 'border-cyan-800/60',
  },
};

const TASK_STATUS_CONFIG: Record<
  ProjectTaskItem['status'],
  { label: string; textClass: string }
> = {
  implemented: { label: 'Implementado', textClass: 'text-emerald-300' },
  partial: { label: 'Parcial', textClass: 'text-amber-300' },
  pending_raw_data: { label: 'Requiere GeoTIFF local', textClass: 'text-slate-400' },
  future_extension: { label: 'Extensión futura', textClass: 'text-sky-300' },
};

const BODY_NAMES: Record<string, string> = {
  earth: 'TIERRA',
  mars: 'MARTE',
  moon: 'LUNA',
};

export function AboutWorkspace() {
  const [limitations, setLimitations] = useState<LimitationItem[]>([]);
  const [tasks, setTasks] = useState<ProjectTaskItem[]>([]);
  const [rawMounted, setRawMounted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    Promise.all([fetchLimitations(), fetchProjectStatus()])
      .then(([limList, statusData]) => {
        if (cancelled) return;
        setLimitations(limList);
        setTasks(statusData.tasks);
        setRawMounted(statusData.rawGeoTiffMounted);
      })
      .catch((err) => {
        if (cancelled) return;
        setError(err instanceof Error ? err.message : 'Error al cargar estado técnico.');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="flex-1 overflow-y-auto bg-[#060911] text-slate-100">
      <div className="max-w-5xl mx-auto px-6 py-8 space-y-8">
        <header className="border-b border-slate-800 pb-5">
          <h1 className="font-display text-3xl font-bold text-white">
            LIMITACIONES Y ESTADO TÉCNICO
          </h1>
          <p className="mt-2 text-sm text-slate-300 leading-relaxed">
            NEXANALOG compara topografía entre la Tierra, Marte y la Luna manteniendo visibles las
            limitaciones metodológicas, la cobertura observacional real y el estado técnico de cada
            módulo.
          </p>
        </header>

        {error && (
          <div className="p-4 border border-rose-800 bg-rose-950/30 rounded-md text-xs text-rose-200">
            {error}
          </div>
        )}

        {/* 1. Limitaciones científicas */}
        <section className="space-y-3">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-amber-400" />
            <h2 className="font-display text-xl font-bold text-white">
              Limitaciones científicas del análisis
            </h2>
          </div>

          {loading ? (
            <div className="text-xs text-slate-400 py-4">Cargando limitaciones...</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {limitations.map((item) => {
                const sev = SEVERITY_CONFIG[item.severity];
                return (
                  <article
                    key={item.id}
                    className={`p-4 bg-[#090E1A] border ${sev.borderClass} rounded-md space-y-2`}
                  >
                    <div className="flex items-center justify-between gap-2 text-xs font-mono">
                      <span className={sev.textClass}>{sev.label} · {item.category}</span>
                      <span className="text-slate-400">
                        {item.affectedBodies.map((b) => BODY_NAMES[b] ?? b).join(' · ')}
                      </span>
                    </div>
                    <h3 className="text-sm font-semibold text-white">{item.title}</h3>
                    <p className="text-xs text-slate-300 leading-relaxed">{item.description}</p>
                  </article>
                );
              })}
            </div>
          )}
        </section>

        {/* 2. Estados técnicos del proyecto */}
        <section className="space-y-3 border-t border-slate-800 pt-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-cyan-400" />
              <h2 className="font-display text-xl font-bold text-white">
                Estados técnicos del proyecto
              </h2>
            </div>
            <span className="text-xs font-mono text-slate-400">
              GeoTIFF binario local:{' '}
              <strong className={rawMounted ? 'text-emerald-300' : 'text-amber-300'}>
                {rawMounted ? 'Montado' : 'No montado (usando resúmenes verificados y ref. NASA)'}
              </strong>
            </span>
          </div>

          {loading ? (
            <div className="text-xs text-slate-400 py-4">Cargando estado técnico...</div>
          ) : (
            <div className="bg-[#090E1A] border border-slate-800 rounded-md divide-y divide-slate-800/80">
              {tasks.map((task) => {
                const st = TASK_STATUS_CONFIG[task.status];
                return (
                  <div
                    key={task.id}
                    className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div className="flex items-start gap-2.5">
                      {task.status === 'implemented' ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <div className="text-xs sm:text-sm font-medium text-slate-100">
                          {task.id}. {task.title}
                        </div>
                        <div className="text-xs text-slate-400">{task.detail}</div>
                      </div>
                    </div>
                    <span className={`text-xs font-mono shrink-0 ${st.textClass}`}>
                      {st.label}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        {/* 3. Métricas y fuentes */}
        <section className="space-y-3 border-t border-slate-800 pt-6">
          <h2 className="font-display text-lg font-bold text-white">
            Variables medidas y fuentes de referencia
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="p-4 bg-[#090E1A] border border-slate-800 rounded-md space-y-1">
              <div className="font-display text-sm font-bold text-white">TIERRA</div>
              <div className="text-slate-300">NASA SRTM (~30 m) y ArcticDEM (~10 m, &gt;60° N)</div>
              <div className="font-mono text-slate-500">CRS: EPSG:4326 · EGM96/WGS84</div>
            </div>
            <div className="p-4 bg-[#090E1A] border border-slate-800 rounded-md space-y-1">
              <div className="font-display text-sm font-bold text-white">MARTE</div>
              <div className="text-slate-300">NASA PDS MOLA MEGDR (~463 m/px)</div>
              <div className="font-mono text-slate-500">CRS: IAU_2015:49900 · Areoide GMM3</div>
            </div>
            <div className="p-4 bg-[#090E1A] border border-slate-800 rounded-md space-y-1">
              <div className="font-display text-sm font-bold text-white">LUNA</div>
              <div className="text-slate-300">NASA PDS LRO LOLA (~20–60 m/px ref.)</div>
              <div className="font-mono text-slate-500">CRS: IAU_2015:30100 · Esfera LOLA</div>
            </div>
          </div>
        </section>

        {/* 4. Equipo del Proyecto */}
        <section className="space-y-3 border-t border-slate-800 pt-6">
          <h2 className="font-display text-lg font-bold text-white">Equipo del Proyecto</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {TEAM_MEMBERS.map((member) => (
              <div
                key={member.name}
                className="p-4 bg-[#090E1A] border border-slate-800 rounded-md"
              >
                <div className="text-sm font-semibold text-white">{member.name}</div>
                <div className="mt-1 text-xs text-slate-400">{member.role}</div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
