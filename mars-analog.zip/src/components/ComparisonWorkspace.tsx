import { useCallback, useEffect, useState } from 'react';
import {
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Link2,
  Link2Off,
  Minus,
  Plus,
  RotateCcw,
  SlidersHorizontal,
} from 'lucide-react';
import { computeAciComparison, fetchRegionResults } from '../api/client';
import type { AciResult, RegionRecord, RegionResults } from '../shared/types';
import { type CameraSphericalState, GlobeViewport } from './GlobeViewport';

interface ComparisonWorkspaceProps {
  regions: RegionRecord[];
  initialEarthRegionId?: string;
  initialTargetRegionId?: string;
}

const DEFAULT_WEIGHTS = { slope: 0.4, tri: 0.35, localRelief: 0.25 };
const DEFAULT_SCALES = { slope: 10, tri: 5, localRelief: 20 };

function fmt(val: number | null | undefined, digits = 2): string {
  if (val === null || val === undefined || !Number.isFinite(val)) return '—';
  return val.toFixed(digits);
}

export function ComparisonWorkspace({
  regions,
  initialEarthRegionId,
  initialTargetRegionId,
}: ComparisonWorkspaceProps) {
  const earthRegions = regions.filter((r) => r.body === 'earth');
  const targetRegions = regions.filter((r) => r.body === 'mars' || r.body === 'moon');

  const [earthRegionId, setEarthRegionId] = useState<string>(
    initialEarthRegionId ?? 'uyuni_25km',
  );
  const [targetRegionId, setTargetRegionId] = useState<string>(
    initialTargetRegionId ?? 'jezero_25km',
  );

  useEffect(() => {
    if (initialEarthRegionId) setEarthRegionId(initialEarthRegionId);
    if (initialTargetRegionId) setTargetRegionId(initialTargetRegionId);
  }, [initialEarthRegionId, initialTargetRegionId]);

  const [earthResult, setEarthResult] = useState<RegionResults | null>(null);
  const [targetResult, setTargetResult] = useState<RegionResults | null>(null);
  const [targetRole, setTargetRole] = useState<'full_dem' | 'observed_only_dem'>('full_dem');

  const [weights, setWeights] = useState(DEFAULT_WEIGHTS);
  const [scales, setScales] = useState(DEFAULT_SCALES);
  const [showAdvancedParams, setShowAdvancedParams] = useState(false);

  const [aci, setAci] = useState<AciResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [aciLoading, setAciLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [syncOrbits, setSyncOrbits] = useState(false);
  const [sharedSpherical, setSharedSpherical] = useState<CameraSphericalState | null>(null);
  const [syncSource, setSyncSource] = useState<'earth' | 'target' | null>(null);
  const [focusKey, setFocusKey] = useState(1);
  const [earthZoomCmd, setEarthZoomCmd] = useState<{ delta: number; key: number } | null>(null);
  const [targetZoomCmd, setTargetZoomCmd] = useState<{ delta: number; key: number } | null>(null);

  const earthRegion = earthRegions.find((r) => r.id === earthRegionId);
  const targetRegion = targetRegions.find((r) => r.id === targetRegionId);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    Promise.all([
      fetchRegionResults(earthRegionId),
      fetchRegionResults(targetRegionId),
    ])
      .then(([earthData, tgtData]) => {
        if (cancelled) return;
        setEarthResult(earthData);
        setTargetResult(tgtData);
      })
      .catch((err) => {
        if (cancelled) return;
        setError(err instanceof Error ? err.message : 'Error al cargar comparación.');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [earthRegionId, targetRegionId]);

  useEffect(() => {
    let cancelled = false;
    setAciLoading(true);

    computeAciComparison({
      earthRegionId,
      targetRegionId,
      targetDatasetRole: targetRegionId === 'jezero_25km' ? targetRole : 'full_dem',
      weights,
      scales,
    })
      .then((res) => {
        if (!cancelled) setAci(res);
      })
      .catch((err) => {
        if (!cancelled) setError(err instanceof Error ? err.message : 'Error al calcular similitud.');
      })
      .finally(() => {
        if (!cancelled) setAciLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [earthRegionId, targetRegionId, targetRole, weights, scales]);

  const handleEarthCamera = useCallback(
    (s: CameraSphericalState) => {
      if (!syncOrbits) return;
      setSyncSource('earth');
      setSharedSpherical(s);
    },
    [syncOrbits],
  );

  const handleTargetCamera = useCallback(
    (s: CameraSphericalState) => {
      if (!syncOrbits) return;
      setSyncSource('target');
      setSharedSpherical(s);
    },
    [syncOrbits],
  );

  const earthDs = earthResult?.datasets[0] ?? null;
  const targetDs =
    targetRegionId === 'jezero_25km'
      ? targetResult?.datasets.find((d) => d.datasetRole === targetRole) ??
        targetResult?.datasets[0] ??
        null
      : targetResult?.datasets[0] ?? null;

  const isMoonTarget = targetRegion?.body === 'moon';
  const activeBreakdown = aci?.breakdown.filter((b) => b.available) ?? [];
  const localReliefMissing = !(aci?.breakdown.find((b) => b.variable === 'localRelief')?.available);

  const resetDefaults = () => {
    setWeights(DEFAULT_WEIGHTS);
    setScales(DEFAULT_SCALES);
  };

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center bg-[#060911] text-slate-400 text-sm">
        Cargando comparación...
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto bg-[#060911] text-slate-100">
      <div className="max-w-[1320px] mx-auto px-6 py-7 space-y-6">
        {/* Título y selectores claros */}
        <div className="flex flex-col xl:flex-row xl:items-end justify-between gap-4 border-b border-slate-800 pb-5">
          <div>
            <h1 className="font-display text-3xl font-bold text-white">
              COMPARACIÓN DE ANÁLOGOS
            </h1>
            <p className="mt-1 text-sm text-slate-300">
              Compara{' '}
              <strong>{earthRegion?.name ?? earthResult?.regionName ?? 'Tierra'}</strong> con{' '}
              <strong>{targetRegion?.name ?? targetResult?.regionName ?? 'Destino'}</strong>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <label className="flex items-center gap-2 px-3 py-1.5 bg-[#090E1A] border border-slate-800 rounded-md text-xs">
              <span className="text-cyan-400 font-semibold">Tierra:</span>
              <select
                value={earthRegionId}
                onChange={(e) => {
                  setEarthRegionId(e.target.value);
                  setFocusKey((k) => k + 1);
                }}
                className="bg-transparent text-slate-100 focus:outline-none cursor-pointer"
              >
                {earthRegions.map((r) => (
                  <option key={r.id} value={r.id} className="bg-[#090E1A] text-slate-100">
                    {r.name} ({r.status === 'active' ? 'Local' : r.id === 'haughton_crater_ca' ? 'ArcticDEM' : 'SRTM'})
                  </option>
                ))}
              </select>
            </label>

            <label className="flex items-center gap-2 px-3 py-1.5 bg-[#090E1A] border border-slate-800 rounded-md text-xs">
              <span className="text-amber-400 font-semibold">Destino:</span>
              <select
                value={targetRegionId}
                onChange={(e) => {
                  setTargetRegionId(e.target.value);
                  setFocusKey((k) => k + 1);
                }}
                className="bg-transparent text-slate-100 focus:outline-none cursor-pointer"
              >
                {targetRegions.map((r) => (
                  <option key={r.id} value={r.id} className="bg-[#090E1A] text-slate-100">
                    {r.body === 'mars' ? 'Marte' : 'Luna'} · {r.name}
                  </option>
                ))}
              </select>
            </label>

            {targetRegionId === 'jezero_25km' && (
              <div className="flex items-center gap-1 p-1 bg-[#090E1A] border border-slate-800 rounded-md">
                <button
                  type="button"
                  onClick={() => setTargetRole('full_dem')}
                  className={`px-3 py-1 text-xs font-medium rounded-sm cursor-pointer ${
                    targetRole === 'full_dem'
                      ? 'bg-slate-200 text-slate-950 font-semibold'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  Datos completos
                </button>
                <button
                  type="button"
                  onClick={() => setTargetRole('observed_only_dem')}
                  className={`px-3 py-1 text-xs font-medium rounded-sm cursor-pointer ${
                    targetRole === 'observed_only_dem'
                      ? 'bg-slate-200 text-slate-950 font-semibold'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  Solo medidos
                </button>
              </div>
            )}

            <button
              type="button"
              onClick={() => setSyncOrbits((s) => !s)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md border cursor-pointer ${
                syncOrbits
                  ? 'border-cyan-500 bg-cyan-950/40 text-cyan-300'
                  : 'border-slate-800 bg-[#090E1A] text-slate-300 hover:border-slate-700'
              }`}
            >
              {syncOrbits ? <Link2 className="w-3.5 h-3.5" /> : <Link2Off className="w-3.5 h-3.5" />}
              <span>{syncOrbits ? 'Globos unidos' : 'Unir giro'}</span>
            </button>
          </div>
        </div>

        {error && (
          <div className="p-4 border border-rose-800 bg-rose-950/30 rounded-md text-sm text-rose-200">
            {error}
          </div>
        )}

        {/* Globos lado a lado con zoom cercano */}
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div className="bg-[#090E1A] border border-slate-800 rounded-md overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between gap-3">
              <div>
                <div className="text-xs text-cyan-400 font-semibold">
                  TIERRA · {earthRegion?.status === 'active' ? 'Procesado local' : 'Ref. satelital'}
                </div>
                <h2 className="font-display text-lg font-bold text-white">
                  {earthRegion?.name ?? earthResult?.regionName}
                </h2>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <div className="text-right text-xs font-mono text-slate-400 tabular-nums">
                  <div>
                    {earthRegion
                      ? `${earthRegion.centerLat.toFixed(2)}°, ${earthRegion.centerLon.toFixed(2)}°`
                      : '—'}
                  </div>
                  <div>Detalle: cada ~{Math.round(earthDs?.pixelScaleM ?? 30)} m</div>
                </div>
                <div className="flex items-center gap-1 bg-[#060911] border border-slate-800 rounded p-0.5">
                  <button
                    type="button"
                    onClick={() => setEarthZoomCmd({ delta: -0.2, key: Date.now() })}
                    title="Acercar Tierra"
                    className="p-1 text-slate-300 hover:text-white cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setEarthZoomCmd({ delta: 0.22, key: Date.now() })}
                    title="Alejar Tierra"
                    className="p-1 text-slate-300 hover:text-white cursor-pointer"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
            <div className="h-[310px] w-full bg-[#060911]">
              <GlobeViewport
                body="earth"
                regions={regions}
                selectedRegionId={earthRegionId}
                focusTarget={
                  earthRegion
                    ? {
                        lat: earthRegion.centerLat,
                        lon: earthRegion.centerLon,
                        distance: 1.26,
                        key: focusKey,
                      }
                    : null
                }
                zoomCommand={earthZoomCmd}
                showBoundary={true}
                showClouds={true}
                syncSpherical={syncOrbits && syncSource === 'target' ? sharedSpherical : null}
                onCameraSphericalChange={handleEarthCamera}
              />
            </div>
          </div>

          <div className="bg-[#090E1A] border border-slate-800 rounded-md overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between gap-3">
              <div>
                <div className="text-xs text-amber-400 font-semibold">
                  {isMoonTarget ? 'LUNA · Ref. NASA LOLA' : 'MARTE · Datos MOLA'}
                </div>
                <h2 className="font-display text-lg font-bold text-white">
                  {targetRegion?.name ?? targetResult?.regionName}
                </h2>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <div className="text-right text-xs font-mono text-slate-400 tabular-nums">
                  <div>
                    {targetRegion
                      ? `${targetRegion.centerLat.toFixed(2)}°, ${targetRegion.centerLon.toFixed(2)}° E`
                      : '—'}
                  </div>
                  <div>Detalle: cada ~{Math.round(targetDs?.pixelScaleM ?? 463)} m</div>
                </div>
                <div className="flex items-center gap-1 bg-[#060911] border border-slate-800 rounded p-0.5">
                  <button
                    type="button"
                    onClick={() => setTargetZoomCmd({ delta: -0.2, key: Date.now() })}
                    title="Acercar destino"
                    className="p-1 text-slate-300 hover:text-white cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setTargetZoomCmd({ delta: 0.22, key: Date.now() })}
                    title="Alejar destino"
                    className="p-1 text-slate-300 hover:text-white cursor-pointer"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
            <div className="h-[310px] w-full bg-[#060911]">
              <GlobeViewport
                body={isMoonTarget ? 'moon' : 'mars'}
                regions={regions}
                selectedRegionId={targetRegionId}
                focusTarget={
                  targetRegion
                    ? {
                        lat: targetRegion.centerLat,
                        lon: targetRegion.centerLon,
                        distance: 1.26,
                        key: focusKey,
                      }
                    : null
                }
                zoomCommand={targetZoomCmd}
                showBoundary={true}
                showMolaElevation={true}
                showObservationOverlay={!isMoonTarget}
                syncSpherical={syncOrbits && syncSource === 'earth' ? sharedSpherical : null}
                onCameraSphericalChange={handleTargetCamera}
              />
            </div>
          </div>
        </section>

        {/* Resultado principal fácil de entender */}
        <section className="bg-[#090E1A] border border-slate-800 rounded-md p-6 space-y-5">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            <div className="lg:col-span-4 p-5 bg-[#060911] border border-slate-800 rounded-md">
              <div className="text-xs text-slate-400">
                Índice de similitud del terreno (ACI)
              </div>
              <div className="mt-1.5 flex items-baseline gap-2">
                <span className="font-mono text-5xl font-bold text-cyan-400 tabular-nums">
                  {aciLoading
                    ? '...'
                    : aci?.score !== null && aci?.score !== undefined
                      ? aci.score.toFixed(1)
                      : 'Pendiente'}
                </span>
                {aci?.score !== null && aci?.score !== undefined && (
                  <span className="font-mono text-sm text-slate-400">/ 100</span>
                )}
              </div>
              {aci?.score !== null && aci?.score !== undefined && (
                <div className="mt-3 h-2 w-full bg-slate-900 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-cyan-400 transition-all duration-300"
                    style={{ width: `${Math.min(100, Math.max(0, aci.score))}%` }}
                  />
                </div>
              )}
              <p className="mt-2.5 text-xs text-slate-400">
                Indicador experimental (no es oficial de NASA). 100 significa terreno idéntico en
                las variables comparadas.
              </p>
            </div>

            <div className="lg:col-span-8 space-y-3">
              <h2 className="font-display text-lg font-bold text-white">
                ¿Por qué dio este resultado?
              </h2>
              {targetRegionId === 'jezero_25km' && targetRole === 'observed_only_dem' ? (
                <p className="text-sm text-amber-200/90 leading-relaxed">
                  Los datos filtrados sin interpolación requieren el archivo GeoTIFF original en el
                  servidor. Cambia a <strong>Datos completos</strong> arriba para ver la comparación
                  calculada.
                </p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                  {activeBreakdown.map((item, idx) => {
                    const simPct =
                      item.similaritySj !== null ? (item.similaritySj * 100).toFixed(1) : '—';
                    const isGood = (item.similaritySj ?? 0) >= 0.5;
                    return (
                      <div
                        key={item.variable}
                        className="p-3.5 bg-[#060911] border border-slate-800 rounded-md space-y-1"
                      >
                        <div className={`font-semibold ${isGood ? 'text-cyan-300' : 'text-amber-300'}`}>
                          {idx + 1}. {item.label} ({simPct}% similar)
                        </div>
                        <p className="text-slate-300 leading-relaxed tabular-nums">
                          Tierra: <strong>{fmt(item.earthValue, 2)} {item.unit}</strong> vs Destino:{' '}
                          <strong>{fmt(item.targetValue, 2)} {item.unit}</strong>.
                        </p>
                      </div>
                    );
                  })}
                </div>
              )}

              <div className="flex items-start gap-2 text-xs text-slate-400 pt-1">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>
                  {localReliefMissing
                    ? 'El desnivel local no está en el resumen de este recorte; el cálculo reparte el peso entre Inclinación y Rugosidad sin inventar ceros.'
                    : 'Compara únicamente la forma del terreno considerando la diferencia de resolución entre sensores.'}
                </span>
              </div>
            </div>
          </div>

          {/* Botón opcional para ajustar parámetros */}
          <div className="border-t border-slate-800 pt-4">
            <button
              type="button"
              onClick={() => setShowAdvancedParams((s) => !s)}
              className="inline-flex items-center gap-2 text-xs font-medium text-slate-300 hover:text-cyan-300 cursor-pointer"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-cyan-400" />
              <span>Ajustar importancia de cada variable (opcional)</span>
              {showAdvancedParams ? (
                <ChevronUp className="w-4 h-4" />
              ) : (
                <ChevronDown className="w-4 h-4" />
              )}
            </button>

            {showAdvancedParams && (
              <div className="mt-4 p-4 bg-[#060911] border border-slate-800 rounded-md space-y-4">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">
                    Fórmula: S = exp(-|diferencia| / escala) · ACI = 100 × promedio ponderado
                  </span>
                  <button
                    type="button"
                    onClick={resetDefaults}
                    className="inline-flex items-center gap-1 text-cyan-400 hover:underline cursor-pointer"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Valores iniciales</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-5 text-xs">
                  <div className="space-y-1.5">
                    <div className="flex justify-between">
                      <span>Peso Inclinación</span>
                      <span className="font-mono text-cyan-400">
                        {(weights.slope * 100).toFixed(0)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={weights.slope}
                      onChange={(e) => setWeights((w) => ({ ...w, slope: Number(e.target.value) }))}
                      className="w-full accent-cyan-400 cursor-pointer"
                    />
                    <div className="flex justify-between text-slate-400">
                      <span>Tolerancia (escala)</span>
                      <span className="font-mono">{scales.slope}°</span>
                    </div>
                    <input
                      type="range"
                      min={1}
                      max={30}
                      step={1}
                      value={scales.slope}
                      onChange={(e) => setScales((s) => ({ ...s, slope: Number(e.target.value) }))}
                      className="w-full accent-cyan-400 cursor-pointer"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex justify-between">
                      <span>Peso Rugosidad (TRI)</span>
                      <span className="font-mono text-cyan-400">
                        {(weights.tri * 100).toFixed(0)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={weights.tri}
                      onChange={(e) => setWeights((w) => ({ ...w, tri: Number(e.target.value) }))}
                      className="w-full accent-cyan-400 cursor-pointer"
                    />
                    <div className="flex justify-between text-slate-400">
                      <span>Tolerancia (escala)</span>
                      <span className="font-mono">{scales.tri} m</span>
                    </div>
                    <input
                      type="range"
                      min={1}
                      max={50}
                      step={1}
                      value={scales.tri}
                      onChange={(e) => setScales((s) => ({ ...s, tri: Number(e.target.value) }))}
                      className="w-full accent-cyan-400 cursor-pointer"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex justify-between text-slate-300">
                      <span>Peso Desnivel local</span>
                      <span className="font-mono text-cyan-400">
                        {localReliefMissing
                          ? 'Excluido'
                          : `${(weights.localRelief * 100).toFixed(0)}%`}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={weights.localRelief}
                      onChange={(e) =>
                        setWeights((w) => ({ ...w, localRelief: Number(e.target.value) }))
                      }
                      className="w-full accent-cyan-400 cursor-pointer"
                    />
                    <div className="flex justify-between text-slate-400">
                      <span>Tolerancia (escala)</span>
                      <span className="font-mono">{scales.localRelief} m</span>
                    </div>
                    <input
                      type="range"
                      min={2}
                      max={150}
                      step={2}
                      value={scales.localRelief}
                      onChange={(e) =>
                        setScales((s) => ({ ...s, localRelief: Number(e.target.value) }))
                      }
                      className="w-full accent-cyan-400 cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* Comparación visual simple en 3 tarjetas */}
        {earthDs && targetDs && (
          <section className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="bg-[#090E1A] border border-slate-800 rounded-md p-5 space-y-3">
              <h3 className="text-sm font-semibold text-white">Inclinación promedio</h3>
              {[
                {
                  label: `${earthRegion?.name ?? 'Tierra'}`,
                  val: earthDs.slope.mean,
                  color: 'bg-cyan-400',
                },
                {
                  label: `${targetRegion?.name ?? 'Destino'}`,
                  val: targetDs.slope.mean,
                  color: 'bg-amber-400',
                },
              ].map((item) => (
                <div key={item.label} className="space-y-1 text-xs">
                  <div className="flex justify-between gap-2">
                    <span className="text-slate-300 truncate">{item.label}</span>
                    <span className="font-mono text-white shrink-0 tabular-nums">
                      {item.val !== null ? `${fmt(item.val, 2)}°` : '—'}
                    </span>
                  </div>
                  <div className="h-2.5 bg-[#060911] border border-slate-800 rounded-xs overflow-hidden">
                    <div
                      className={`h-full ${item.color}`}
                      style={{ width: `${item.val !== null ? Math.min(100, (item.val / 25) * 100) : 0}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-[#090E1A] border border-slate-800 rounded-md p-5 space-y-3">
              <h3 className="text-sm font-semibold text-white">Rugosidad del terreno</h3>
              {[
                {
                  label: `${earthRegion?.name ?? 'Tierra'}`,
                  val: earthDs.tri.mean,
                  color: 'bg-cyan-400',
                },
                {
                  label: `${targetRegion?.name ?? 'Destino'}`,
                  val: targetDs.tri.mean,
                  color: 'bg-amber-400',
                },
              ].map((item) => (
                <div key={item.label} className="space-y-1 text-xs">
                  <div className="flex justify-between gap-2">
                    <span className="text-slate-300 truncate">{item.label}</span>
                    <span className="font-mono text-white shrink-0 tabular-nums">
                      {item.val !== null ? `${fmt(item.val, 2)} m` : '—'}
                    </span>
                  </div>
                  <div className="h-2.5 bg-[#060911] border border-slate-800 rounded-xs overflow-hidden">
                    <div
                      className={`h-full ${item.color}`}
                      style={{ width: `${item.val !== null ? Math.min(100, (item.val / 60) * 100) : 0}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-[#090E1A] border border-slate-800 rounded-md p-5 space-y-3">
              <h3 className="text-sm font-semibold text-white">Cobertura y datos válidos</h3>
              <div className="space-y-1 text-xs">
                <div className="flex justify-between gap-2">
                  <span className="text-slate-300 truncate">{earthRegion?.name}</span>
                  <span className="font-mono text-cyan-300 shrink-0 tabular-nums">
                    {earthDs.coverage.validPercent !== null
                      ? `${earthDs.coverage.validPercent.toFixed(1)}% válidos`
                      : '—'}
                  </span>
                </div>
                <div className="h-2.5 bg-[#060911] border border-slate-800 rounded-xs overflow-hidden">
                  <div
                    className="h-full bg-cyan-500"
                    style={{ width: `${earthDs.coverage.validPercent ?? 0}%` }}
                  />
                </div>
              </div>
              <div className="space-y-1 text-xs">
                <div className="flex justify-between gap-2">
                  <span className="text-slate-300 truncate">{targetRegion?.name}</span>
                  <span className="font-mono text-amber-300 shrink-0 tabular-nums">
                    {targetRegionId === 'jezero_25km'
                      ? `${targetDs.coverage.observedPercent?.toFixed(1) ?? '0'}% / ${targetDs.coverage.interpolatedOrEmptyPercent?.toFixed(1) ?? '0'}%`
                      : `${targetDs.coverage.validPercent?.toFixed(1) ?? '95'}% LOLA`}
                  </span>
                </div>
                <div className="h-2.5 bg-[#060911] border border-slate-800 rounded-xs overflow-hidden flex">
                  {targetRegionId === 'jezero_25km' ? (
                    <>
                      <div
                        className="h-full bg-cyan-400"
                        style={{ width: `${targetDs.coverage.observedPercent ?? 0}%` }}
                      />
                      <div
                        className="h-full bg-amber-500/60"
                        style={{ width: `${targetDs.coverage.interpolatedOrEmptyPercent ?? 0}%` }}
                      />
                    </>
                  ) : (
                    <div
                      className="h-full bg-amber-400"
                      style={{ width: `${targetDs.coverage.validPercent ?? 95}%` }}
                    />
                  )}
                </div>
              </div>
            </div>
          </section>
        )}

        {aci && (aci.limitationsApplied.length > 0 || aci.explanation.length > 0) && (
          <section className="bg-[#090E1A] border border-amber-800/40 rounded-md p-5 space-y-2.5">
            <h3 className="text-sm font-semibold text-amber-300">
              Limitaciones aplicadas a esta comparación
            </h3>
            <ul className="space-y-1 text-xs text-slate-300 list-disc list-inside">
              {[...aci.limitationsApplied, ...aci.explanation].map((line, i) => (
                <li key={i}>{line}</li>
              ))}
            </ul>
          </section>
        )}
      </div>
    </div>
  );
}
