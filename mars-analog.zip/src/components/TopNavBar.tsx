import { ArrowLeft } from 'lucide-react';

export type WorkspaceTab = 'exploration' | 'comparison' | 'about';

interface TopNavBarProps {
  activeTab: WorkspaceTab;
  onSelectTab: (tab: WorkspaceTab) => void;
  onBack: () => void;
  canGoBack: boolean;
  onReturnWelcome: () => void;
}

const NAV_ITEMS: Array<{ id: WorkspaceTab; label: string }> = [
  { id: 'exploration', label: 'Exploración' },
  { id: 'comparison', label: 'Comparación' },
  { id: 'about', label: 'Limitaciones y Estado' },
];

export function TopNavBar({
  activeTab,
  onSelectTab,
  onBack,
  onReturnWelcome,
}: TopNavBarProps) {
  const primaryActionTab: WorkspaceTab =
    activeTab === 'comparison' ? 'exploration' : 'comparison';
  const primaryActionLabel =
    activeTab === 'comparison' ? 'Explorador 3D' : 'Comparar Análogos';

  return (
    <header className="h-14 px-5 border-b border-slate-800 bg-[#080C16] flex items-center justify-between gap-6 shrink-0 z-30">
      {/* Zona 1: Retroceder + Marca */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          type="button"
          onClick={onBack}
          title="Retroceder"
          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-200 bg-[#0D1424] border border-slate-800 rounded-md hover:border-cyan-500/60 hover:text-cyan-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-cyan-400"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Retroceder</span>
        </button>

        <button
          type="button"
          onClick={onReturnWelcome}
          className="font-display text-lg font-bold tracking-wider text-white hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-cyan-400"
        >
          NEXANALOG
        </button>
      </div>

      {/* Zona 2: Navegación */}
      <nav aria-label="Navegación principal" className="hidden md:flex items-center gap-7">
        {NAV_ITEMS.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectTab(item.id)}
              className={`py-1 text-sm font-medium transition-colors whitespace-nowrap shrink-0 border-b-2 cursor-pointer focus-visible:outline-2 focus-visible:outline-cyan-400 ${
                isActive
                  ? 'text-cyan-400 border-cyan-400'
                  : 'text-slate-300 border-transparent hover:text-white hover:border-slate-600'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </nav>

      {/* Zona 3: Acción principal */}
      <div className="flex items-center shrink-0">
        <button
          type="button"
          onClick={() => onSelectTab(primaryActionTab)}
          className="px-4 py-1.5 text-xs font-semibold tracking-wide bg-cyan-500 text-slate-950 rounded-md hover:bg-cyan-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-cyan-400"
        >
          {primaryActionLabel}
        </button>
      </div>
    </header>
  );
}
