import { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import type { RegionRecord } from '../shared/types';
import { GlobeViewport } from './GlobeViewport';

interface WelcomeScreenProps {
  regions: RegionRecord[];
  onEnterSystem: () => void;
}

const PROJECT_TEAM = [
  'Octavio Andrés Pereyra',
  'Cesar Martin Pereyra',
  'Danily Castro Navarro',
  'Fabricio Quiroz Montaño',
  'Warren Clarkson',
];

export function WelcomeScreen({ regions, onEnterSystem }: WelcomeScreenProps) {
  const [entering, setEntering] = useState(false);

  const handleEnter = () => {
    if (entering) return;
    setEntering(true);
    window.setTimeout(() => {
      onEnterSystem();
    }, 520);
  };

  return (
    <div
      className={`relative w-full min-h-screen overflow-hidden bg-[#060911] flex flex-col justify-between transition-opacity duration-500 ${
        entering ? 'opacity-0' : 'opacity-100'
      }`}
    >
      {/* Globo 3D interactivo de fondo */}
      <div className="absolute inset-0 z-0">
        <GlobeViewport
          body="earth"
          regions={regions}
          selectedRegionId="uyuni_25km"
          welcomeMode={true}
          enteringSystem={entering}
          showBoundary={true}
        />
      </div>

      {/* Velo de contraste */}
      <div
        aria-hidden="true"
        className="absolute inset-0 z-10 pointer-events-none bg-gradient-to-b from-[#060911]/80 via-[#060911]/45 to-[#060911]/95"
      />

      {/* Línea superior discreta */}
      <div className="relative z-20 px-6 md:px-12 pt-8 flex items-center justify-between text-xs text-slate-400 font-mono">
        <span>Plataforma de Análogos Topográficos Planetarios</span>
        <span>Tierra SRTMGL1 · Marte MOLA MEGDR · Luna LOLA (En preparación)</span>
      </div>

      {/* Ancla central */}
      <main className="relative z-20 flex-1 flex flex-col items-center justify-center px-6 text-center max-w-4xl mx-auto">
        <h1 className="font-display text-5xl sm:text-6xl md:text-7xl font-bold tracking-tight text-white text-balance">
          NEXANALOG
        </h1>
        <p className="mt-4 text-lg sm:text-xl text-slate-200 max-w-2xl font-normal leading-relaxed">
          Explorando análogos terrestres para la exploración planetaria
        </p>
        <p className="mt-2.5 text-sm text-slate-400 max-w-xl">
          Comparación topográfica 3D entre Tierra, Marte y Luna con procedencia y cobertura real.
        </p>

        <div className="mt-9">
          <button
            type="button"
            onClick={handleEnter}
            className="inline-flex items-center gap-3 px-7 py-3.5 text-sm font-semibold tracking-wider uppercase bg-cyan-500 text-slate-950 rounded-md hover:bg-cyan-400 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <span>ENTRAR AL SISTEMA DE EXPLORACIÓN</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </main>

      {/* Equipo del proyecto */}
      <footer className="relative z-20 px-6 md:px-12 pb-10 pt-6">
        <div className="max-w-5xl mx-auto border-t border-slate-800/90 pt-6">
          <div className="flex flex-col md:flex-row md:items-baseline justify-between gap-4">
            <h2 className="font-display text-xs font-semibold tracking-[0.18em] uppercase text-cyan-400 shrink-0">
              EQUIPO DEL PROYECTO
            </h2>
            <ul className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-x-6 gap-y-2 text-sm text-slate-200 flex-1">
              {PROJECT_TEAM.map((member) => (
                <li
                  key={member}
                  className="py-1 border-b border-slate-800/70 sm:border-b-0 font-normal"
                >
                  {member}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </footer>
    </div>
  );
}
