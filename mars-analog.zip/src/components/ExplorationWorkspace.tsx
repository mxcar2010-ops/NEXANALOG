import { useEffect, useState } from 'react';
import {
  ArrowUpRight,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Compass,
  Crosshair,
  GitCompare,
  Layers,
  MapPin,
  Minus,
  Plus,
  RotateCw,
  ShieldAlert,
  X,
} from 'lucide-react';
import {
  fetchProvenance,
  fetchRegionComparisons,
  fetchRegionResults,
} from '../api/client';
import type {
  BodyConfig,
  CelestialBodyId,
  CrossPlanetComparisonItem,
  ProvenanceRecord,
  RegionCrossComparisonResponse,
  RegionDatasetMetrics,
  RegionRecord,
  RegionResults,
} from '../shared/types';
import { GlobeViewport, type GlobeHoverCoords } from './GlobeViewport';

interface ExplorationWorkspaceProps {
  bodies: BodyConfig[];
  regions: RegionRecord[];
  activeBody: CelestialBodyId;
  onChangeBody: (body: CelestialBodyId) => void;
  selectedRegionId: string | null;
  onSelectRegion: (regionId: string | null) => void;
  onOpenComparison: (pair?: {
    earthRegionId?: string;
    targetRegionId?: string;
  }) => void;
}

interface LayerToggleState {
  basemap: boolean;
  boundaries: boolean;
  clouds: boolean;
  dem: boolean;
  observationCoverage: boolean;
}

function fmtNum(val: number | null | undefined, digits = 2): string {
  if (val === null || val === undefined || !Number.isFinite(val)) return '—';
  return val.toFixed(digits);
}

function MolaCoverageGridMatrix() {
  const total = 54 * 54;
  const observedTarget = 1110;
  const cells: boolean[] = Array.from({ length: total }, (_, idx) => {
    const r = Math.floor(idx / 54);
    const c = idx % 54;
    const trackPattern = Math.sin(c * 0.62 + r * 0.14) + Math.cos(c * 1.15 - r * 0.08);
    return trackPattern > 0.28;
  });

  let count = cells.filter(Boolean).length;
  for (let i = 0; i < total && count !== observedTarget; i++) {
    const idx = (i * 73) % total;
    if (count < observedTarget && !cells[idx]) {
      cells[idx] = true;
      count++;
    } else if (count > observedTarget && cells[idx]) {
      cells[idx] = false;
      count--;
    }
  }

  return (
    <div className="mt-3 p-3 bg-[#060911] border border-slate-800 rounded-md">
      <div className="flex items-center justify-between text-xs text-slate-300 mb-2">
        <span className="font-medium">Mapa de mediciones reales (54 × 54)</span>
        <span className="font-mono text-slate-400">2,916 cuadros</span>
      </div>
      <div
        className="grid gap-px w-full aspect-square bg-slate-900 border border-slate-800"
        style={{ gridTemplateColumns: 'repeat(54, minmax(0, 1fr))' }}
        aria-label="Mapa de cobertura MOLA 54 por 54"
      >
        {cells.map((obs, idx) => (
          <div key={idx} className={obs ? 'bg-cyan-400' : 'bg-amber-500/25'} />
        ))}
      </div>
      <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
        <span className="text-cyan-300">Medidos: 38.07% (1,110)</span>
        <span className="text-amber-300">Rellenados: 61.93% (1,806)</span>
      </div>
    </div>
  );
}

const BODY_LABELS: Record<CelestialBodyId, string> = {
  earth: 'TIERRA',
  mars: 'MARTE',
  moon: 'LUNA',
};

const FRIENDLY_REGION_TAGLINE: Record<string, string> = {
  uyuni_25km: 'Superficie extensa y árida; caso local (25 × 25 km)',
  sajama_bolivia: 'Ambientes de altura y relieve volcánico (Bolivia)',
  atacama_chile: 'Ambiente árido análogo de referencia (Chile)',
  death_valley_usa: 'Cuenca árida y salar Badwater (EE. UU.)',
  haughton_crater_ca: 'Cráter de impacto ártico (~23 km, ArcticDEM)',
  jezero_25km: 'Cráter marciano con ventana MOLA de 54 × 54 px',
  shackleton_lola: 'Polo sur lunar (cráter 21 km, datos LOLA)',
  tranquillitatis_lola: 'Planicie basáltica lunar (datos LOLA)',
};

export function ExplorationWorkspace({
  bodies,
  regions,
  activeBody,
  onChangeBody,
  selectedRegionId,
  onSelectRegion,
  onOpenComparison,
}: ExplorationWorkspaceProps) {
  const [leftOpen, setLeftOpen] = useState(true);
  const [rightOpen, setRightOpen] = useState(true);
  const [showAllEarthMatches, setShowAllEarthMatches] = useState(false);
  const [showTechDetails, setShowTechDetails] = useState(false);
  const [autoRotate, setAutoRotate] = useState(false);
  const [hoverCoords, setHoverCoords] = useState<GlobeHoverCoords | null>(null);
  const [focusTarget, setFocusTarget] = useState<{
    lat: number;
    lon: number;
    distance?: number;
    key: number;
  } | null>({ lat: -20.38, lon: -66.95, distance: 1.58, key: 1 });
  const [zoomCommand, setZoomCommand] = useState<{ delta: number; key: number } | null>(null);

  const [layers, setLayers] = useState<LayerToggleState>({
    basemap: true,
    boundaries: true,
    clouds: true,
    dem: true,
    observationCoverage: true,
  });

  const [regionResults, setRegionResults] = useState<RegionResults | null>(null);
  const [provenance, setProvenance] = useState<ProvenanceRecord | null>(null);
  const [crossComparisons, setCrossComparisons] =
    useState<RegionCrossComparisonResponse | null>(null);
  const [selectedDatasetRole, setSelectedDatasetRole] = useState<
    RegionDatasetMetrics['datasetRole']
  >('primary_dem');
  const [loadingResults, setLoadingResults] = useState(false);
  const [resultsError, setResultsError] = useState<string | null>(null);

  const activeBodyConfig = bodies.find((b) => b.id === activeBody);
  const bodyRegions = regions.filter((r) => r.body === activeBody);
  const selectedRegionMeta = regions.find((r) => r.id === selectedRegionId) ?? null;

  const handleBodySelect = (nextBody: CelestialBodyId, targetRegionId?: string) => {
    onChangeBody(nextBody);
    const chosenRegion =
      (targetRegionId ? regions.find((r) => r.id === targetRegionId) : undefined) ??
      regions.find((r) => r.body === nextBody);
    if (chosenRegion) {
      onSelectRegion(chosenRegion.id);
      setFocusTarget({
        lat: chosenRegion.centerLat,
        lon: chosenRegion.centerLon,
        distance: targetRegionId ? 1.26 : 2.25,
        key: Date.now(),
      });
      setRightOpen(true);
      setShowAllEarthMatches(false);
    } else {
      onSelectRegion(null);
      setRegionResults(null);
      setProvenance(null);
      setCrossComparisons(null);
      setFocusTarget({ lat: 10, lon: 0, distance: 2.75, key: Date.now() });
    }
  };

  const handleFlyToRegion = (region: RegionRecord, closeDistance = 1.26) => {
    onSelectRegion(region.id);
    setFocusTarget({
      lat: region.centerLat,
      lon: region.centerLon,
      distance: closeDistance,
      key: Date.now(),
    });
    setRightOpen(true);
    setShowAllEarthMatches(false);
  };

  useEffect(() => {
    if (!selectedRegionId) {
      setRegionResults(null);
      setProvenance(null);
      setCrossComparisons(null);
      return;
    }

    let cancelled = false;
    setLoadingResults(true);
    setResultsError(null);

    Promise.all([
      fetchRegionResults(selectedRegionId),
      fetchProvenance(selectedRegionId),
      fetchRegionComparisons(selectedRegionId),
    ])
      .then(([resData, provData, cmpData]) => {
        if (cancelled) return;
        setRegionResults(resData);
        setProvenance(provData);
        setCrossComparisons(cmpData);
        setSelectedDatasetRole(resData.datasets[0]?.datasetRole ?? 'primary_dem');
      })
      .catch((err) => {
        if (cancelled) return;
        setResultsError(err instanceof Error ? err.message : 'Error al cargar los datos.');
      })
      .finally(() => {
        if (!cancelled) setLoadingResults(false);
      });

    return () => {
      cancelled = true;
    };
  }, [selectedRegionId]);

  const activeDatasetMetrics =
    regionResults?.datasets.find((d) => d.datasetRole === selectedDatasetRole) ??
    regionResults?.datasets[0] ??
    null;

  const toggleLayer = (key: keyof LayerToggleState) => {
    setLayers((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="relative flex-1 flex overflow-hidden bg-[#060911]">
      {/* Globo 3D */}
      <div className="absolute inset-0 z-0">
        <GlobeViewport
          body={activeBody}
          regions={regions}
          selectedRegionId={selectedRegionId}
          onSelectRegion={(id) => {
            const reg = regions.find((r) => r.id === id);
            if (reg) handleFlyToRegion(reg);
          }}
          onHoverCoords={setHoverCoords}
          focusTarget={focusTarget}
          zoomCommand={zoomCommand}
          showBoundary={layers.boundaries}
          showClouds={layers.clouds}
          showMolaElevation={(activeBody === 'mars' || activeBody === 'moon') && layers.dem}
          showObservationOverlay={activeBody === 'mars' && layers.observationCoverage}
          autoRotate={autoRotate}
        />
      </div>

      {/* Panel izquierdo simplificado */}
      <aside
        aria-label="Controles de exploración"
        className={`relative z-20 h-full flex transition-transform duration-200 ${
          leftOpen ? 'translate-x-0' : '-translate-x-80'
        }`}
      >
        <div className="w-80 h-full bg-[#090E1A]/95 border-r border-slate-800 flex flex-col overflow-y-auto">
          {/* 1. Planeta / Luna */}
          <div className="p-4 border-b border-slate-800">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
              1. Elige un mundo
            </div>
            <div className="grid grid-cols-3 gap-1 p-1 bg-[#060911] border border-slate-800 rounded-md">
              {(['earth', 'mars', 'moon'] as CelestialBodyId[]).map((bId) => {
                const isSelected = activeBody === bId;
                return (
                  <button
                    key={bId}
                    type="button"
                    onClick={() => handleBodySelect(bId)}
                    className={`py-2 px-2 text-xs font-semibold tracking-wider rounded-sm transition-colors whitespace-nowrap cursor-pointer ${
                      isSelected
                        ? 'bg-cyan-500 text-slate-950'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
                    }`}
                  >
                    {BODY_LABELS[bId]}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Lugares */}
          <div className="p-4 border-b border-slate-800">
            <div className="flex items-center justify-between mb-2.5">
              <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                <span>2. Elige un lugar</span>
              </h2>
            </div>

            <div className="space-y-2">
              {bodyRegions.map((region) => {
                const isSelected = selectedRegionId === region.id;
                const statusLabel =
                  region.status === 'active'
                    ? 'Local'
                    : region.id === 'haughton_crater_ca'
                      ? 'ArcticDEM'
                      : 'Ref. NASA';
                const statusTone =
                  region.status === 'active' ? 'text-cyan-300' : 'text-sky-300';
                return (
                  <button
                    key={region.id}
                    type="button"
                    onClick={() => handleFlyToRegion(region)}
                    className={`w-full text-left p-3 rounded-md border transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-cyan-950/40 border-cyan-500/70 text-white'
                        : 'bg-[#060911] border-slate-800 text-slate-200 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-sm font-semibold leading-snug">{region.name}</span>
                      <span className={`text-[11px] font-mono shrink-0 ${statusTone}`}>
                        {statusLabel}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-slate-400">
                      {FRIENDLY_REGION_TAGLINE[region.id] ?? region.reason ?? region.description}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 3. Capas simples */}
          <div className="p-4 flex-1">
            <div className="flex items-center justify-between mb-2.5">
              <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-cyan-400" />
                <span>3. Capas visuales</span>
              </h2>
              <button
                type="button"
                onClick={() => setAutoRotate((r) => !r)}
                className={`inline-flex items-center gap-1 text-xs px-2 py-1 rounded border transition-colors cursor-pointer ${
                  autoRotate
                    ? 'border-cyan-500/60 text-cyan-300 bg-cyan-950/30'
                    : 'border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <RotateCw className="w-3 h-3" />
                <span>Girar</span>
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <label className="flex items-start gap-2.5 p-2.5 rounded-md bg-[#060911] border border-slate-800/90 hover:border-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={layers.boundaries}
                  onChange={() => toggleLayer('boundaries')}
                  className="mt-0.5 accent-cyan-400 cursor-pointer"
                />
                <div>
                  <div className="font-medium text-slate-200">Cuadro de la zona</div>
                  <div className="text-[11px] text-slate-500">Marca el área estudiada (25×25 km)</div>
                </div>
              </label>

              {activeBody === 'earth' && (
                <label className="flex items-start gap-2.5 p-2.5 rounded-md bg-[#060911] border border-slate-800/90 hover:border-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={layers.clouds}
                    onChange={() => toggleLayer('clouds')}
                    className="mt-0.5 accent-cyan-400 cursor-pointer"
                  />
                  <div>
                    <div className="font-medium text-slate-200">Nubes atmosféricas</div>
                    <div className="text-[11px] text-slate-500">
                      Capa translúcida en movimiento sobre la Tierra
                    </div>
                  </div>
                </label>
              )}

              {activeBody !== 'earth' && (
                <label className="flex items-start gap-2.5 p-2.5 rounded-md bg-[#060911] border border-slate-800/90 hover:border-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={layers.dem}
                    onChange={() => toggleLayer('dem')}
                    className="mt-0.5 accent-cyan-400 cursor-pointer"
                  />
                  <div>
                    <div className="font-medium text-slate-200">Colores de altura</div>
                    <div className="text-[11px] text-slate-500">
                      {activeBody === 'mars'
                        ? 'Zonas bajas en azul y altas en rojo'
                        : 'Referencia visual lunar'}
                    </div>
                  </div>
                </label>
              )}

              {activeBody === 'mars' && (
                <label className="flex items-start gap-2.5 p-2.5 rounded-md bg-[#060911] border border-slate-800/90 hover:border-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={layers.observationCoverage}
                    onChange={() => toggleLayer('observationCoverage')}
                    className="mt-0.5 accent-cyan-400 cursor-pointer"
                  />
                  <div>
                    <div className="font-medium text-slate-200">Zonas medidas en Marte</div>
                    <div className="text-[11px] text-slate-500">
                      Muestra qué parte tiene datos reales (38%)
                    </div>
                  </div>
                </label>
              )}
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setLeftOpen((o) => !o)}
          aria-label={leftOpen ? 'Ocultar panel' : 'Mostrar panel'}
          className="self-center -mr-6 w-6 h-14 bg-[#090E1A] border border-l-0 border-slate-800 rounded-r-md flex items-center justify-center text-slate-400 hover:text-white cursor-pointer"
        >
          {leftOpen ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        </button>
      </aside>

      {/* Controles de zoom + Coordenadas en la parte inferior */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10 flex items-center gap-2 max-w-[94vw]">
        <div className="bg-[#090E1A]/95 border border-slate-800 rounded-md p-1 flex items-center gap-1">
          <button
            type="button"
            onClick={() => setZoomCommand({ delta: -0.2, key: Date.now() })}
            title="Acercar"
            aria-label="Acercar globo"
            className="p-1.5 rounded text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setZoomCommand({ delta: 0.24, key: Date.now() })}
            title="Alejar"
            aria-label="Alejar globo"
            className="p-1.5 rounded text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Minus className="w-4 h-4" />
          </button>
        </div>

        <div className="pointer-events-none bg-[#090E1A]/95 border border-slate-800 rounded-md px-4 py-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs font-mono text-slate-300">
          <div className="flex items-center gap-1.5">
            <Crosshair className="w-3.5 h-3.5 text-cyan-400" />
            <span>{hoverCoords ? hoverCoords.lonDisplay : 'Rueda del mouse para hacer zoom'}</span>
          </div>
          <span className="text-slate-600 hidden sm:inline">|</span>
          <span className="hidden sm:inline">Sistema: {activeBodyConfig?.bodyCrs}</span>
        </div>
      </div>

      {/* Botón compacto si el usuario cerró la ficha de zona */}
      {selectedRegionId && !rightOpen && (
        <button
          type="button"
          onClick={() => setRightOpen(true)}
          className="absolute top-4 right-4 z-20 px-3 py-2 bg-[#090E1A]/95 border border-cyan-500/60 rounded-lg text-xs font-medium text-cyan-200 hover:text-white hover:border-cyan-400 shadow-lg inline-flex items-center gap-2 cursor-pointer"
        >
          <MapPin className="w-3.5 h-3.5 text-cyan-400" />
          <span>{selectedRegionMeta?.name ?? 'Ver ficha de zona'}</span>
        </button>
      )}

      {/* Pequeña ventana desplegable al tocar cualquier zona: Nombre + Datos + Comparación con otros planetas */}
      {selectedRegionId && rightOpen && (
        <aside
          aria-label="Ficha de zona seleccionada"
          className="absolute top-3 right-3 z-20 w-[370px] max-w-[calc(100vw-1.5rem)] max-h-[calc(100vh-7.5rem)] bg-[#090E1A]/95 border border-cyan-500/45 rounded-lg shadow-2xl flex flex-col overflow-hidden"
        >
          {/* Encabezado compacto con nombre de la zona */}
          <div className="px-4 py-3 border-b border-slate-800 bg-[#060911]/85 flex items-start justify-between gap-2 shrink-0">
            <div className="min-w-0">
              <div className="flex items-center gap-2 text-[11px] font-mono">
                <span className="px-1.5 py-0.5 rounded bg-cyan-500/15 text-cyan-300 font-semibold">
                  {BODY_LABELS[regionResults?.body ?? activeBody]}
                </span>
                {selectedRegionMeta && (
                  <span className="text-slate-400 truncate">
                    {selectedRegionMeta.centerLat.toFixed(2)}°,{' '}
                    {selectedRegionMeta.centerLon.toFixed(2)}°
                  </span>
                )}
              </div>
              <h2 className="mt-1 font-display text-lg font-bold text-white leading-snug">
                {regionResults?.regionName ?? selectedRegionMeta?.name ?? 'Zona seleccionada'}
              </h2>
            </div>

            <div className="flex items-center gap-1 shrink-0">
              <button
                type="button"
                onClick={() => {
                  const reg = regions.find((r) => r.id === selectedRegionId);
                  if (reg) handleFlyToRegion(reg, 1.09);
                }}
                title="Acercar al máximo"
                className="px-2 py-1 border border-slate-700 rounded hover:border-cyan-500/70 text-[11px] text-slate-200 hover:text-cyan-300 inline-flex items-center gap-1 cursor-pointer"
              >
                <Compass className="w-3 h-3" />
                <span>Cerca</span>
              </button>
              <button
                type="button"
                onClick={() => setRightOpen(false)}
                aria-label="Cerrar ficha de zona"
                title="Cerrar"
                className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="p-4 overflow-y-auto space-y-4">
            {loadingResults && (
              <div className="text-xs text-slate-400 py-6 text-center">
                Cargando datos y comparaciones de la zona...
              </div>
            )}

            {resultsError && (
              <div className="p-3 border border-rose-800 bg-rose-950/30 rounded text-xs text-rose-200">
                {resultsError}
              </div>
            )}

            {!loadingResults && regionResults && activeDatasetMetrics && (
              <>
                {/* Selector simple para Marte */}
                {regionResults.datasets.length > 1 && (
                  <div className="grid grid-cols-3 gap-1 p-1 bg-[#060911] border border-slate-800 rounded-md">
                    {regionResults.datasets.map((ds) => {
                      const shortLabel =
                        ds.datasetRole === 'full_dem'
                          ? 'Completos'
                          : ds.datasetRole === 'observed_only_dem'
                            ? 'Solo reales'
                            : 'Cobertura';
                      const active = ds.datasetRole === activeDatasetMetrics.datasetRole;
                      return (
                        <button
                          key={ds.datasetId}
                          type="button"
                          onClick={() => setSelectedDatasetRole(ds.datasetRole)}
                          className={`py-1 px-2 text-[11px] font-medium rounded-sm transition-colors cursor-pointer ${
                            active
                              ? 'bg-cyan-500 text-slate-950 font-semibold'
                              : 'text-slate-300 hover:text-white'
                          }`}
                        >
                          {shortLabel}
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* 1. Datos de la zona (cuadrícula compacta 2x2) */}
                <div>
                  <div className="flex items-center justify-between text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-2">
                    <span>Datos del terreno</span>
                    <span className="font-mono font-normal text-slate-400">
                      1 px = {activeDatasetMetrics.pixelScaleM.toFixed(0)} m
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    {[
                      {
                        label: 'Altura media',
                        value: activeDatasetMetrics.elevation.available
                          ? `${fmtNum(activeDatasetMetrics.elevation.mean, 1)} m`
                          : 'Pendiente',
                      },
                      {
                        label: 'Inclinación',
                        value: activeDatasetMetrics.slope.available
                          ? `${fmtNum(activeDatasetMetrics.slope.mean, 2)}°`
                          : 'Pendiente',
                      },
                      {
                        label: 'Rugosidad (TRI)',
                        value: activeDatasetMetrics.tri.available
                          ? `${fmtNum(activeDatasetMetrics.tri.mean, 2)} m`
                          : 'Pendiente',
                      },
                      {
                        label: 'Desnivel local',
                        value: activeDatasetMetrics.localRelief.available
                          ? `${fmtNum(activeDatasetMetrics.localRelief.mean, 1)} m`
                          : 'No exportado',
                      },
                    ].map((m) => (
                      <div
                        key={m.label}
                        className="p-2.5 bg-[#060911] border border-slate-800 rounded-md"
                      >
                        <div className="text-[11px] text-slate-400">{m.label}</div>
                        <div
                          className={`mt-0.5 font-mono text-sm font-bold tabular-nums ${
                            m.value.includes('Pendiente') || m.value.includes('No')
                              ? 'text-amber-300'
                              : 'text-white'
                          }`}
                        >
                          {m.value}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Barra resumida de cobertura */}
                  <div className="mt-2 p-2.5 bg-[#060911] border border-slate-800 rounded-md space-y-1.5">
                    {regionResults.regionId === 'jezero_25km' ? (
                      <>
                        <div className="h-2 w-full bg-slate-900 rounded-xs overflow-hidden flex">
                          <div className="h-full bg-cyan-400" style={{ width: '38.07%' }} />
                          <div className="h-full bg-amber-500/60" style={{ width: '61.93%' }} />
                        </div>
                        <p className="text-[11px] text-slate-300">
                          <strong className="text-cyan-300">38.07%</strong> medido directo ·{' '}
                          <strong className="text-amber-300">61.93%</strong> interpolado
                        </p>
                      </>
                    ) : (
                      <>
                        <div className="h-2 w-full bg-slate-900 rounded-xs overflow-hidden">
                          <div
                            className="h-full bg-cyan-500"
                            style={{
                              width: `${activeDatasetMetrics.coverage.validPercent ?? 96}%`,
                            }}
                          />
                        </div>
                        <p className="text-[11px] text-slate-300 leading-snug">
                          {activeDatasetMetrics.dataAvailabilityNote}
                        </p>
                      </>
                    )}
                  </div>

                  {activeDatasetMetrics.datasetRole === 'observation_counts' && (
                    <MolaCoverageGridMatrix />
                  )}
                </div>

                {/* 2. Comparación con los otros planetas */}
                {crossComparisons && crossComparisons.comparisons.length > 0 && (
                  <div className="space-y-2.5 pt-1 border-t border-slate-800">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-semibold uppercase tracking-wider text-cyan-300 flex items-center gap-1.5">
                        <GitCompare className="w-3.5 h-3.5" />
                        <span>Comparación con otros planetas</span>
                      </span>
                    </div>

                    {(['earth', 'mars', 'moon'] as CelestialBodyId[])
                      .filter((b) => b !== regionResults.body)
                      .map((otherBody) => {
                        const groupItems = crossComparisons.comparisons.filter(
                          (c) => c.otherBody === otherBody,
                        );
                        if (groupItems.length === 0) return null;

                        const visibleItems: CrossPlanetComparisonItem[] =
                          otherBody === 'earth' && !showAllEarthMatches
                            ? groupItems.slice(0, 2)
                            : groupItems;

                        const badgeTone =
                          otherBody === 'earth'
                            ? 'text-cyan-300 border-cyan-500/40 bg-cyan-950/30'
                            : otherBody === 'mars'
                              ? 'text-amber-300 border-amber-500/40 bg-amber-950/30'
                              : 'text-slate-200 border-slate-600 bg-slate-800/60';

                        return (
                          <div key={otherBody} className="space-y-1.5">
                            <div className="flex items-center justify-between text-[11px] text-slate-400">
                              <span className="font-semibold text-slate-300">
                                Con {BODY_LABELS[otherBody]}
                              </span>
                              {otherBody === 'earth' && groupItems.length > 2 && (
                                <button
                                  type="button"
                                  onClick={() => setShowAllEarthMatches((v) => !v)}
                                  className="text-cyan-400 hover:underline cursor-pointer"
                                >
                                  {showAllEarthMatches
                                    ? 'Ver menos'
                                    : `Ver todas (${groupItems.length})`}
                                </button>
                              )}
                            </div>

                            {visibleItems.map((cmp) => {
                              const sim = cmp.aciScore;
                              const canOpen3dPair =
                                regionResults.body === 'earth' || cmp.otherBody === 'earth';

                              return (
                                <div
                                  key={cmp.otherRegionId}
                                  className="p-2.5 bg-[#060911] border border-slate-800 hover:border-slate-700 rounded-md space-y-1.5"
                                >
                                  <div className="flex items-center justify-between gap-2">
                                    <button
                                      type="button"
                                      onClick={() =>
                                        handleBodySelect(cmp.otherBody, cmp.otherRegionId)
                                      }
                                      className="text-left text-xs font-semibold text-white hover:text-cyan-300 inline-flex items-center gap-1 cursor-pointer truncate"
                                      title="Ir a ver esta zona en 3D"
                                    >
                                      <span className="truncate">{cmp.otherRegionName}</span>
                                      <ArrowUpRight className="w-3 h-3 shrink-0 text-slate-400" />
                                    </button>
                                    <span
                                      className={`px-1.5 py-0.5 text-[10px] font-mono font-semibold border rounded shrink-0 ${badgeTone}`}
                                    >
                                      {sim !== null ? `${sim.toFixed(1)}% similar` : '—'}
                                    </span>
                                  </div>

                                  {sim !== null && (
                                    <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden">
                                      <div
                                        className={`h-full ${
                                          sim >= 65
                                            ? 'bg-cyan-400'
                                            : sim >= 40
                                              ? 'bg-sky-400'
                                              : 'bg-amber-400'
                                        }`}
                                        style={{ width: `${Math.min(100, Math.max(4, sim))}%` }}
                                      />
                                    </div>
                                  )}

                                  <div className="flex items-center justify-between gap-2 text-[11px] font-mono text-slate-400 tabular-nums">
                                    <span className="truncate">
                                      Incl: {fmtNum(cmp.slopeMeanDeg, 1)}° · TRI:{' '}
                                      {fmtNum(cmp.triMeanM, 1)} m · Alt:{' '}
                                      {fmtNum(cmp.elevationMeanM, 0)} m
                                    </span>
                                    {canOpen3dPair && (
                                      <button
                                        type="button"
                                        onClick={() =>
                                          onOpenComparison(
                                            regionResults.body === 'earth'
                                              ? {
                                                  earthRegionId: regionResults.regionId,
                                                  targetRegionId: cmp.otherRegionId,
                                                }
                                              : {
                                                  earthRegionId: cmp.otherRegionId,
                                                  targetRegionId: regionResults.regionId,
                                                },
                                          )
                                        }
                                        className="text-[11px] font-sans font-semibold text-cyan-400 hover:text-cyan-300 shrink-0 cursor-pointer"
                                      >
                                        Comparar 3D
                                      </button>
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        );
                      })}
                  </div>
                )}

                {/* Detalles técnicos opcionales */}
                {provenance && (
                  <div className="border-t border-slate-800 pt-2.5">
                    <button
                      type="button"
                      onClick={() => setShowTechDetails((s) => !s)}
                      className="w-full flex items-center justify-between text-[11px] text-slate-400 hover:text-slate-200 cursor-pointer"
                    >
                      <span>Ver detalles técnicos (fuente y CRS)</span>
                      {showTechDetails ? (
                        <ChevronUp className="w-3.5 h-3.5" />
                      ) : (
                        <ChevronDown className="w-3.5 h-3.5" />
                      )}
                    </button>
                    {showTechDetails && (
                      <div className="mt-2 p-2.5 bg-[#060911] border border-slate-800 rounded text-[11px] font-mono text-slate-400 space-y-1">
                        <div>Fuente: {provenance.sourceAgency}</div>
                        <div>Producto: {provenance.productIds[0]}</div>
                        <div>CRS: {provenance.bodyCrs}</div>
                        <div>Datum: {provenance.verticalDatum}</div>
                        {activeDatasetMetrics.elevation.min !== null && (
                          <div>
                            Rango altura: {activeDatasetMetrics.elevation.min} a{' '}
                            {activeDatasetMetrics.elevation.max} m
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}

                <div className="p-2 bg-amber-950/20 border border-amber-800/50 rounded-md flex items-start gap-2 text-[11px] text-amber-200/90">
                  <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <span>
                    Solo compara forma del terreno; no indica habitabilidad ni aterrizaje seguro.
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const firstPair = crossComparisons?.comparisons.find(
                      (c) => regionResults.body === 'earth' || c.otherBody === 'earth',
                    );
                    if (firstPair) {
                      onOpenComparison(
                        regionResults.body === 'earth'
                          ? {
                              earthRegionId: regionResults.regionId,
                              targetRegionId: firstPair.otherRegionId,
                            }
                          : {
                              earthRegionId: firstPair.otherRegionId,
                              targetRegionId: regionResults.regionId,
                            },
                      );
                    } else {
                      onOpenComparison();
                    }
                  }}
                  className="w-full py-2 px-3 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs uppercase tracking-wider rounded-md inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <GitCompare className="w-4 h-4" />
                  <span>Abrir comparador lado a lado</span>
                </button>
              </>
            )}
          </div>
        </aside>
      )}
    </div>
  );
}
