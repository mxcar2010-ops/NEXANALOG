import type {
  AciRequest,
  AciResult,
  BodyConfig,
  CelestialBodyId,
  DatasetRecord,
  HealthResponse,
  LimitationItem,
  ProjectTaskItem,
  ProvenanceRecord,
  RegionCrossComparisonResponse,
  RegionRecord,
  RegionResults,
} from '../shared/types';

const API_BASE = '/api/v1';

async function getJson<T>(path: string): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`);
  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`API ${path} failed (${response.status}): ${errText}`);
  }
  return response.json() as Promise<T>;
}

export async function fetchHealth(): Promise<HealthResponse> {
  return getJson<HealthResponse>('/health');
}

export async function fetchBodies(): Promise<BodyConfig[]> {
  const data = await getJson<{ bodies: BodyConfig[] }>('/bodies');
  return data.bodies;
}

export async function fetchDatasets(body?: CelestialBodyId): Promise<DatasetRecord[]> {
  const query = body ? `?body=${encodeURIComponent(body)}` : '';
  const data = await getJson<{ datasets: DatasetRecord[] }>(`/datasets${query}`);
  return data.datasets;
}

export async function fetchRegions(body?: CelestialBodyId): Promise<RegionRecord[]> {
  const query = body ? `?body=${encodeURIComponent(body)}` : '';
  const data = await getJson<{ regions: RegionRecord[] }>(`/regions${query}`);
  return data.regions;
}

export async function fetchAllResults(): Promise<RegionResults[]> {
  const data = await getJson<{ results: RegionResults[] }>('/results');
  return data.results;
}

export async function fetchRegionResults(regionId: string): Promise<RegionResults> {
  return getJson<RegionResults>(`/results/${encodeURIComponent(regionId)}`);
}

export async function fetchProvenance(regionId: string): Promise<ProvenanceRecord> {
  return getJson<ProvenanceRecord>(`/provenance/${encodeURIComponent(regionId)}`);
}

export async function fetchLimitations(body?: CelestialBodyId): Promise<LimitationItem[]> {
  const query = body ? `?body=${encodeURIComponent(body)}` : '';
  const data = await getJson<{ limitations: LimitationItem[] }>(`/limitations${query}`);
  return data.limitations;
}

export async function fetchProjectStatus(): Promise<{
  tasks: ProjectTaskItem[];
  rawGeoTiffMounted: boolean;
}> {
  return getJson<{ tasks: ProjectTaskItem[]; rawGeoTiffMounted: boolean }>('/project-status');
}

export async function computeAciComparison(request: AciRequest): Promise<AciResult> {
  const response = await fetch(`${API_BASE}/aci/compare`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(request),
  });
  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`ACI compute failed (${response.status}): ${errText}`);
  }
  return response.json() as Promise<AciResult>;
}

export async function fetchRegionComparisons(
  regionId: string,
): Promise<RegionCrossComparisonResponse> {
  return getJson<RegionCrossComparisonResponse>(
    `/regions/${encodeURIComponent(regionId)}/comparisons`,
  );
}

