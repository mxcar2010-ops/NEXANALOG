import { useEffect, useState } from 'react';
import { fetchBodies, fetchRegions } from './api/client';
import { AboutWorkspace } from './components/AboutWorkspace';
import { ComparisonWorkspace } from './components/ComparisonWorkspace';
import { ExplorationWorkspace } from './components/ExplorationWorkspace';
import { TopNavBar, type WorkspaceTab } from './components/TopNavBar';
import { WelcomeScreen } from './components/WelcomeScreen';
import type { BodyConfig, CelestialBodyId, RegionRecord } from './shared/types';

interface NavSnapshot {
  tab: WorkspaceTab;
  body: CelestialBodyId;
  regionId: string | null;
}

export default function App() {
  const [enteredSystem, setEnteredSystem] = useState(false);
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('exploration');
  const [activeBody, setActiveBody] = useState<CelestialBodyId>('earth');
  const [selectedRegionId, setSelectedRegionId] = useState<string | null>('uyuni_25km');
  const [comparisonPair, setComparisonPair] = useState<{
    earthRegionId: string;
    targetRegionId: string;
  }>({ earthRegionId: 'uyuni_25km', targetRegionId: 'jezero_25km' });
  const [history, setHistory] = useState<NavSnapshot[]>([]);

  const [bodies, setBodies] = useState<BodyConfig[]>([]);
  const [regions, setRegions] = useState<RegionRecord[]>([]);
  const [bootError, setBootError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    Promise.all([fetchBodies(), fetchRegions()])
      .then(([bodyList, regionList]) => {
        if (cancelled) return;
        setBodies(bodyList);
        setRegions(regionList);
      })
      .catch((err) => {
        if (cancelled) return;
        setBootError(err instanceof Error ? err.message : 'Error al conectar con /api/v1.');
      });

    return () => {
      cancelled = true;
    };
  }, []);

  const pushHistory = () => {
    setHistory((prev) => [
      ...prev.slice(-19),
      { tab: activeTab, body: activeBody, regionId: selectedRegionId },
    ]);
  };

  const handleSelectTab = (nextTab: WorkspaceTab) => {
    if (nextTab === activeTab) return;
    pushHistory();
    setActiveTab(nextTab);
  };

  const handleChangeBody = (nextBody: CelestialBodyId) => {
    if (nextBody === activeBody) return;
    pushHistory();
    setActiveBody(nextBody);
  };

  const handleOpenComparison = (pair?: {
    earthRegionId?: string;
    targetRegionId?: string;
  }) => {
    setComparisonPair((prev) => ({
      earthRegionId: pair?.earthRegionId ?? prev.earthRegionId,
      targetRegionId: pair?.targetRegionId ?? prev.targetRegionId,
    }));
    handleSelectTab('comparison');
  };

  const handleBack = () => {
    if (history.length > 0) {
      const prev = history[history.length - 1];
      setHistory((h) => h.slice(0, -1));
      setActiveTab(prev.tab);
      setActiveBody(prev.body);
      setSelectedRegionId(prev.regionId);
    } else {
      setEnteredSystem(false);
    }
  };

  if (!enteredSystem) {
    return (
      <WelcomeScreen
        regions={regions}
        onEnterSystem={() => setEnteredSystem(true)}
      />
    );
  }

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden bg-[#060911] text-slate-100">
      <TopNavBar
        activeTab={activeTab}
        onSelectTab={handleSelectTab}
        onBack={handleBack}
        canGoBack={true}
        onReturnWelcome={() => setEnteredSystem(false)}
      />

      {/* Navegación móvil */}
      <div className="md:hidden flex items-center gap-1 px-4 py-2 border-b border-slate-800 bg-[#090E1A] overflow-x-auto shrink-0">
        {(
          [
            { id: 'exploration', label: 'Exploración' },
            { id: 'comparison', label: 'Comparación' },
            { id: 'about', label: 'Limitaciones y Estado' },
          ] as Array<{ id: WorkspaceTab; label: string }>
        ).map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => handleSelectTab(t.id)}
            className={`px-3 py-1.5 text-xs font-medium rounded-sm whitespace-nowrap cursor-pointer ${
              activeTab === t.id
                ? 'bg-cyan-500 text-slate-950 font-semibold'
                : 'text-slate-300'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {bootError && (
        <div className="px-6 py-2.5 bg-rose-950/50 border-b border-rose-800 text-xs text-rose-200">
          Error de API Backend: {bootError}
        </div>
      )}

      {activeTab === 'exploration' && (
        <ExplorationWorkspace
          bodies={bodies}
          regions={regions}
          activeBody={activeBody}
          onChangeBody={handleChangeBody}
          selectedRegionId={selectedRegionId}
          onSelectRegion={setSelectedRegionId}
          onOpenComparison={handleOpenComparison}
        />
      )}

      {activeTab === 'comparison' && (
        <ComparisonWorkspace
          regions={regions}
          initialEarthRegionId={comparisonPair.earthRegionId}
          initialTargetRegionId={comparisonPair.targetRegionId}
        />
      )}

      {activeTab === 'about' && <AboutWorkspace />}
    </div>
  );
}
