import * as THREE from 'three';
import type { RegionRecord } from '../shared/types';
import { latLonToVector3 } from './planetaryTextures';

const GLOBE_RADIUS = 1.0;

// Deterministic 2D hash & FBM for regional 3D heightfields and textures
function hash2(ix: number, iy: number, seed: number): number {
  let h = (ix * 374761393 + iy * 668265263 + seed * 1597334677) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967295;
}

function smooth(t: number): number {
  return t * t * (3 - 2 * t);
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

function noise2(x: number, y: number, seed: number): number {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = smooth(x - ix);
  const fy = smooth(y - iy);
  const a = hash2(ix, iy, seed);
  const b = hash2(ix + 1, iy, seed);
  const c = hash2(ix, iy + 1, seed);
  const d = hash2(ix + 1, iy + 1, seed);
  return lerp(lerp(a, b, fx), lerp(c, d, fx), fy);
}

function fbm2(x: number, y: number, seed: number, octaves = 5): number {
  let sum = 0;
  let amp = 0.5;
  let freq = 1;
  let norm = 0;
  for (let o = 0; o < octaves; o++) {
    sum += amp * noise2(x * freq, y * freq, seed + o * 41);
    norm += amp;
    amp *= 0.5;
    freq *= 2.05;
  }
  return sum / norm;
}

function ridged2(x: number, y: number, seed: number, octaves = 4): number {
  let sum = 0;
  let amp = 0.5;
  let freq = 1;
  let norm = 0;
  for (let o = 0; o < octaves; o++) {
    const n = noise2(x * freq, y * freq, seed + o * 59);
    const r = 1 - Math.abs(n * 2 - 1);
    sum += amp * r * r;
    norm += amp;
    amp *= 0.5;
    freq *= 2.1;
  }
  return sum / norm;
}

/**
 * Smooth edge feathering mask (1 in center, 0 cleanly at border).
 */
function edgeMask(nx: number, ny: number): number {
  const r = Math.hypot(nx, ny);
  if (r >= 0.98) return 0;
  if (r <= 0.68) return 1;
  const t = (r - 0.68) / (0.98 - 0.68);
  return 1 - t * t * (3 - 2 * t);
}

/**
 * Computes normalized height in [-1, +1] for each study region at local coordinates nx, ny in [-1, 1].
 */
function evaluateRegionHeight(regionId: string, nx: number, ny: number): number {
  const r = Math.hypot(nx, ny);
  const ang = Math.atan2(ny, nx);
  const mask = edgeMask(nx, ny);
  if (mask <= 0) return 0;

  let h = 0;

  switch (regionId) {
    case 'uyuni_25km': {
      // Vast ultra-flat salt pan with subtle Andean shoreline foothills at edges & Isla Incahuasi rock spire
      const micro = (fbm2(nx * 10 + 4, ny * 10 + 4, 101, 4) - 0.5) * 0.08;
      const incahuasi = Math.exp(-((nx + 0.14) ** 2 + (ny - 0.08) ** 2) / 0.0045) * 0.58;
      const edgeHills =
        Math.max(0, r - 0.55) *
        ridged2(nx * 5.2 + 12, ny * 5.2 + 7, 107, 4) *
        1.15;
      h = micro + incahuasi + edgeHills;
      break;
    }

    case 'sajama_bolivia': {
      // Dramatic snow-capped stratovolcano cone with radial glacial gullies & summit crater
      const cone = Math.max(0, 1 - r * 1.18);
      const slopeProfile = Math.pow(cone, 1.35) * 1.15;
      const radialGullies =
        Math.sin(ang * 14 + fbm2(nx * 6, ny * 6, 202, 3) * 2.4) *
        0.11 *
        Math.min(1, r * 3.5) *
        cone;
      const summitCrater = Math.exp(-(r * r) / 0.004) * -0.22;
      const altiplanoBase = ridged2(nx * 4.5 + 3, ny * 4.5 + 9, 209, 4) * 0.22;
      h = slopeProfile + radialGullies + summitCrater + altiplanoBase;
      break;
    }

    case 'atacama_chile': {
      // Hyperarid Yungay valley: flat alluvial basin floor, braided fan channels, coastal ridge flanks
      const valley = Math.min(0.8, Math.pow(Math.abs(nx * 0.85 + ny * 0.25), 1.6) * 0.95);
      const ridge = ridged2(nx * 5.5 + 8, ny * 5.5 + 15, 305, 4) * 0.42;
      const fan = Math.exp(-((ny - 0.1) ** 2) / 0.18) * (fbm2(nx * 14, ny * 14, 311, 4) - 0.5) * 0.14;
      h = valley * 0.55 + ridge * (0.3 + 0.7 * Math.abs(nx)) + fan;
      break;
    }

    case 'death_valley_usa': {
      // Deep Badwater evaporite salt flat trough (-0.45) flanked by steep Panamint & Black Mtn normal fault scarps
      const rotatedX = nx * 0.92 + ny * 0.38;
      const rotatedY = -nx * 0.38 + ny * 0.92;
      const troughDist = Math.abs(rotatedX);
      const basinFloor = troughDist < 0.24 ? -0.42 : -0.42 + Math.pow((troughDist - 0.24) / 0.65, 1.15) * 1.15;
      const mountainSpurs =
        troughDist > 0.22
          ? ridged2(rotatedX * 7 + 5, rotatedY * 7 + 11, 409, 4) * 0.48 * Math.min(1, (troughDist - 0.22) * 3.5)
          : (fbm2(nx * 12, ny * 12, 415, 3) - 0.5) * 0.05;
      h = basinFloor + mountainSpurs;
      break;
    }

    case 'haughton_crater_ca': {
      // 23 km multi-ring arctic impact basin with raised rim, central breccia hills, and dendritic channels
      const craterR = 0.56;
      const rim = Math.exp(-Math.pow((r - craterR) / 0.085, 2)) * 0.62;
      const bowl = r < craterR ? -0.42 * (1 - (r / craterR) ** 2) : 0;
      const centralUplift = Math.exp(-(r * r) / 0.025) * 0.28;
      const breccia = ridged2(nx * 7.5 + 2, ny * 7.5 + 6, 503, 4) * 0.22;
      h = bowl + rim + centralUplift + breccia;
      break;
    }

    case 'jezero_25km': {
      // Crater rim arc, western Neretva Vallis canyon breach, branching delta fan & floor craters
      const craterR = 0.62;
      const rim = Math.exp(-Math.pow((r - craterR) / 0.09, 2)) * 0.68;
      const floor = r < craterR ? -0.34 : 0.08;
      // Western canyon breach cutting through rim at (-0.62, 0.06)
      const canyonMask =
        nx < -0.28 && Math.abs(ny - 0.06 - nx * 0.08) < 0.095
          ? Math.exp(-Math.pow((ny - 0.06 - nx * 0.08) / 0.055, 2))
          : 0;
      // Fan-shaped western delta apron inside crater (-0.52 to -0.14)
      const dx = nx + 0.52;
      const deltaFan =
        dx > 0 && dx < 0.38 && Math.abs(ny - 0.04) < dx * 0.72
          ? (1 - dx / 0.42) * 0.28 + Math.sin(ny * 36 + nx * 12) * 0.025
          : 0;
      // Belva-like floor craters
      const c1 = -Math.exp(-((nx - 0.18) ** 2 + (ny + 0.14) ** 2) / 0.004) * 0.22;
      const c2 = -Math.exp(-((nx + 0.05) ** 2 + (ny - 0.28) ** 2) / 0.0025) * 0.16;
      const terrain = (fbm2(nx * 8 + 14, ny * 8 + 3, 607, 4) - 0.5) * 0.18;
      h = floor + rim * (1 - canyonMask * 0.85) - canyonMask * 0.35 + deltaFan + c1 + c2 + terrain;
      break;
    }

    case 'shackleton_lola': {
      // Deep 21 km polar crater (4.2 km deep, steep >30° terraced walls, bright high rim massifs)
      const craterR = 0.48;
      const rim = Math.exp(-Math.pow((r - craterR) / 0.09, 2)) * 0.65;
      const bowl = r < craterR ? -1.05 * Math.pow(1 - (r / craterR) ** 2.2, 0.85) : 0;
      const terraces =
        r < craterR && r > craterR * 0.45
          ? Math.sin((r / craterR) * Math.PI * 6) * 0.05
          : 0;
      const highlands = ridged2(nx * 6 + 9, ny * 6 + 2, 709, 4) * 0.32;
      h = bowl + rim + terraces + highlands * (r > craterR * 0.85 ? 1 : 0.25);
      break;
    }

    case 'tranquillitatis_lola': {
      // Smooth basalt mare plain with 3D wrinkle ridges (dorsa), sinuous rille & crisp small craters
      const base = (fbm2(nx * 6 + 1, ny * 6 + 8, 809, 4) - 0.5) * 0.12;
      const wrinkle =
        Math.exp(-Math.pow((nx - Math.sin(ny * 2.5) * 0.18) / 0.06, 2)) * 0.26;
      const rille =
        Math.exp(-Math.pow((ny - 0.22 - Math.sin(nx * 3.5) * 0.09) / 0.028, 2)) * -0.18;
      const c1 = -Math.exp(-((nx - 0.26) ** 2 + (ny + 0.18) ** 2) / 0.005) * 0.34;
      const c1Rim = Math.exp(-Math.pow((Math.hypot(nx - 0.26, ny + 0.18) - 0.08) / 0.025, 2)) * 0.18;
      const c2 = -Math.exp(-((nx + 0.32) ** 2 + (ny - 0.25) ** 2) / 0.003) * 0.24;
      h = base + wrinkle + rille + c1 + c1Rim + c2;
      break;
    }

    default:
      h = (fbm2(nx * 6, ny * 6, 999, 4) - 0.5) * 0.25;
  }

  return h * mask;
}

/**
 * Maps a region height and local features into a rich 1024x1024 RGBA texture + edge fade.
 */
function createRegionPatchTexture(
  region: RegionRecord,
  showObservationOverlay: boolean,
): THREE.CanvasTexture {
  const size = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const img = ctx.createImageData(size, size);
  const data = img.data;

  // Rasterize at 512x512 then scale cleanly + overlay crisp vector details at 1024x1024!
  const grid = 512;
  const smallCanvas = document.createElement('canvas');
  smallCanvas.width = grid;
  smallCanvas.height = grid;
  const sCtx = smallCanvas.getContext('2d')!;
  const sImg = sCtx.createImageData(grid, grid);
  const sData = sImg.data;

  for (let py = 0; py < grid; py++) {
    const ny = (py / (grid - 1)) * 2 - 1;
    for (let px = 0; px < grid; px++) {
      const nx = (px / (grid - 1)) * 2 - 1;
      const r = Math.hypot(nx, ny);
      const mask = edgeMask(nx, ny);

      // Compute local gradient for subtle terrain micro-shading
      const eps = 0.008;
      const h = evaluateRegionHeight(region.id, nx, ny);
      const hx = evaluateRegionHeight(region.id, nx + eps, ny);
      const hy = evaluateRegionHeight(region.id, nx, ny + eps);
      const shade = THREE.MathUtils.clamp(1 + ((h - hx) * 1.4 + (h - hy) * 1.4) * 3.2, 0.55, 1.45);
      const grain = (fbm2(nx * 24 + 5, ny * 24 + 9, 55, 3) - 0.5) * 24;

      let cr = 128;
      let cg = 128;
      let cb = 128;

      switch (region.id) {
        case 'uyuni_25km': {
          // Bright salt crust in center, beige-brown Andean slopes at outer edge, dark Isla Incahuasi
          const onSalt = r < 0.62 && h < 0.25;
          const incDist = Math.hypot(nx + 0.14, ny - 0.08);
          if (incDist < 0.075) {
            cr = 92; cg = 78; cb = 62;
          } else if (onSalt) {
            // Hexagonal salt ridge pattern
            const hex =
              Math.abs(Math.sin(nx * 38 + Math.cos(ny * 22) * 0.7)) *
              Math.abs(Math.cos(ny * 34 + Math.sin(nx * 20) * 0.7));
            const ridge = hex < 0.14 ? -14 : 6;
            cr = 228 + ridge; cg = 235 + ridge; cb = 242 + ridge;
          } else {
            cr = 132 + h * 45; cg = 116 + h * 35; cb = 90 + h * 25;
          }
          break;
        }

        case 'sajama_bolivia': {
          // Snow & glacier cap above h > 0.52, volcanic dark basalt flanks, golden altiplano pampa below
          if (h > 0.56) {
            cr = 236; cg = 242; cb = 248;
          } else if (h > 0.3) {
            const t = (h - 0.3) / 0.26;
            cr = lerp(112, 185, t); cg = lerp(94, 174, t); cb = lerp(78, 162, t);
          } else {
            cr = 142 + h * 40; cg = 124 + h * 30; cb = 88 + h * 20;
          }
          break;
        }

        case 'atacama_chile': {
          // Hyperarid ochre/gypsum floor, rust-brown alluvial fans, darker coastal bedrock ridges
          const fanTint = fbm2(nx * 14, ny * 14, 311, 4);
          if (h < 0.16) {
            cr = 188 + fanTint * 24; cg = 152 + fanTint * 20; cb = 112 + fanTint * 16;
          } else {
            cr = 148 + h * 35; cg = 108 + h * 25; cb = 78 + h * 18;
          }
          break;
        }

        case 'death_valley_usa': {
          const rotX = nx * 0.92 + ny * 0.38;
          if (Math.abs(rotX) < 0.23 && h < -0.25) {
            // White Badwater evaporite salt flat
            cr = 224; cg = 222; cb = 214;
          } else if (h < 0.05) {
            // Alluvial fans & Artist's Palette mineral bands
            const mineral = fbm2(nx * 12, ny * 12, 421, 3);
            cr = 178 + mineral * 28; cg = 144 + mineral * 18; cb = 108 + mineral * 22;
          } else {
            // Panamint & Black Mountain dark desert rock
            cr = 118 + h * 35; cg = 96 + h * 28; cb = 78 + h * 20;
          }
          break;
        }

        case 'haughton_crater_ca': {
          // Pale gray-tan carbonate impact breccia inside crater, darker permafrost plateau outside
          if (r < 0.54) {
            cr = 166 + h * 32; cg = 162 + h * 30; cb = 148 + h * 24;
          } else {
            cr = 108 + h * 42; cg = 114 + h * 40; cb = 104 + h * 36;
          }
          break;
        }

        case 'jezero_25km': {
          // Martian terracotta rim, lighter clay/carbonate fan delta, dark basaltic crater floor
          const dx = nx + 0.52;
          const onDelta = dx > 0 && dx < 0.38 && Math.abs(ny - 0.04) < dx * 0.72;
          if (onDelta) {
            cr = 216; cg = 158; cb = 112;
          } else if (h > 0.2) {
            cr = 204; cg = 122; cb = 82;
          } else if (h < -0.22) {
            cr = 124; cg = 68; cb = 48;
          } else {
            cr = 168; cg = 96; cb = 64;
          }
          break;
        }

        case 'shackleton_lola': {
          // Cryogenic deep-shadow floor, sharp sunlit south-pole rim crest
          if (h < -0.55) {
            cr = 34; cg = 40; cb = 52;
          } else if (h > 0.25) {
            cr = 212; cg = 220; cb = 230;
          } else {
            const t = (h + 0.55) / 0.8;
            cr = lerp(52, 162, t); cg = lerp(58, 168, t); cb = lerp(68, 178, t);
          }
          break;
        }

        case 'tranquillitatis_lola': {
          // Dark smooth lunar basalt mare with lighter crater ejecta & wrinkle ridges
          if (h > 0.14) {
            cr = 114; cg = 120; cb = 130;
          } else {
            cr = 72 + h * 40; cg = 78 + h * 40; cb = 88 + h * 42;
          }
          break;
        }

        default:
          cr = 130; cg = 130; cb = 130;
      }

      const idx = (py * grid + px) * 4;
      sData[idx] = THREE.MathUtils.clamp(Math.round(cr * shade + grain), 0, 255);
      sData[idx + 1] = THREE.MathUtils.clamp(Math.round(cg * shade + grain), 0, 255);
      sData[idx + 2] = THREE.MathUtils.clamp(Math.round(cb * shade + grain), 0, 255);
      sData[idx + 3] = Math.round(mask * 246);
    }
  }

  sCtx.putImageData(sImg, 0, 0);
  ctx.drawImage(smallCanvas, 0, 0, size, size);

  // Add razor-sharp 1024x1024 site-specific vector details on top
  if (region.id === 'uyuni_25km') {
    ctx.save();
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.34)';
    ctx.lineWidth = 1.4;
    for (let i = 0; i < 42; i++) {
      const cx = size * (0.26 + ((i * 73) % 48) / 100);
      const cy = size * (0.26 + ((i * 59) % 48) / 100);
      const rad = 18 + (i % 14);
      ctx.beginPath();
      for (let s = 0; s < 6; s++) {
        const a = (s / 6) * Math.PI * 2;
        const vx = cx + Math.cos(a) * rad;
        const vy = cy + Math.sin(a) * rad;
        if (s === 0) ctx.moveTo(vx, vy);
        else ctx.lineTo(vx, vy);
      }
      ctx.closePath();
      ctx.stroke();
    }
    ctx.restore();
  }

  if (region.id === 'jezero_25km') {
    // Draw fine delta distributary channels on Jezero
    ctx.save();
    ctx.strokeStyle = 'rgba(248, 210, 164, 0.45)';
    ctx.lineWidth = 2.2;
    const inletX = size * 0.24;
    const inletY = size * 0.52;
    for (let b = -3; b <= 3; b++) {
      ctx.beginPath();
      ctx.moveTo(inletX, inletY);
      ctx.quadraticCurveTo(
        size * 0.35,
        inletY + b * 14,
        size * 0.44,
        inletY + b * 28,
      );
      ctx.stroke();
    }
    if (showObservationOverlay) {
      // Subtle 38.07% observed cyan track dots along MOLA passes
      for (let r = 8; r < 46; r += 2) {
        for (let c = 8; c < 46; c += 2) {
          const observed = (r * 7 + c * 11) % 100 < 38;
          ctx.fillStyle = observed ? 'rgba(34, 211, 238, 0.28)' : 'rgba(245, 158, 11, 0.08)';
          ctx.fillRect((c / 54) * size, (r / 54) * size, 9, 9);
        }
      }
    }
    ctx.restore();
  }

  void data;

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

/**
 * Builds a curved, vertex-displaced 3D regional terrain mesh centered accurately on the sphere.
 */
export function buildRegionalTerrainPatch(
  region: RegionRecord,
  options: { showObservationOverlay?: boolean } = {},
): THREE.Mesh {
  const segs = 92;
  const halfArcRad = region.body === 'moon' ? 0.044 : region.body === 'mars' ? 0.042 : 0.038;
  const maxRelief = region.body === 'moon' ? 0.015 : region.body === 'mars' ? 0.012 : 0.0105;

  const centerNormal = latLonToVector3(region.centerLat, region.centerLon, 1).normalize();
  const refUp =
    Math.abs(centerNormal.y) > 0.94
      ? new THREE.Vector3(0, 0, 1)
      : new THREE.Vector3(0, 1, 0);
  const east = new THREE.Vector3().crossVectors(refUp, centerNormal).normalize();
  const north = new THREE.Vector3().crossVectors(centerNormal, east).normalize();

  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  for (let iy = 0; iy <= segs; iy++) {
    const v = iy / segs;
    const ny = v * 2 - 1;
    for (let ix = 0; ix <= segs; ix++) {
      const u = ix / segs;
      const nx = u * 2 - 1;

      const dir = centerNormal
        .clone()
        .addScaledVector(east, nx * halfArcRad)
        .addScaledVector(north, -ny * halfArcRad)
        .normalize();

      const h = evaluateRegionHeight(region.id, nx, ny);
      const radius = GLOBE_RADIUS + 0.0014 + h * maxRelief;
      const pos = dir.multiplyScalar(radius);

      positions.push(pos.x, pos.y, pos.z);
      uvs.push(u, 1 - v);
    }
  }

  const rowStride = segs + 1;
  for (let iy = 0; iy < segs; iy++) {
    for (let ix = 0; ix < segs; ix++) {
      const a = iy * rowStride + ix;
      const b = a + 1;
      const c = a + rowStride;
      const d = c + 1;
      indices.push(a, c, b);
      indices.push(b, c, d);
    }
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();

  const map = createRegionPatchTexture(region, Boolean(options.showObservationOverlay));
  const material = new THREE.MeshStandardMaterial({
    map,
    transparent: true,
    roughness: region.id === 'uyuni_25km' ? 0.65 : 0.9,
    metalness: 0.03,
    depthWrite: true,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });

  const mesh = new THREE.Mesh(geometry, material);
  mesh.userData.regionId = region.id;
  return mesh;
}
