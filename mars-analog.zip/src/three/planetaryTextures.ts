import * as THREE from 'three';
import type { CelestialBodyId } from '../shared/types';

export interface PlanetaryTextureSet {
  map: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
  roughnessMap: THREE.CanvasTexture;
  cloudMap?: THREE.CanvasTexture;
}

/**
 * Converts geographic/planetocentric (latDeg, lonDeg) to 3D Cartesian coordinates
 * aligned exactly with THREE.SphereGeometry UV mapping:
 *   u = (lon180 + 180) / 360 -> phi = u * 2 * PI
 *   theta = (90 - lat) * PI / 180
 */
export function latLonToVector3(latDeg: number, lonDeg: number, radius: number): THREE.Vector3 {
  const lon180 = lonDeg > 180 ? lonDeg - 360 : lonDeg;
  const phi = ((lon180 + 180) / 360) * Math.PI * 2;
  const theta = ((90 - latDeg) * Math.PI) / 180;

  const x = -radius * Math.cos(phi) * Math.sin(theta);
  const y = radius * Math.cos(theta);
  const z = radius * Math.sin(phi) * Math.sin(theta);
  return new THREE.Vector3(x, y, z);
}

/**
 * Inverse of latLonToVector3: converts a local-space sphere surface point to (latDeg, lonDeg).
 */
export function vector3ToLatLon(
  point: THREE.Vector3,
  body: CelestialBodyId,
): { lat: number; lon: number; lonDisplay: string } {
  const n = point.clone().normalize();
  const lat = (Math.asin(THREE.MathUtils.clamp(n.y, -1, 1)) * 180) / Math.PI;
  let phi = Math.atan2(n.z, -n.x);
  if (phi < 0) phi += Math.PI * 2;
  const lon180 = (phi * 180) / Math.PI - 180;

  if (body === 'earth') {
    const hemiLat = lat >= 0 ? 'N' : 'S';
    const hemiLon = lon180 >= 0 ? 'E' : 'W';
    return {
      lat,
      lon: lon180,
      lonDisplay: `${Math.abs(lat).toFixed(2)}° ${hemiLat}, ${Math.abs(lon180).toFixed(2)}° ${hemiLon}`,
    };
  }

  // Mars & Moon use planetocentric 0° to 360° East longitude
  const lon360 = lon180 < 0 ? lon180 + 360 : lon180;
  const hemiLat = lat >= 0 ? 'N' : 'S';
  return {
    lat,
    lon: lon360,
    lonDisplay: `${Math.abs(lat).toFixed(2)}° ${hemiLat}, ${lon360.toFixed(2)}° E`,
  };
}

function lonToX(lonDeg: number, width: number): number {
  const lon180 = lonDeg > 180 ? lonDeg - 360 : lonDeg;
  return ((lon180 + 180) / 360) * width;
}

function latToY(latDeg: number, height: number): number {
  return ((90 - latDeg) / 180) * height;
}

// Fast deterministic 3D lattice hash for seamless spherical FBM noise
function hash3(ix: number, iy: number, iz: number, seed: number): number {
  let h = (ix * 374761393 + iy * 668265263 + iz * 2147483647 + seed * 1597334677) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967295;
}

function smoothstep(t: number): number {
  return t * t * (3 - 2 * t);
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

function noise3(x: number, y: number, z: number, seed: number): number {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const iz = Math.floor(z);
  const fx = smoothstep(x - ix);
  const fy = smoothstep(y - iy);
  const fz = smoothstep(z - iz);

  const n000 = hash3(ix, iy, iz, seed);
  const n100 = hash3(ix + 1, iy, iz, seed);
  const n010 = hash3(ix, iy + 1, iz, seed);
  const n110 = hash3(ix + 1, iy + 1, iz, seed);
  const n001 = hash3(ix, iy, iz + 1, seed);
  const n101 = hash3(ix + 1, iy, iz + 1, seed);
  const n011 = hash3(ix, iy + 1, iz + 1, seed);
  const n111 = hash3(ix + 1, iy + 1, iz + 1, seed);

  const nx00 = lerp(n000, n100, fx);
  const nx10 = lerp(n010, n110, fx);
  const nx01 = lerp(n001, n101, fx);
  const nx11 = lerp(n011, n111, fx);

  return lerp(lerp(nx00, nx10, fy), lerp(nx01, nx11, fy), fz);
}

function fbm3(x: number, y: number, z: number, seed: number, octaves = 4): number {
  let sum = 0;
  let amp = 0.5;
  let freq = 1;
  let norm = 0;
  for (let o = 0; o < octaves; o++) {
    sum += amp * noise3(x * freq, y * freq, z * freq, seed + o * 31);
    norm += amp;
    amp *= 0.5;
    freq *= 2.08;
  }
  return sum / norm;
}

function ridged3(x: number, y: number, z: number, seed: number, octaves = 4): number {
  let sum = 0;
  let amp = 0.5;
  let freq = 1;
  let norm = 0;
  for (let o = 0; o < octaves; o++) {
    const n = noise3(x * freq, y * freq, z * freq, seed + o * 43);
    const r = 1 - Math.abs(n * 2 - 1);
    sum += amp * r * r;
    norm += amp;
    amp *= 0.5;
    freq *= 2.12;
  }
  return sum / norm;
}

function createSphericalNoiseCanvas(
  w: number,
  h: number,
  freq: number,
  seed: number,
  contrast = 1,
  octaves = 4,
  ridged = false,
): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d')!;
  const img = ctx.createImageData(w, h);
  const data = img.data;

  for (let py = 0; py < h; py++) {
    const theta = (py / h) * Math.PI;
    const sinT = Math.sin(theta);
    const cosT = Math.cos(theta);
    for (let px = 0; px < w; px++) {
      const phi = (px / w) * Math.PI * 2;
      const nx = sinT * Math.cos(phi) * freq;
      const ny = cosT * freq;
      const nz = sinT * Math.sin(phi) * freq;
      let v = ridged ? ridged3(nx, ny, nz, seed, octaves) : fbm3(nx, ny, nz, seed, octaves);
      v = THREE.MathUtils.clamp((v - 0.5) * contrast + 0.5, 0, 1);
      const byte = Math.round(v * 255);
      const idx = (py * w + px) * 4;
      data[idx] = byte;
      data[idx + 1] = byte;
      data[idx + 2] = byte;
      data[idx + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  return c;
}

/**
 * Generates a high-frequency micro-grain pattern canvas for crisp zoomed-in terrain texture.
 */
function createMicroGrainCanvas(size = 256, seed = 91): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d')!;
  const img = ctx.createImageData(size, size);
  const d = img.data;
  for (let i = 0; i < size * size; i++) {
    const r = ((Math.imul(i + seed * 17, 2654435761) >>> 24) & 0xff);
    const v = 104 + Math.round((r / 255) * 48);
    const p = i * 4;
    d[p] = v;
    d[p + 1] = v;
    d[p + 2] = v;
    d[p + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  return c;
}

function drawPolygon(
  ctx: CanvasRenderingContext2D,
  coords: Array<[number, number]>,
  width: number,
  height: number,
  fill: string | CanvasGradient,
  stroke?: string,
  lineWidth = 1.2,
) {
  if (coords.length === 0) return;
  ctx.beginPath();
  coords.forEach(([lon, lat], idx) => {
    const x = lonToX(lon, width);
    const y = latToY(lat, height);
    if (idx === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill();
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.lineWidth = lineWidth;
    ctx.stroke();
  }
}

function drawSoftBlob(
  ctx: CanvasRenderingContext2D,
  lon: number,
  lat: number,
  rxDeg: number,
  ryDeg: number,
  width: number,
  height: number,
  innerColor: string,
  outerColor: string,
) {
  const cx = lonToX(lon, width);
  const cy = latToY(lat, height);
  const rx = (rxDeg / 360) * width;
  const ry = (ryDeg / 180) * height;
  const rMax = Math.max(rx, ry);
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(rx / rMax, ry / rMax);
  const g = ctx.createRadialGradient(0, 0, 0, 0, 0, rMax);
  g.addColorStop(0, innerColor);
  g.addColorStop(1, outerColor);
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, 0, rMax, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawCrater(
  albedoCtx: CanvasRenderingContext2D,
  bumpCtx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  radius: number,
  albedoWidth: number,
  bumpWidth: number,
  opts: {
    rimLight: string;
    floorDark: string;
    centralPeak?: boolean;
    depthStrength?: number;
  },
) {
  const { rimLight, floorDark, centralPeak = false, depthStrength = 0.62 } = opts;
  const rimWidth = Math.max(1.2, radius * 0.15);

  const bowlGrad = albedoCtx.createRadialGradient(
    cx + radius * 0.18,
    cy + radius * 0.18,
    radius * 0.08,
    cx,
    cy,
    radius,
  );
  bowlGrad.addColorStop(0, floorDark);
  bowlGrad.addColorStop(0.75, floorDark);
  bowlGrad.addColorStop(1, 'rgba(0,0,0,0)');
  albedoCtx.fillStyle = bowlGrad;
  albedoCtx.beginPath();
  albedoCtx.arc(cx, cy, radius, 0, Math.PI * 2);
  albedoCtx.fill();

  albedoCtx.save();
  albedoCtx.lineWidth = rimWidth;
  albedoCtx.strokeStyle = rimLight;
  albedoCtx.beginPath();
  albedoCtx.arc(cx, cy, radius * 0.95, Math.PI * 0.85, Math.PI * 1.92);
  albedoCtx.stroke();

  albedoCtx.strokeStyle = floorDark;
  albedoCtx.beginPath();
  albedoCtx.arc(cx, cy, radius * 0.95, -Math.PI * 0.08, Math.PI * 0.85);
  albedoCtx.stroke();

  if (centralPeak && radius > 10) {
    albedoCtx.fillStyle = rimLight;
    albedoCtx.beginPath();
    albedoCtx.arc(cx, cy, radius * 0.16, 0, Math.PI * 2);
    albedoCtx.fill();
  }
  albedoCtx.restore();

  // Bump relief scaled accurately from albedo -> bump dimensions
  const ratio = bumpWidth / albedoWidth;
  const bx = cx * ratio;
  const by = cy * ratio;
  const br = radius * ratio;
  const bGrad = bumpCtx.createRadialGradient(bx, by, 0, bx, by, br * 1.28);
  bGrad.addColorStop(0, centralPeak ? `rgba(180,180,180,${depthStrength * 0.7})` : `rgba(22,22,22,${depthStrength})`);
  bGrad.addColorStop(0.24, `rgba(28,28,28,${depthStrength * 0.88})`);
  bGrad.addColorStop(0.7, `rgba(48,48,48,${depthStrength * 0.65})`);
  bGrad.addColorStop(0.86, `rgba(242,242,242,${depthStrength * 0.9})`);
  bGrad.addColorStop(1, 'rgba(128,128,128,0)');
  bumpCtx.fillStyle = bGrad;
  bumpCtx.beginPath();
  bumpCtx.arc(bx, by, br * 1.28, 0, Math.PI * 2);
  bumpCtx.fill();
}

function drawGraticule(ctx: CanvasRenderingContext2D, width: number, height: number, color: string) {
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = 0.8;

  for (let lon = -150; lon <= 180; lon += 30) {
    const x = lonToX(lon, width);
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, height);
    ctx.stroke();
  }

  for (let lat = -60; lat <= 60; lat += 30) {
    const y = latToY(lat, height);
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }

  ctx.strokeStyle = color.replace(/[\d.]+\)$/, '0.22)');
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(0, latToY(0, height));
  ctx.lineTo(width, latToY(0, height));
  ctx.stroke();
  ctx.restore();
}

// Detailed continental and major island polygons [lon, lat]
const EARTH_LANDMASSES: Array<Array<[number, number]>> = [
  // South America
  [
    [-81, 9], [-76, 11], [-71, 12], [-62, 10], [-52, 4], [-49, 0], [-42, -3], [-35, -6],
    [-38, -14], [-41, -22], [-48, -26], [-53, -33], [-58, -38], [-64, -41], [-66, -48],
    [-68, -55], [-73, -53], [-75, -47], [-73, -41], [-72, -33], [-70, -20], [-76, -14],
    [-81, -5], [-79, 2],
  ],
  // North & Central America (with Baja & Florida & Hudson Bay detail)
  [
    [-168, 65], [-161, 71], [-145, 70], [-130, 70], [-115, 69], [-96, 68], [-90, 62],
    [-93, 58], [-82, 53], [-78, 62], [-67, 60], [-55, 52], [-60, 46], [-66, 44], [-71, 41],
    [-75, 36], [-80, 31], [-80, 25], [-82, 26], [-83, 29], [-89, 30], [-97, 26], [-96, 19],
    [-91, 21], [-87, 21], [-88, 16], [-83, 14], [-83, 9], [-78, 8], [-84, 9], [-92, 14],
    [-103, 18], [-106, 23], [-112, 29], [-114, 31], [-110, 23], [-115, 29], [-117, 32],
    [-122, 37], [-124, 44], [-124, 49], [-131, 55], [-140, 60], [-152, 60], [-162, 55], [-166, 60],
  ],
  // Arctic Archipelago (Devon Island for Haughton Crater 75.37N -89.68W, Baffin, Victoria, Ellesmere)
  [[-96, 74], [-84, 74], [-80, 77], [-90, 78], [-97, 76]],
  [[-118, 69], [-102, 69], [-103, 73], [-116, 73]],
  [[-84, 71], [-68, 70], [-63, 66], [-72, 63], [-80, 67]],
  [[-86, 79], [-66, 82], [-62, 78], [-78, 77]],
  // Greenland
  [[-52, 60], [-42, 60], [-33, 68], [-19, 75], [-24, 82], [-48, 82], [-68, 77], [-57, 69]],
  // Iceland, UK, Ireland, Sardinia, Sicily
  [[-24, 65], [-14, 66], [-14, 63], [-23, 64]],
  [[-6, 50], [2, 51], [-1, 58], [-6, 58], [-5, 54]],
  [[-10, 52], [-6, 52], [-6, 55], [-10, 55]],
  [[8, 39], [10, 39], [10, 41], [8, 41]],
  [[12, 37], [15, 37], [15, 38], [12, 38]],
  // Cuba, Hispaniola, Jamaica, Puerto Rico
  [[-84, 22], [-74, 20], [-76, 21], [-83, 23]],
  [[-74, 19], [-68, 18], [-69, 20], [-73, 20]],
  // Africa
  [
    [-17, 15], [-16, 21], [-12, 28], [-6, 36], [3, 37], [11, 37], [12, 33], [24, 32],
    [33, 31], [38, 22], [43, 12], [51, 12], [48, 4], [41, -2], [40, -11], [35, -24],
    [28, -33], [19, -35], [15, -26], [12, -14], [12, -5], [9, 4], [2, 6], [-8, 5], [-15, 11],
  ],
  // Madagascar
  [[44, -25], [47, -25], [50, -13], [48, -12], [44, -18]],
  // Europe (with Iberian, Italian, Balkan, Scandinavian peninsulas)
  [
    [-9, 37], [-9, 43], [-2, 43], [-5, 48], [2, 51], [8, 55], [11, 58], [5, 60],
    [10, 65], [19, 70], [29, 71], [42, 67], [58, 69], [60, 55], [44, 43], [36, 45],
    [29, 41], [23, 38], [20, 40], [18, 40], [16, 38], [13, 41], [12, 44], [9, 44], [3, 43], [-4, 37],
  ],
  // Asia + Arabian Peninsula + India + SE Asia + Kamchatka
  [
    [35, 36], [42, 42], [53, 45], [60, 55], [60, 69], [73, 73], [104, 77], [140, 73],
    [176, 67], [168, 60], [162, 55], [156, 51], [159, 60], [141, 53], [135, 44], [129, 36],
    [127, 35], [124, 39], [121, 31], [118, 24], [109, 20], [109, 12], [104, 2],
    [100, 8], [97, 16], [90, 22], [82, 16], [78, 8], [73, 19], [67, 25], [57, 26],
    [49, 29], [56, 23], [52, 16], [44, 13], [39, 21], [35, 29],
  ],
  // Sri Lanka, Japan, Taiwan, Philippines, Sumatra, Java, Borneo, Sulawesi, New Guinea
  [[80, 6], [82, 7], [81, 9], [80, 8]],
  [[130, 32], [136, 34], [141, 39], [145, 44], [140, 44], [136, 37], [130, 34]],
  [[120, 22], [122, 25], [121, 25], [120, 23]],
  [[120, 12], [123, 18], [126, 7], [122, 7]],
  [[96, 5], [105, -6], [114, -8], [102, 0]],
  [[109, -3], [118, -3], [118, 6], [110, 2]],
  [[119, -5], [123, 1], [125, 1], [120, -4]],
  [[132, -2], [142, -3], [150, -10], [138, -8]],
  // Australia & Tasmania & New Zealand
  [
    [114, -22], [122, -17], [131, -12], [136, -15], [142, -11], [149, -20],
    [153, -28], [150, -37], [141, -38], [133, -33], [122, -34], [115, -34], [114, -27],
  ],
  [[145, -41], [148, -41], [147, -43], [145, -43]],
  [[167, -46], [174, -41], [178, -37], [174, -35], [172, -41], [166, -45]],
];

function createEarthTextures(): PlanetaryTextureSet {
  const w = 4096;
  const h = 2048;
  const bw = 2048;
  const bh = 1024;
  const rw = 1024;
  const rh = 512;

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = w;
  albedoCanvas.height = h;
  const ctx = albedoCanvas.getContext('2d')!;

  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = bw;
  bumpCanvas.height = bh;
  const bCtx = bumpCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = rw;
  roughCanvas.height = rh;
  const rCtx = roughCanvas.getContext('2d')!;

  // 1. Deep ocean bathymetry gradient
  const oceanGrad = ctx.createLinearGradient(0, 0, 0, h);
  oceanGrad.addColorStop(0, '#0f2944');
  oceanGrad.addColorStop(0.25, '#09223d');
  oceanGrad.addColorStop(0.5, '#071b33');
  oceanGrad.addColorStop(0.75, '#09223d');
  oceanGrad.addColorStop(1, '#0f2944');
  ctx.fillStyle = oceanGrad;
  ctx.fillRect(0, 0, w, h);

  const oceanNoise = createSphericalNoiseCanvas(768, 384, 7.5, 11, 1.55, 5);
  ctx.save();
  ctx.globalAlpha = 0.2;
  ctx.globalCompositeOperation = 'screen';
  ctx.drawImage(oceanNoise, 0, 0, w, h);
  ctx.restore();

  // Mid-ocean ridges & Pacific abyssal trenches
  ctx.save();
  ctx.strokeStyle = 'rgba(32, 112, 174, 0.38)';
  ctx.lineWidth = 16;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(lonToX(-28, w), latToY(65, h));
  ctx.bezierCurveTo(
    lonToX(-42, w), latToY(20, h),
    lonToX(-15, w), latToY(-5, h),
    lonToX(-14, w), latToY(-55, h),
  );
  ctx.stroke();
  ctx.strokeStyle = 'rgba(4, 14, 30, 0.55)';
  ctx.lineWidth = 9;
  ctx.beginPath();
  ctx.moveTo(lonToX(142, w), latToY(12, h));
  ctx.quadraticCurveTo(lonToX(148, w), latToY(20, h), lonToX(144, w), latToY(35, h));
  ctx.stroke();
  ctx.restore();

  bCtx.fillStyle = '#0c0c0c';
  bCtx.fillRect(0, 0, bw, bh);
  rCtx.fillStyle = '#383838';
  rCtx.fillRect(0, 0, rw, rh);

  // 2. Continental shelf shallow turquoise halo
  ctx.save();
  ctx.shadowColor = 'rgba(26, 152, 190, 0.55)';
  ctx.shadowBlur = 26;
  EARTH_LANDMASSES.forEach((poly) => {
    drawPolygon(ctx, poly, w, h, '#193b32');
  });
  ctx.restore();

  // 3. Continents + Bump base + Matte roughness
  EARTH_LANDMASSES.forEach((poly) => {
    drawPolygon(ctx, poly, w, h, '#244b39', 'rgba(92, 184, 148, 0.5)', 1.6);
    drawPolygon(bCtx, poly, bw, bh, '#464646', '#343434', 1.2);
    drawPolygon(rCtx, poly, rw, rh, '#dcdcdc');
  });

  // Inland lakes & seas (Great Lakes, Caspian, Black Sea, Lake Titicaca, Victoria)
  const inlandWaters: Array<Array<[number, number]>> = [
    [[-92, 47], [-84, 46], [-81, 43], [-87, 42], [-91, 46]], // Great Lakes
    [[47, 45], [53, 45], [54, 37], [49, 37]],                  // Caspian Sea
    [[28, 46], [40, 45], [41, 41], [29, 41]],                  // Black Sea
    [[-70, -15.3], [-68.6, -15.6], [-68.8, -16.6], [-70.1, -16.1]], // Titicaca
    [[31.8, 0.4], [34.5, 0.3], [34.2, -2.6], [31.6, -2.5]],    // Victoria
  ];
  inlandWaters.forEach((poly) => {
    drawPolygon(ctx, poly, w, h, '#09223d');
    drawPolygon(rCtx, poly, rw, rh, '#3c3c3c');
    drawPolygon(bCtx, poly, bw, bh, '#151515');
  });

  // 4. Rich Biomes (Tropical rainforests, temperate grasslands, boreal taiga, deserts)
  drawSoftBlob(ctx, -62, -5, 16, 10, w, h, 'rgba(24, 92, 46, 0.85)', 'rgba(24, 92, 46, 0)');
  drawSoftBlob(ctx, 21, 0, 12, 9, w, h, 'rgba(24, 92, 46, 0.82)', 'rgba(24, 92, 46, 0)');
  drawSoftBlob(ctx, 112, -1, 18, 9, w, h, 'rgba(24, 92, 46, 0.78)', 'rgba(24, 92, 46, 0)');
  drawSoftBlob(ctx, 90, 61, 45, 7, w, h, 'rgba(42, 74, 52, 0.65)', 'rgba(42, 74, 52, 0)');
  drawSoftBlob(ctx, -110, 58, 28, 7, w, h, 'rgba(44, 76, 54, 0.62)', 'rgba(44, 76, 54, 0)');

  // Deserts
  drawSoftBlob(ctx, 12, 23, 24, 10, w, h, 'rgba(186, 152, 102, 0.9)', 'rgba(186, 152, 102, 0)');
  drawSoftBlob(ctx, 45, 22, 11, 8, w, h, 'rgba(190, 154, 102, 0.88)', 'rgba(190, 154, 102, 0)');
  drawSoftBlob(ctx, 98, 42, 16, 7, w, h, 'rgba(166, 140, 96, 0.78)', 'rgba(166, 140, 96, 0)');
  drawSoftBlob(ctx, 132, -25, 14, 8, w, h, 'rgba(174, 122, 82, 0.86)', 'rgba(174, 122, 82, 0)');
  drawSoftBlob(ctx, -115, 35, 7, 5, w, h, 'rgba(176, 146, 104, 0.84)', 'rgba(176, 146, 104, 0)');
  drawSoftBlob(ctx, -69.2, -24.0, 3.8, 5.5, w, h, 'rgba(186, 152, 104, 0.92)', 'rgba(186, 152, 104, 0)');

  // Major river networks (Amazon, Nile, Congo, Mississippi, Yangtze, Parana)
  ctx.save();
  ctx.strokeStyle = 'rgba(16, 72, 104, 0.75)';
  ctx.lineWidth = 2.1;
  ctx.lineCap = 'round';
  const rivers: Array<Array<[number, number]>> = [
    [[-76, -4], [-68, -3], [-60, -3], [-50, 0]],             // Amazon
    [[32, 2], [32, 15], [31, 31]],                            // Nile
    [[26, -3], [21, 1], [15, -4], [12, -6]],                  // Congo
    [[-95, 44], [-90, 38], [-91, 33], [-89, 29]],             // Mississippi
    [[96, 33], [105, 29], [114, 30], [121, 31]],              // Yangtze
    [[-56, -18], [-58, -26], [-58, -34]],                     // Parana
  ];
  rivers.forEach((pts) => {
    ctx.beginPath();
    pts.forEach(([lon, lat], idx) => {
      const rx = lonToX(lon, w);
      const ry = latToY(lat, h);
      if (idx === 0) ctx.moveTo(rx, ry);
      else ctx.lineTo(rx, ry);
    });
    ctx.stroke();
  });
  ctx.restore();

  // 5. Mountain chains
  const mountains: Array<{ lon: number; lat: number; rx: number; ry: number; color: string; bump: string }> = [
    { lon: -68.5, lat: -19, rx: 4.5, ry: 16, color: 'rgba(164, 146, 114, 0.84)', bump: 'rgba(235, 235, 235, 0.92)' },
    { lon: -72, lat: -38, rx: 3, ry: 12, color: 'rgba(150, 144, 132, 0.75)', bump: 'rgba(215, 215, 215, 0.84)' },
    { lon: 86, lat: 32, rx: 14, ry: 6, color: 'rgba(182, 170, 148, 0.88)', bump: 'rgba(252, 252, 252, 0.96)' },
    { lon: -112, lat: 46, rx: 8, ry: 12, color: 'rgba(142, 132, 112, 0.76)', bump: 'rgba(222, 222, 222, 0.86)' },
    { lon: 11, lat: 46.5, rx: 6, ry: 2.8, color: 'rgba(174, 168, 160, 0.78)', bump: 'rgba(218, 218, 218, 0.85)' },
    { lon: 44, lat: 42, rx: 5, ry: 2.4, color: 'rgba(158, 150, 140, 0.72)', bump: 'rgba(202, 202, 202, 0.78)' },
    { lon: 38, lat: 8, rx: 5, ry: 7, color: 'rgba(150, 134, 104, 0.72)', bump: 'rgba(202, 202, 202, 0.78)' },
  ];
  mountains.forEach((m) => {
    drawSoftBlob(ctx, m.lon, m.lat, m.rx, m.ry, w, h, m.color, 'rgba(0,0,0,0)');
    drawSoftBlob(bCtx, m.lon, m.lat, m.rx, m.ry, bw, bh, m.bump, 'rgba(0,0,0,0)');
  });

  // 6. HIGH-DETAIL ZOOMED-IN SITE GEOMORPHOLOGY (paired with 3D regional patches)
  {
    const ux = lonToX(-66.95, w);
    const uy = latToY(-20.38, h);
    ctx.save();
    ctx.fillStyle = '#e8eef5';
    ctx.strokeStyle = '#b4c2d0';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.ellipse(ux, uy, 11, 7.5, -0.22, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#5c4b3c';
    ctx.beginPath();
    ctx.arc(ux - 1.5, uy + 0.5, 1.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    bCtx.fillStyle = '#a8a8a8';
    bCtx.beginPath();
    bCtx.ellipse(lonToX(-66.95, bw), latToY(-20.38, bh), 5.5, 3.8, -0.22, 0, Math.PI * 2);
    bCtx.fill();
  }

  {
    const sx = lonToX(-68.88, w);
    const sy = latToY(-18.11, h);
    drawSoftBlob(ctx, -68.88, -18.11, 0.7, 0.7, w, h, 'rgba(130, 110, 92, 0.9)', 'rgba(0,0,0,0)');
    ctx.fillStyle = '#f8fafc';
    ctx.beginPath();
    ctx.arc(sx, sy, 3.5, 0, Math.PI * 2);
    ctx.fill();
    drawSoftBlob(bCtx, -68.88, -18.11, 0.75, 0.75, bw, bh, 'rgba(255,255,255,0.98)', 'rgba(0,0,0,0)');
  }

  drawSoftBlob(ctx, -69.25, -24.50, 1.4, 2.2, w, h, 'rgba(198, 162, 114, 0.92)', 'rgba(0,0,0,0)');

  {
    const dx = lonToX(-117.08, w);
    const dy = latToY(36.51, h);
    ctx.save();
    ctx.fillStyle = '#e5e7eb';
    ctx.beginPath();
    ctx.ellipse(dx, dy, 2.8, 7.5, -0.35, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    bCtx.save();
    bCtx.fillStyle = '#262626';
    bCtx.beginPath();
    bCtx.ellipse(lonToX(-117.08, bw), latToY(36.51, bh), 1.8, 4.2, -0.35, 0, Math.PI * 2);
    bCtx.fill();
    bCtx.strokeStyle = '#d8d8d8';
    bCtx.lineWidth = 1.6;
    bCtx.stroke();
    bCtx.restore();
  }

  drawCrater(ctx, bCtx, lonToX(-89.68, w), latToY(75.37, h), 8, w, bw, {
    rimLight: 'rgba(203, 213, 225, 0.85)',
    floorDark: 'rgba(110, 106, 98, 0.78)',
    depthStrength: 0.82,
  });

  // 7. Polar Ice Caps & Arctic sea-ice hint
  drawSoftBlob(ctx, -42, 73, 14, 8, w, h, 'rgba(228, 238, 248, 0.9)', 'rgba(228, 238, 248, 0)');
  const arcticGrad = ctx.createLinearGradient(0, 0, 0, latToY(76, h));
  arcticGrad.addColorStop(0, '#e2edf8');
  arcticGrad.addColorStop(0.6, 'rgba(208, 224, 240, 0.55)');
  arcticGrad.addColorStop(1, 'rgba(208, 224, 240, 0)');
  ctx.fillStyle = arcticGrad;
  ctx.fillRect(0, 0, w, latToY(76, h));

  const antY = latToY(-71, h);
  const antGrad = ctx.createLinearGradient(0, antY - 24, 0, h);
  antGrad.addColorStop(0, 'rgba(218, 230, 242, 0)');
  antGrad.addColorStop(0.25, '#c8d8e8');
  antGrad.addColorStop(1, '#e8f1fa');
  ctx.fillStyle = antGrad;
  ctx.fillRect(0, antY - 24, w, h - antY + 24);
  rCtx.fillStyle = '#9a9a9a';
  rCtx.fillRect(0, latToY(-72, rh), rw, rh - latToY(-72, rh));
  bCtx.fillStyle = '#8e8e8e';
  bCtx.fillRect(0, latToY(-72, bh), bw, bh - latToY(-72, bh));

  // Blend ridged spherical mountain detail + FBM + micro-grain
  const ridgedLand = createSphericalNoiseCanvas(768, 384, 14, 77, 1.85, 5, true);
  ctx.save();
  ctx.globalAlpha = 0.22;
  ctx.globalCompositeOperation = 'overlay';
  ctx.drawImage(ridgedLand, 0, 0, w, h);
  ctx.restore();

  const micro = createMicroGrainCanvas(256, 41);
  const microPat = ctx.createPattern(micro, 'repeat');
  if (microPat) {
    ctx.save();
    ctx.globalAlpha = 0.12;
    ctx.globalCompositeOperation = 'overlay';
    ctx.fillStyle = microPat;
    ctx.fillRect(0, 0, w, h);
    ctx.restore();
  }

  bCtx.save();
  bCtx.globalAlpha = 0.52;
  bCtx.globalCompositeOperation = 'overlay';
  bCtx.drawImage(ridgedLand, 0, 0, bw, bh);
  bCtx.restore();

  drawGraticule(ctx, w, h, 'rgba(56, 189, 248, 0.08)');

  // 8. High-detail Cloud Layer (1536x768)
  const cw = 1536;
  const ch = 768;
  const cloudCanvas = document.createElement('canvas');
  cloudCanvas.width = cw;
  cloudCanvas.height = ch;
  const cCtx = cloudCanvas.getContext('2d')!;
  const cImg = cCtx.createImageData(cw, ch);
  const cData = cImg.data;
  for (let py = 0; py < ch; py++) {
    const theta = (py / ch) * Math.PI;
    const latRad = Math.PI / 2 - theta;
    const sinT = Math.sin(theta);
    const cosT = Math.cos(theta);
    const band = 0.56 + 0.24 * Math.cos(latRad * 3.2) + 0.14 * Math.sin(latRad * 6.0);
    for (let px = 0; px < cw; px++) {
      const phi = (px / cw) * Math.PI * 2;
      const wx = sinT * Math.cos(phi);
      const wy = cosT;
      const wz = sinT * Math.sin(phi);
      const warp = fbm3(wx * 3.2, wy * 3.2, wz * 3.2, 203, 3) * 0.58;
      const n = fbm3((wx + warp) * 5.6, wy * 7.2, (wz - warp) * 5.6, 419, 5);
      const density = THREE.MathUtils.clamp((n * band - 0.36) * 2.35, 0, 1);
      const alpha = Math.round(Math.pow(density, 1.35) * 208);
      const idx = (py * cw + px) * 4;
      cData[idx] = 244;
      cData[idx + 1] = 248;
      cData[idx + 2] = 255;
      cData[idx + 3] = alpha;
    }
  }
  cCtx.putImageData(cImg, 0, 0);

  return {
    map: toCanvasTexture(albedoCanvas, true),
    bumpMap: toCanvasTexture(bumpCanvas, false),
    roughnessMap: toCanvasTexture(roughCanvas, false),
    cloudMap: toCanvasTexture(cloudCanvas, true),
  };
}

function createMarsTextures(options: {
  showMolaElevation?: boolean;
  showObservationOverlay?: boolean;
}): PlanetaryTextureSet {
  const w = 4096;
  const h = 2048;
  const bw = 2048;
  const bh = 1024;
  const rw = 1024;
  const rh = 512;

  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = bw;
  bumpCanvas.height = bh;
  const bCtx = bumpCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = rw;
  roughCanvas.height = rh;
  const rCtx = roughCanvas.getContext('2d')!;

  const marsGrad = ctx.createLinearGradient(0, 0, 0, h);
  marsGrad.addColorStop(0, '#cbb6a0');
  marsGrad.addColorStop(0.14, '#a25636');
  marsGrad.addColorStop(0.45, '#bd633b');
  marsGrad.addColorStop(0.86, '#8e4429');
  marsGrad.addColorStop(1, '#cbb7a4');
  ctx.fillStyle = marsGrad;
  ctx.fillRect(0, 0, w, h);

  const bGrad = bCtx.createLinearGradient(0, 0, 0, bh);
  bGrad.addColorStop(0, '#444444');
  bGrad.addColorStop(0.45, '#686868');
  bGrad.addColorStop(0.65, '#929292');
  bGrad.addColorStop(1, '#848484');
  bCtx.fillStyle = bGrad;
  bCtx.fillRect(0, 0, bw, bh);

  rCtx.fillStyle = '#e6e6e6';
  rCtx.fillRect(0, 0, rw, rh);

  const dustNoise = createSphericalNoiseCanvas(768, 384, 8.4, 313, 1.65, 5);
  const highlandRidges = createSphericalNoiseCanvas(768, 384, 13.5, 331, 1.85, 5, true);
  ctx.save();
  ctx.globalAlpha = 0.34;
  ctx.globalCompositeOperation = 'overlay';
  ctx.drawImage(dustNoise, 0, 0, w, h);
  ctx.globalAlpha = 0.2;
  ctx.drawImage(highlandRidges, 0, 0, w, h);
  ctx.restore();

  bCtx.save();
  bCtx.globalAlpha = 0.48;
  bCtx.globalCompositeOperation = 'overlay';
  bCtx.drawImage(dustNoise, 0, 0, bw, bh);
  bCtx.globalAlpha = 0.38;
  bCtx.drawImage(highlandRidges, 0, 0, bw, bh);
  bCtx.restore();

  if (options.showMolaElevation) {
    const molaGrad = ctx.createLinearGradient(0, 0, 0, h);
    molaGrad.addColorStop(0.08, 'rgba(30, 96, 148, 0.54)');
    molaGrad.addColorStop(0.42, 'rgba(42, 145, 140, 0.42)');
    molaGrad.addColorStop(0.62, 'rgba(218, 148, 52, 0.43)');
    molaGrad.addColorStop(0.92, 'rgba(188, 66, 36, 0.44)');
    ctx.fillStyle = molaGrad;
    ctx.fillRect(0, 0, w, h);
  }

  // Syrtis Major Planum (8.4° N, 69.5° E) + windblown basalt streaks
  drawPolygon(
    ctx,
    [[58, 22], [72, 20], [75, 8], [71, -1], [63, -3], [56, 9]],
    w,
    h,
    'rgba(50, 24, 18, 0.76)',
  );
  drawSoftBlob(bCtx, 66, 10, 10, 11, bw, bh, 'rgba(175,175,175,0.48)', 'rgba(0,0,0,0)');

  // Acidalia, Utopia, Mare Erythraeum, Solis Planum & dark wind streaks
  drawPolygon(ctx, [[-46, 56], [-8, 59], [6, 44], [-18, 34], [-48, 42]], w, h, 'rgba(56, 28, 20, 0.64)');
  drawSoftBlob(ctx, 118, 46, 28, 16, w, h, 'rgba(136, 78, 52, 0.45)', 'rgba(0,0,0,0)');
  drawSoftBlob(ctx, 118, 46, 28, 16, bw, bh, 'rgba(42,42,42,0.55)', 'rgba(0,0,0,0)');
  drawPolygon(ctx, [[-52, -9], [-12, -7], [28, -10], [48, -22], [10, -28], [-55, -21]], w, h, 'rgba(60, 28, 20, 0.58)');
  drawSoftBlob(ctx, 155, 8, 9, 4, w, h, 'rgba(64, 30, 20, 0.52)', 'rgba(0,0,0,0)');

  // Isidis Planitia (~12.9° N, 87.0° E)
  drawSoftBlob(
    ctx,
    87.0,
    12.9,
    11,
    9.5,
    w,
    h,
    options.showMolaElevation ? 'rgba(38, 138, 152, 0.72)' : 'rgba(156, 96, 62, 0.58)',
    'rgba(0,0,0,0)',
  );
  drawSoftBlob(bCtx, 87.0, 12.9, 11, 9.5, bw, bh, 'rgba(38,38,38,0.68)', 'rgba(0,0,0,0)');

  // Hellas & Argyre
  drawSoftBlob(ctx, 70.5, -42.4, 20, 15, w, h, options.showMolaElevation ? 'rgba(26, 94, 178, 0.82)' : 'rgba(182, 122, 88, 0.55)', 'rgba(0,0,0,0)');
  drawSoftBlob(bCtx, 70.5, -42.4, 20, 15, bw, bh, 'rgba(16,16,16,0.9)', 'rgba(0,0,0,0)');
  drawSoftBlob(ctx, 316, -49.7, 10, 8, w, h, options.showMolaElevation ? 'rgba(35, 112, 172, 0.72)' : 'rgba(165, 102, 72, 0.5)', 'rgba(0,0,0,0)');
  drawSoftBlob(bCtx, 316, -49.7, 10, 8, bw, bh, 'rgba(26,26,26,0.78)', 'rgba(0,0,0,0)');

  // Tharsis Volcanic Rise & Shield Volcanoes
  drawSoftBlob(ctx, 250, 4, 24, 22, w, h, 'rgba(218, 124, 78, 0.52)', 'rgba(0,0,0,0)');
  drawSoftBlob(bCtx, 250, 4, 24, 22, bw, bh, 'rgba(212,212,212,0.7)', 'rgba(0,0,0,0)');

  const volcanoes: Array<[number, number, number]> = [
    [226.2, 18.65, 8.8], // Olympus Mons
    [255.9, 11.9, 4.4],  // Ascraeus Mons
    [247.0, 1.5, 4.1],   // Pavonis Mons
    [239.9, -8.3, 4.6],  // Arsia Mons
    [147.2, 25.0, 5.2],  // Elysium Mons
  ];
  volcanoes.forEach(([lon, lat, radDeg]) => {
    drawSoftBlob(ctx, lon, lat, radDeg, radDeg, w, h, options.showMolaElevation ? 'rgba(248, 250, 252, 0.92)' : 'rgba(224, 146, 104, 0.86)', 'rgba(0,0,0,0)');
    drawSoftBlob(bCtx, lon, lat, radDeg, radDeg, bw, bh, 'rgba(255,255,255,0.96)', 'rgba(0,0,0,0)');
    const vx = lonToX(lon, w);
    const vy = latToY(lat, h);
    ctx.fillStyle = 'rgba(65, 28, 18, 0.72)';
    ctx.beginPath();
    ctx.arc(vx, vy, radDeg * 1.1, 0, Math.PI * 2);
    ctx.fill();
  });

  // Valles Marineris multi-branch rift canyon + Kasei Vallis outflow
  const drawCanyon = (targetCtx: CanvasRenderingContext2D, sx: number, sy: number, strokeCol: string, lw: number) => {
    targetCtx.save();
    targetCtx.strokeStyle = strokeCol;
    targetCtx.lineCap = 'round';
    targetCtx.lineWidth = lw;
    targetCtx.beginPath();
    targetCtx.moveTo(lonToX(264, sx), latToY(-9.2, sy));
    targetCtx.bezierCurveTo(
      lonToX(282, sx), latToY(-14.2, sy),
      lonToX(302, sx), latToY(-12.8, sy),
      lonToX(322, sx), latToY(-16.2, sy),
    );
    targetCtx.stroke();

    targetCtx.lineWidth = lw * 0.52;
    targetCtx.beginPath();
    targetCtx.moveTo(lonToX(283, sx), latToY(-7.2, sy));
    targetCtx.lineTo(lonToX(305, sx), latToY(-9.2, sy));
    targetCtx.moveTo(lonToX(318, sx), latToY(-15.0, sy));
    targetCtx.quadraticCurveTo(lonToX(332, sx), latToY(-4.0, sy), lonToX(338, sx), latToY(12.0, sy));
    targetCtx.moveTo(lonToX(285, sx), latToY(6.0, sy));
    targetCtx.quadraticCurveTo(lonToX(292, sx), latToY(18.0, sy), lonToX(306, sx), latToY(23.0, sy));
    targetCtx.stroke();
    targetCtx.restore();
  };
  drawCanyon(ctx, w, h, 'rgba(38, 14, 10, 0.88)', 13);
  drawCanyon(bCtx, bw, bh, 'rgba(10, 10, 10, 0.94)', 8);

  // HIGH-DETAIL JEZERO CRATER & WESTERN DELTA FAN (18.4° N, 77.6° E)
  {
    const jx = lonToX(77.6, w);
    const jy = latToY(18.4, h);
    drawCrater(ctx, bCtx, jx, jy, 14, w, bw, {
      rimLight: 'rgba(242, 198, 152, 0.8)',
      floorDark: 'rgba(92, 46, 28, 0.72)',
      depthStrength: 0.85,
    });
    ctx.save();
    ctx.strokeStyle = 'rgba(218, 168, 118, 0.8)';
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.moveTo(jx - 22, jy - 3);
    ctx.lineTo(jx - 8, jy - 1);
    ctx.stroke();
    ctx.fillStyle = 'rgba(212, 162, 114, 0.72)';
    ctx.beginPath();
    ctx.moveTo(jx - 8, jy - 1);
    ctx.lineTo(jx - 1, jy - 5);
    ctx.lineTo(jx - 1, jy + 4);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  // 1,650 Multi-scale Martian craters
  for (let i = 0; i < 1650; i++) {
    const u = ((i * 2654435761) >>> 0) / 4294967295;
    const v = (((i + 97) * 2246822519) >>> 0) / 4294967295;
    const cx = u * w;
    const latBias = i % 3 === 0 ? v : 0.4 + v * 0.54;
    const cy = 85 + latBias * (h - 170);
    const radius = i % 37 === 0 ? 18 + (i % 24) : i % 8 === 0 ? 7 + (i % 9) : 2.2 + (i % 5);
    drawCrater(ctx, bCtx, cx, cy, radius, w, bw, {
      rimLight: 'rgba(235, 175, 132, 0.3)',
      floorDark: 'rgba(54, 22, 14, 0.36)',
      centralPeak: i % 37 === 0,
      depthStrength: i % 37 === 0 ? 0.78 : 0.48,
    });
  }

  // Micro grain for close-up inspection
  const micro = createMicroGrainCanvas(256, 73);
  const microPat = ctx.createPattern(micro, 'repeat');
  if (microPat) {
    ctx.save();
    ctx.globalAlpha = 0.14;
    ctx.globalCompositeOperation = 'overlay';
    ctx.fillStyle = microPat;
    ctx.fillRect(0, 0, w, h);
    ctx.restore();
  }

  // Polar CO2/Water Ice Caps
  const drawPolarCap = (yStart: number, yEnd: number) => {
    const capGrad = ctx.createLinearGradient(0, yStart, 0, yEnd);
    if (yStart === 0) {
      capGrad.addColorStop(0, '#eef2f6');
      capGrad.addColorStop(0.7, '#d8dfe6');
      capGrad.addColorStop(1, 'rgba(216, 223, 230, 0)');
    } else {
      capGrad.addColorStop(0, 'rgba(216, 223, 230, 0)');
      capGrad.addColorStop(0.3, '#d8dfe6');
      capGrad.addColorStop(1, '#eef2f6');
    }
    ctx.fillStyle = capGrad;
    ctx.fillRect(0, yStart, w, yEnd - yStart);
  };
  drawPolarCap(0, latToY(80, h));
  drawPolarCap(latToY(-81, h), h);

  ctx.strokeStyle = 'rgba(130, 72, 48, 0.45)';
  ctx.lineWidth = 3;
  for (let s = 0; s < 16; s++) {
    const sx = (s / 16) * w;
    ctx.beginPath();
    ctx.moveTo(sx, latToY(87, h));
    ctx.lineTo(sx + 110, latToY(82.5, h));
    ctx.stroke();
  }

  if (options.showObservationOverlay) {
    const jx = lonToX(77.6, w);
    const jy = latToY(18.4, h);
    const box = 44;
    ctx.save();
    ctx.fillStyle = 'rgba(10, 15, 28, 0.82)';
    ctx.fillRect(jx - box / 2, jy - box / 2, box, box);
    for (let r = 0; r < 14; r++) {
      for (let c = 0; c < 14; c++) {
        const observed = (r * 7 + c * 11) % 100 < 38;
        ctx.fillStyle = observed ? '#22d3ee' : 'rgba(245, 158, 11, 0.45)';
        ctx.fillRect(jx - box / 2 + c * 3.1, jy - box / 2 + r * 3.1, 2.7, 2.7);
      }
    }
    ctx.restore();
  }

  drawGraticule(ctx, w, h, 'rgba(251, 146, 60, 0.09)');

  return {
    map: toCanvasTexture(canvas, true),
    bumpMap: toCanvasTexture(bumpCanvas, false),
    roughnessMap: toCanvasTexture(roughCanvas, false),
  };
}

function createMoonTextures(options: { showMolaElevation?: boolean }): PlanetaryTextureSet {
  const w = 4096;
  const h = 2048;
  const bw = 2048;
  const bh = 1024;
  const rw = 1024;
  const rh = 512;

  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = bw;
  bumpCanvas.height = bh;
  const bCtx = bumpCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = rw;
  roughCanvas.height = rh;
  const rCtx = roughCanvas.getContext('2d')!;

  ctx.fillStyle = '#6f7580';
  ctx.fillRect(0, 0, w, h);

  bCtx.fillStyle = '#8c8c8c';
  bCtx.fillRect(0, 0, bw, bh);

  rCtx.fillStyle = '#efefef';
  rCtx.fillRect(0, 0, rw, rh);

  const regNoise = createSphericalNoiseCanvas(768, 384, 9.5, 509, 1.75, 5);
  const lunarRidges = createSphericalNoiseCanvas(768, 384, 14.0, 521, 1.95, 5, true);
  ctx.save();
  ctx.globalAlpha = 0.34;
  ctx.globalCompositeOperation = 'overlay';
  ctx.drawImage(regNoise, 0, 0, w, h);
  ctx.globalAlpha = 0.24;
  ctx.drawImage(lunarRidges, 0, 0, w, h);
  ctx.restore();

  bCtx.save();
  bCtx.globalAlpha = 0.5;
  bCtx.globalCompositeOperation = 'overlay';
  bCtx.drawImage(regNoise, 0, 0, bw, bh);
  bCtx.globalAlpha = 0.42;
  bCtx.drawImage(lunarRidges, 0, 0, bw, bh);
  bCtx.restore();

  if (options.showMolaElevation) {
    const lolaGrad = ctx.createLinearGradient(0, 0, 0, h);
    lolaGrad.addColorStop(0, 'rgba(56, 189, 248, 0.16)');
    lolaGrad.addColorStop(0.55, 'rgba(148, 163, 184, 0.08)');
    lolaGrad.addColorStop(0.85, 'rgba(59, 130, 246, 0.25)');
    lolaGrad.addColorStop(1, 'rgba(30, 64, 175, 0.32)');
    ctx.fillStyle = lolaGrad;
    ctx.fillRect(0, 0, w, h);
  }

  // South Pole-Aitken Basin
  drawSoftBlob(ctx, 191, -53, 44, 30, w, h, 'rgba(38, 44, 54, 0.72)', 'rgba(0,0,0,0)');
  drawSoftBlob(bCtx, 191, -53, 44, 30, bw, bh, 'rgba(24,24,24,0.85)', 'rgba(0,0,0,0)');

  // Major lunar basaltic Maria
  const maria: Array<[number, number, number, number]> = [
    [-25, 18, 32, 26],
    [-16, 36, 16, 13],
    [18, 26, 13, 11],
    [31, 8.5, 14, 11],
    [59, 17, 8, 7],
    [-39, -24, 14, 10],
    [-14, -21, 12, 10],
    [51, -8, 11, 10],
    [34, -15, 9, 8],
    [265, -19, 10, 9],
  ];
  maria.forEach(([lon, lat, rxDeg, ryDeg]) => {
    drawSoftBlob(ctx, lon, lat, rxDeg, ryDeg, w, h, 'rgba(34, 39, 48, 0.86)', 'rgba(0,0,0,0)');
    drawSoftBlob(bCtx, lon, lat, rxDeg, ryDeg, bw, bh, 'rgba(48,48,48,0.72)', 'rgba(0,0,0,0)');
  });

  // Mare Orientale multi-ring bullseye basin (-19° S, 265° E)
  ctx.save();
  ctx.strokeStyle = 'rgba(204, 212, 224, 0.38)';
  ctx.lineWidth = 4;
  [12, 22, 32].forEach((rPx) => {
    ctx.beginPath();
    ctx.arc(lonToX(265, w), latToY(-19, h), rPx, 0, Math.PI * 2);
    ctx.stroke();
  });
  ctx.restore();

  // Wrinkle ridges (Dorsa) across Mare Tranquillitatis & Serenitatis
  ctx.save();
  ctx.strokeStyle = 'rgba(156, 170, 188, 0.42)';
  ctx.lineWidth = 2.0;
  ctx.beginPath();
  ctx.moveTo(lonToX(26, w), latToY(3, h));
  ctx.quadraticCurveTo(lonToX(31, w), latToY(8.5, h), lonToX(35, w), latToY(15, h));
  ctx.moveTo(lonToX(14, w), latToY(21, h));
  ctx.quadraticCurveTo(lonToX(22, w), latToY(26, h), lonToX(24, w), latToY(33, h));
  ctx.stroke();
  ctx.restore();

  // Montes Apenninus arc
  ctx.save();
  ctx.strokeStyle = 'rgba(222, 228, 236, 0.65)';
  ctx.lineWidth = 8;
  ctx.beginPath();
  ctx.moveTo(lonToX(-12, w), latToY(14, h));
  ctx.quadraticCurveTo(lonToX(-2, w), latToY(20, h), lonToX(6, w), latToY(28, h));
  ctx.stroke();
  ctx.restore();

  bCtx.save();
  bCtx.strokeStyle = 'rgba(244, 244, 244, 0.88)';
  bCtx.lineWidth = 6;
  bCtx.beginPath();
  bCtx.moveTo(lonToX(-12, bw), latToY(14, bh));
  bCtx.quadraticCurveTo(lonToX(-2, bw), latToY(20, bh), lonToX(6, bw), latToY(28, bh));
  bCtx.stroke();
  bCtx.restore();

  // Ray craters (Tycho, Copernicus, Kepler, Aristarchus)
  const rayCraters: Array<[number, number, number, number]> = [
    [-11.2, -43.3, 18, 310],
    [-20.0, 9.6, 16, 240],
    [-38.0, 8.1, 12, 145],
    [-47.4, 23.7, 12, 165],
  ];
  rayCraters.forEach(([lon, lat, spokes, reach]) => {
    const rx = lonToX(lon, w);
    const ry = latToY(lat, h);
    ctx.save();
    ctx.strokeStyle = 'rgba(232, 238, 246, 0.27)';
    ctx.lineWidth = 2.0;
    for (let s = 0; s < spokes; s++) {
      const ang = (s / spokes) * Math.PI * 2 + (s % 3) * 0.11;
      const len = reach * (0.55 + ((s * 37) % 45) / 100);
      ctx.beginPath();
      ctx.moveTo(rx, ry);
      ctx.lineTo(rx + Math.cos(ang) * len, ry + Math.sin(ang) * len * 0.72);
      ctx.stroke();
    }
    ctx.restore();
  });

  // 2,100 Multi-scale lunar craters
  for (let i = 0; i < 2100; i++) {
    const u = ((i * 2654435761) >>> 0) / 4294967295;
    const v = (((i + 131) * 2246822519) >>> 0) / 4294967295;
    const cx = u * w;
    const cy = 44 + v * (h - 88);
    const radius = i % 41 === 0 ? 22 + (i % 24) : i % 9 === 0 ? 8 + (i % 10) : 2.3 + (i % 5);
    drawCrater(ctx, bCtx, cx, cy, radius, w, bw, {
      rimLight: 'rgba(226, 232, 240, 0.36)',
      floorDark: 'rgba(18, 22, 28, 0.44)',
      centralPeak: i % 41 === 0,
      depthStrength: i % 41 === 0 ? 0.86 : 0.54,
    });
  }

  // Shackleton Crater accent (-89.54° S, 129.78° E)
  drawCrater(ctx, bCtx, lonToX(129.78, w), latToY(-89.54, h), 22, w, bw, {
    rimLight: 'rgba(241, 245, 249, 0.82)',
    floorDark: 'rgba(10, 14, 22, 0.9)',
    depthStrength: 0.94,
  });

  // Micro regolith grain
  const micro = createMicroGrainCanvas(256, 107);
  const microPat = ctx.createPattern(micro, 'repeat');
  if (microPat) {
    ctx.save();
    ctx.globalAlpha = 0.16;
    ctx.globalCompositeOperation = 'overlay';
    ctx.fillStyle = microPat;
    ctx.fillRect(0, 0, w, h);
    ctx.restore();
  }

  drawGraticule(ctx, w, h, 'rgba(148, 163, 184, 0.1)');

  return {
    map: toCanvasTexture(canvas, true),
    bumpMap: toCanvasTexture(bumpCanvas, false),
    roughnessMap: toCanvasTexture(roughCanvas, false),
  };
}

function toCanvasTexture(canvas: HTMLCanvasElement, isSrgb: boolean): THREE.CanvasTexture {
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = isSrgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Generates paired 4K albedo, 2K elevation bump, roughness, and Earth cloud textures.
 */
export function createPlanetaryTextures(
  body: CelestialBodyId,
  options: { showMolaElevation?: boolean; showObservationOverlay?: boolean } = {},
): PlanetaryTextureSet {
  if (body === 'earth') return createEarthTextures();
  if (body === 'mars') return createMarsTextures(options);
  return createMoonTextures(options);
}
