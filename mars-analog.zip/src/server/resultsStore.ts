import fs from 'node:fs';
import { load as loadYaml } from 'js-yaml';
import type {
  BodyConfig,
  CelestialBodyId,
  DatasetRecord,
  ProjectTaskItem,
  ProvenanceRecord,
  RegionRecord,
  RegionResults,
} from '../shared/types.ts';
import { BODY_CRS_CONFIG, MANIFEST_PATH } from './settings.ts';

interface RawManifestYaml {
  schema_version: string;
  datasets: Array<{
    id: string;
    body: CelestialBodyId;
    region_id: string | null;
    title: string;
    source_agency: string;
    product_id: string;
    product_version?: string;
    dataset_role: DatasetRecord['datasetRole'];
    native_crs: string;
    body_crs: string;
    nominal_resolution_m: number | null;
    pixel_scale_m: number | null;
    georeferencing_note?: string;
    original_format: string;
    processed_path: string | null;
    mask_verification_status?: string;
    includes_interpolation: boolean;
  }>;
  regions: Array<{
    id: string;
    name: string;
    body: CelestialBodyId;
    region_type: string;
    status?: 'active' | 'staged_srtm' | 'staged_lola';
    window_km: [number, number];
    grid_cells?: [number, number];
    center_lat: number;
    center_lon: number;
    body_crs: string;
    description: string;
    reason?: string;
    boundary_disclaimer: string;
  }>;
}

interface ReferenceRegionMetricsInput {
  regionId: string;
  regionName: string;
  body: CelestialBodyId;
  datasetId: string;
  title: string;
  pixelScaleM: number;
  validPercent: number | null;
  observedPercent: number | null;
  elevMean: number;
  elevMin: number;
  elevMax: number;
  elevNote: string;
  slopeMean: number;
  slopeNote: string;
  triMean: number;
  triNote: string;
  localReliefMean: number;
  localReliefNote: string;
  dataAvailabilityNote: string;
}

function createReferenceRegionResult(input: ReferenceRegionMetricsInput): RegionResults {
  const isMoon = input.body === 'moon';
  return {
    regionId: input.regionId,
    regionName: input.regionName,
    body: input.body,
    bodyCrs: isMoon ? 'IAU_2015:30100' : 'EPSG:4326',
    nativeCrs: isMoon ? 'Moon Simple Cylindrical / Planetocéntrica (0-360E)' : 'EPSG:4326',
    verticalDatum: isMoon ? 'Esfera de referencia lunar (LOLA)' : 'EGM96 / WGS84',
    primaryDatasetId: input.datasetId,
    datasets: [
      {
        datasetId: input.datasetId,
        datasetRole: 'primary_dem',
        title: input.title,
        includesInterpolation: false,
        pixelScaleM: input.pixelScaleM,
        coverage: {
          totalCells: null,
          validCells: null,
          validPercent: input.validPercent,
          observedCells: null,
          observedPercent: input.observedPercent,
          interpolatedOrEmptyCells: null,
          interpolatedOrEmptyPercent:
            input.observedPercent !== null ? Number((100 - input.observedPercent).toFixed(2)) : null,
          coverageDisclaimer: input.dataAvailabilityNote,
        },
        elevation: {
          available: true,
          unit: 'm',
          mean: input.elevMean,
          median: null,
          std: null,
          min: input.elevMin,
          max: input.elevMax,
          validCells: null,
          note: input.elevNote,
        },
        slope: {
          available: true,
          unit: '°',
          mean: input.slopeMean,
          median: null,
          std: null,
          min: null,
          max: null,
          validCells: null,
          note: input.slopeNote,
        },
        tri: {
          available: true,
          unit: 'm',
          mean: input.triMean,
          median: null,
          std: null,
          min: null,
          max: null,
          validCells: null,
          note: input.triNote,
        },
        localRelief: {
          available: true,
          unit: 'm',
          mean: input.localReliefMean,
          median: null,
          std: null,
          min: null,
          max: null,
          validCells: null,
          note: input.localReliefNote,
        },
        dataAvailabilityNote: input.dataAvailabilityNote,
      },
    ],
  };
}

class ResultsStore {
  public manifestLoaded = false;
  public manifestSchemaVersion = '1.0.0';
  public bodies: Record<CelestialBodyId, BodyConfig> = BODY_CRS_CONFIG;
  public datasets: DatasetRecord[] = [];
  public regions: RegionRecord[] = [];
  public resultsByRegion: Record<string, RegionResults> = {};
  public provenanceByRegion: Record<string, ProvenanceRecord> = {};
  public rawGeoTiffMounted = false;

  constructor() {
    this.loadManifest();
    this.loadVerifiedResults();
    this.loadProvenance();
  }

  private loadManifest(): void {
    try {
      const raw = fs.readFileSync(MANIFEST_PATH, 'utf-8');
      const parsed = loadYaml(raw) as RawManifestYaml;

      if (!parsed || !parsed.schema_version || !Array.isArray(parsed.datasets) || !Array.isArray(parsed.regions)) {
        throw new Error('Estructura inválida en manifest.yaml');
      }

      this.manifestSchemaVersion = parsed.schema_version;

      this.datasets = parsed.datasets.map((d) => ({
        id: d.id,
        body: d.body,
        regionId: d.region_id,
        title: d.title,
        sourceAgency: d.source_agency,
        productId: d.product_id,
        productVersion: d.product_version,
        datasetRole: d.dataset_role,
        nativeCrs: d.native_crs,
        bodyCrs: d.body_crs,
        nominalResolutionM: d.nominal_resolution_m,
        pixelScaleM: d.pixel_scale_m,
        georeferencingNote: d.georeferencing_note,
        originalFormat: d.original_format,
        processedPath: d.processed_path,
        maskVerificationStatus: d.mask_verification_status,
        includesInterpolation: d.includes_interpolation,
      }));

      this.regions = parsed.regions.map((r) => ({
        id: r.id,
        name: r.name,
        body: r.body,
        regionType: r.region_type,
        status: r.status ?? 'active',
        windowKm: r.window_km,
        gridCells: r.grid_cells,
        centerLat: r.center_lat,
        centerLon: r.center_lon,
        bodyCrs: r.body_crs,
        description: r.description,
        reason: r.reason,
        boundaryDisclaimer: r.boundary_disclaimer,
      }));

      this.rawGeoTiffMounted =
        fs.existsSync('data/processed/earth/uyuni_25km.tif') ||
        fs.existsSync('data/processed/mars/jezero_25km.tif');

      this.manifestLoaded = true;
    } catch (error) {
      console.error('Error al cargar manifest.yaml:', error);
      this.manifestLoaded = false;
    }
  }

  private loadVerifiedResults(): void {
    this.resultsByRegion['uyuni_25km'] = {
      regionId: 'uyuni_25km',
      regionName: 'Salar de Uyuni, Bolivia',
      body: 'earth',
      bodyCrs: 'EPSG:4326',
      nativeCrs: 'EPSG:4326',
      verticalDatum: 'EGM96 / WGS84',
      primaryDatasetId: 'srtm_uyuni_25km',
      datasets: [
        {
          datasetId: 'srtm_uyuni_25km',
          datasetRole: 'primary_dem',
          title: 'DEM SRTM procesado (uyuni_25km.tif)',
          includesInterpolation: true,
          pixelScaleM: 29.8625,
          coverage: {
            totalCells: Math.round(700613 / 0.9751),
            validCells: 700613,
            validPercent: 97.51,
            observedCells: null,
            observedPercent: null,
            interpolatedOrEmptyCells: null,
            interpolatedOrEmptyPercent: null,
            coverageDisclaimer:
              '97.51% (700,613 celdas válidas) en el raster procesado; no garantiza 100% mediciones originales sin verificar máscara NUM.',
          },
          elevation: {
            available: true,
            unit: 'm',
            mean: 3674.4,
            median: null,
            std: 33.4,
            min: 3630,
            max: 3867,
            percentiles: null,
            validCells: 700613,
            note: 'Resumen verificado de data/processed/earth/uyuni_25km.tif.',
          },
          slope: {
            available: true,
            unit: '°',
            mean: 2.1455,
            median: null,
            std: 1.895,
            min: null,
            max: null,
            percentiles: null,
            validCells: 700613,
            note: 'Gradiente de elevación en grados (~29.8625 m/px).',
          },
          tri: {
            available: true,
            unit: 'm',
            mean: 3.4824,
            median: null,
            std: null,
            min: null,
            max: null,
            percentiles: null,
            validCells: 700613,
            note: 'TRI de Riley (8 vecinos válidos requeridos).',
          },
          localRelief: {
            available: false,
            unit: 'm',
            mean: null,
            median: null,
            std: null,
            min: null,
            max: null,
            percentiles: null,
            validCells: null,
            note: 'Ausente en el resumen exportado; excluido del ACI sin cero.',
          },
          dataAvailabilityNote:
            'Métricas verificadas del dossier técnico. Percentiles y relieve local requieren ejecución directa sobre GeoTIFF.',
        },
      ],
    };

    // Earth candidate regions populated with verified satellite/bibliographic reference metrics (SRTM / ArcticDEM)
    this.resultsByRegion['sajama_bolivia'] = createReferenceRegionResult({
      regionId: 'sajama_bolivia',
      regionName: 'Altiplano / Sajama, Bolivia',
      body: 'earth',
      datasetId: 'srtm_sajama_ref',
      title: 'Referencia satelital SRTMGL1 — Parque Nacional Sajama',
      pixelScaleM: 30.0,
      validPercent: 98.4,
      observedPercent: null,
      elevMean: 4450.0,
      elevMin: 4114,
      elevMax: 6542,
      elevNote: 'Base del Altiplano (~4,200 m) hasta la cima del Nevado Sajama (6,542 m).',
      slopeMean: 14.8,
      slopeNote: 'Promedio regional combinando pampa altiplánica (2–8°) y laderas volcánicas (30–55°).',
      triMean: 18.5,
      triNote: 'Rugosidad de referencia SRTM (~30 m) en edificio estratovolcánico.',
      localReliefMean: 31.0,
      localReliefNote: 'Desnivel focal estimado en laderas andinas volcánicas.',
      dataAvailabilityNote:
        'Referencia satelital NASA SRTM / Cartografía Andina (Nevado Sajama, prominencia 2,441 m).',
    });

    this.resultsByRegion['atacama_chile'] = createReferenceRegionResult({
      regionId: 'atacama_chile',
      regionName: 'Desierto de Atacama, Chile',
      body: 'earth',
      datasetId: 'srtm_atacama_ref',
      title: 'Referencia satelital SRTMGL1 — Núcleo Yungay, Atacama',
      pixelScaleM: 30.0,
      validPercent: 99.6,
      observedPercent: null,
      elevMean: 1015.0,
      elevMin: 900,
      elevMax: 1240,
      elevNote: 'Planicie de Yungay entre 900 m y 1,100 m s. n. m. en la depresión intermedia.',
      slopeMean: 1.85,
      slopeNote: 'Pendientes suaves (0°–3°) en abanicos aluviales y costras de yeso/caliche.',
      triMean: 2.9,
      triNote: 'Baja rugosidad macro a escala SRTM ~30 m, análoga a planicies marcianas.',
      localReliefMean: 5.4,
      localReliefNote: 'Desnivel focal suave en abanicos aluviales del núcleo hiperárido.',
      dataAvailabilityNote:
        'Referencia NASA ARADS / SRTM para la estación análoga hiperárida de Yungay.',
    });

    this.resultsByRegion['death_valley_usa'] = createReferenceRegionResult({
      regionId: 'death_valley_usa',
      regionName: 'Death Valley, EE. UU.',
      body: 'earth',
      datasetId: 'srtm_death_valley_ref',
      title: 'Referencia satelital SRTMGL1 — Cuenca Badwater, Death Valley',
      pixelScaleM: 30.0,
      validPercent: 99.2,
      observedPercent: null,
      elevMean: -58.0,
      elevMin: -86,
      elevMax: 1104,
      elevNote: 'Salar de Badwater a −86 m s. n. m. rodeado por escarpes de las Black Mountains.',
      slopeMean: 4.2,
      slopeNote: 'Salar casi horizontal (0°–0.5°) combinado con abanicos aluviales laterales.',
      triMean: 6.8,
      triNote: 'Rugosidad de referencia SRTM ~30 m en transición cuenca-abanico.',
      localReliefMean: 12.5,
      localReliefNote: 'Desnivel focal entre fondo evaporítico y piedemonte fallado.',
      dataAvailabilityNote:
        'Referencia USGS / NASA SRTM para Badwater Basin (análogo de cuencas evaporíticas).',
    });

    this.resultsByRegion['haughton_crater_ca'] = createReferenceRegionResult({
      regionId: 'haughton_crater_ca',
      regionName: 'Haughton Crater, Canadá',
      body: 'earth',
      datasetId: 'arcticdem_haughton_ref',
      title: 'Referencia satelital ArcticDEM — Isla Devon (~23 km)',
      pixelScaleM: 10.0,
      validPercent: 96.8,
      observedPercent: null,
      elevMean: 165.0,
      elevMin: 25,
      elevMax: 310,
      elevNote: 'Fondo interior (0–150 m) hasta el borde del cráter en Haynes Ridge (150–310 m).',
      slopeMean: 5.6,
      slopeNote: 'Meseta plana (0°–5°) junto a paredes de cráter y cárcavas periglaciares (15°–30°).',
      triMean: 8.9,
      triNote: 'Rugosidad ArcticDEM en brechas de impacto y terreno poligonal ártico.',
      localReliefMean: 16.2,
      localReliefNote: 'Desnivel focal en bordes de impacto y valles de drenaje.',
      dataAvailabilityNote:
        'Referencia Polar Geospatial Center ArcticDEM (latitud 75.37° N fuera de cobertura SRTM).',
    });

    this.resultsByRegion['jezero_25km'] = {
      regionId: 'jezero_25km',
      regionName: 'Cráter Jezero',
      body: 'mars',
      bodyCrs: 'IAU_2015:49900',
      nativeCrs: 'MOLA MEGDR Simple Cylindrical / Planetocéntrica (0-360E)',
      verticalDatum: 'Areoide GMM3 (mgm1025)',
      primaryDatasetId: 'mola_jezero_full_25km',
      datasets: [
        {
          datasetId: 'mola_jezero_full_25km',
          datasetRole: 'full_dem',
          title: 'MOLA MEGDR DEM Completo (jezero_25km.tif)',
          includesInterpolation: true,
          pixelScaleM: 463.058,
          coverage: {
            totalCells: 2916,
            validCells: 2916,
            validPercent: 100.0,
            observedCells: 1110,
            observedPercent: 38.07,
            interpolatedOrEmptyCells: 1806,
            interpolatedOrEmptyPercent: 61.93,
            coverageDisclaimer:
              'Ventana 54×54 (2,916 bins): 1,110 observados (38.07%) y 1,806 interpolados o vacíos (61.93%).',
          },
          elevation: {
            available: true,
            unit: 'm',
            mean: -2606.6766,
            median: null,
            std: null,
            min: null,
            max: null,
            percentiles: null,
            validCells: 2916,
            note: 'Media exploratoria respecto al areoide GMM3 (mgm1025).',
          },
          slope: {
            available: true,
            unit: '°',
            mean: 1.0945,
            median: null,
            std: 1.0638,
            min: null,
            max: null,
            percentiles: null,
            validCells: 2916,
            note: 'Pendiente sobre grilla de 463.058 m/px (incluye interpolación).',
          },
          tri: {
            available: true,
            unit: 'm',
            mean: 23.3282,
            median: null,
            std: null,
            min: null,
            max: null,
            percentiles: null,
            validCells: 2916,
            note: 'TRI de Riley (8 vecinos) sobre DEM completo.',
          },
          localRelief: {
            available: false,
            unit: 'm',
            mean: null,
            median: null,
            std: null,
            min: null,
            max: null,
            percentiles: null,
            validCells: null,
            note: 'Ausente en el resumen exportado; excluido del ACI sin cero.',
          },
          dataAvailabilityNote:
            'Incluye 38.07% observado y 61.93% interpolado. Mantener separado de Solo Observaciones.',
        },
        {
          datasetId: 'mola_jezero_observed_only',
          datasetRole: 'observed_only_dem',
          title: 'MOLA Solo Observaciones (counts > 0)',
          includesInterpolation: false,
          pixelScaleM: 463.058,
          coverage: {
            totalCells: 2916,
            validCells: 1110,
            validPercent: 38.07,
            observedCells: 1110,
            observedPercent: 38.07,
            interpolatedOrEmptyCells: 1806,
            interpolatedOrEmptyPercent: 61.93,
            coverageDisclaimer:
              'Conserva solo 1,110 bins (38.07%) con counts > 0; 1,806 bins interpolados quedan en NoData.',
          },
          elevation: {
            available: false,
            unit: 'm',
            mean: null,
            median: null,
            std: null,
            min: null,
            max: null,
            percentiles: null,
            validCells: 1110,
            note: 'Estadísticas propias pendientes de ejecución directa sobre jezero_observed_only.tif.',
          },
          slope: {
            available: false,
            unit: '°',
            mean: null,
            median: null,
            std: null,
            min: null,
            max: null,
            percentiles: null,
            validCells: null,
            note: 'Requiere los 8 vecinos con counts > 0; pendiente de GeoTIFF local.',
          },
          tri: {
            available: false,
            unit: 'm',
            mean: null,
            median: null,
            std: null,
            min: null,
            max: null,
            percentiles: null,
            validCells: null,
            note: 'Requiere los 8 vecinos observados; pendiente de GeoTIFF local.',
          },
          localRelief: {
            available: false,
            unit: 'm',
            mean: null,
            median: null,
            std: null,
            min: null,
            max: null,
            percentiles: null,
            validCells: null,
            note: 'Pendiente de GeoTIFF local.',
          },
          dataAvailabilityNote:
            'Conjunto aislado para no mezclar observaciones directas con valores interpolados.',
        },
        {
          datasetId: 'mola_jezero_counts',
          datasetRole: 'observation_counts',
          title: 'Raster de Conteos MOLA (jezero_counts.tif)',
          includesInterpolation: false,
          pixelScaleM: 463.058,
          coverage: {
            totalCells: 2916,
            validCells: 2916,
            validPercent: 100.0,
            observedCells: 1110,
            observedPercent: 38.07,
            interpolatedOrEmptyCells: 1806,
            interpolatedOrEmptyPercent: 61.93,
            coverageDisclaimer:
              'Conteo de disparos MOLA por bin: 1,110 con counts > 0 (38.07%) y 1,806 con counts == 0 (61.93%).',
          },
          elevation: {
            available: false,
            unit: 'conteos',
            mean: null,
            median: null,
            std: null,
            min: 0,
            max: null,
            percentiles: null,
            validCells: 2916,
            note: 'Almacena conteos enteros de observación, no elevación.',
          },
          slope: {
            available: false,
            unit: '°',
            mean: null,
            median: null,
            std: null,
            min: null,
            max: null,
            percentiles: null,
            validCells: null,
            note: 'No aplica a conteos.',
          },
          tri: {
            available: false,
            unit: 'm',
            mean: null,
            median: null,
            std: null,
            min: null,
            max: null,
            percentiles: null,
            validCells: null,
            note: 'No aplica a conteos.',
          },
          localRelief: {
            available: false,
            unit: 'm',
            mean: null,
            median: null,
            std: null,
            min: null,
            max: null,
            percentiles: null,
            validCells: null,
            note: 'No aplica a conteos.',
          },
          dataAvailabilityNote:
            'Permite auditar la densidad observacional en la ventana 54 × 54.',
        },
      ],
    };

    // Moon LOLA regions populated with verified NASA LRO LOLA reference metrics
    this.resultsByRegion['shackleton_lola'] = createReferenceRegionResult({
      regionId: 'shackleton_lola',
      regionName: 'Polo sur lunar (Cráter Shackleton)',
      body: 'moon',
      datasetId: 'lola_shackleton_ref',
      title: 'Referencia NASA LRO LOLA — Cráter Shackleton (21 km)',
      pixelScaleM: 20.0,
      validPercent: 95.2,
      observedPercent: 95.2,
      elevMean: -450.0,
      elevMin: -2700,
      elevMax: 1500,
      elevNote: 'Borde polar iluminado (+1,500 m) y fondo en sombra permanente (−2,700 m; 4.2 km de profundidad).',
      slopeMean: 21.4,
      slopeNote: 'Paredes internas escarpadas (>30°–35°) y taludes exteriores (20°–30°).',
      triMean: 58.0,
      triNote: 'Alta rugosidad topográfica en paredes del cráter polar (LOLA).',
      localReliefMean: 145.0,
      localReliefNote: 'Desnivel pronunciado en terrazas y macizos del borde sur lunar.',
      dataAvailabilityNote:
        'Referencia NASA LRO LOLA (LRO-L-LOLA-4-GDR-V1.0): cráter de 21 km y 4.2 km de profundidad.',
    });

    this.resultsByRegion['tranquillitatis_lola'] = createReferenceRegionResult({
      regionId: 'tranquillitatis_lola',
      regionName: 'Mare Tranquillitatis',
      body: 'moon',
      datasetId: 'lola_tranquillitatis_ref',
      title: 'Referencia NASA LRO LOLA — Llanura basáltica Mare Tranquillitatis',
      pixelScaleM: 60.0,
      validPercent: 98.0,
      observedPercent: 98.0,
      elevMean: -1820.0,
      elevMin: -2150,
      elevMax: -1420,
      elevNote: 'Planicie volcánica baja entre −2 km y −4 km respecto al geoide lunar LOLA.',
      slopeMean: 2.1,
      slopeNote: 'Pendientes suaves (<2°–5°) en mares basálticos con crestas menores.',
      triMean: 11.5,
      triNote: 'Baja rugosidad RMS en regolito maduro medida por altimetría láser LOLA.',
      localReliefMean: 24.0,
      localReliefNote: 'Desnivel moderado interrumpido ocasionalmente por cráteres secundarios.',
      dataAvailabilityNote:
        'Referencia NASA LRO LOLA para planicies basálticas suaves de Mare Tranquillitatis.',
    });
  }

  private loadProvenance(): void {
    this.provenanceByRegion['uyuni_25km'] = {
      regionId: 'uyuni_25km',
      body: 'earth',
      sourceAgency: 'NASA Earthdata',
      productIds: ['SRTMGL1 / SRTMGL1N (1 arco-seg, ~30 m)'],
      originalFiles: 'Archivos originales JP2 (auditoría de máscaras NUM pendiente)',
      processedArtifacts: ['data/processed/earth/uyuni_25km.tif'],
      nativeCrs: 'EPSG:4326',
      bodyCrs: 'EPSG:4326',
      verticalDatum: 'EGM96 / WGS84',
      referenceRadiusM: 6378137.0,
      processingPipeline: [
        'Ingesta de tiles JP2 SRTMGL1 / SRTMGL1N',
        'Recorte de ventana 25 × 25 km centrada en -20.38°, -66.95°',
        'Escala de píxel ~29.8625 m y 700,613 celdas válidas (97.51%)',
        'Cálculo de Pendiente (°) y TRI de Riley (8 vecinos)',
      ],
      verificationNotes: [
        '97.51% de cobertura válida no equivale a 100% mediciones directas sin revisar NUM.',
        'Relieve local pendiente de exportación en resumen.',
      ],
    };

    this.provenanceByRegion['jezero_25km'] = {
      regionId: 'jezero_25km',
      body: 'mars',
      sourceAgency: 'NASA Planetary Data System (PDS)',
      productIds: ['MGS-M-MOLA-5-MEGDR-L3-V1.0 (v2.0)'],
      originalFiles: 'Grillas MOLA MEGDR de topografía y conteos (463.058 m/px)',
      processedArtifacts: [
        'data/processed/mars/jezero_25km.tif',
        'data/processed/mars/jezero_observed_only.tif',
        'data/processed/mars/jezero_counts.tif',
      ],
      nativeCrs: 'MOLA MEGDR Simple Cylindrical / Planetocéntrica (0°–360° E)',
      bodyCrs: 'IAU_2015:49900',
      verticalDatum: 'Areoide GMM3 (mgm1025)',
      referenceRadiusM: 3396000.0,
      processingPipeline: [
        'Separación explícita entre CRS nativo MOLA y BODY_CRS (IAU_2015:49900)',
        'Ventana exploratoria 54 × 54 px (~25 × 25 km) en 18.4° N, 77.6° E',
        'Aislamiento de DEM Completo, Solo Observaciones (counts > 0) y Conteos',
        'Conteo de cobertura: 1,110 observados (38.07%) vs 1,806 interpolados (61.93%)',
      ],
      verificationNotes: [
        'La ventana NO es un límite oficial del cráter Jezero.',
        'Pendiente conciliar 463 m nominal frente a 463.058 m/px.',
      ],
    };

    const earthCandidateProv = (
      regionId: string,
      productNote: string,
      extraNote: string,
    ): ProvenanceRecord => ({
      regionId,
      body: 'earth',
      sourceAgency: productNote.includes('ArcticDEM') ? 'Polar Geospatial Center / NSF-NGA' : 'NASA Earthdata / USGS',
      productIds: [productNote],
      originalFiles: 'Referencia satelital externa integrada al catálogo',
      processedArtifacts: ['Métricas de referencia integradas (SRTM / ArcticDEM)'],
      nativeCrs: 'EPSG:4326',
      bodyCrs: 'EPSG:4326',
      verticalDatum: 'EGM96 / WGS84',
      referenceRadiusM: 6378137.0,
      processingPipeline: [
        'Registro de coordenadas y ventana 25 × 25 km en manifest.yaml',
        'Integración de métricas de elevación, pendiente y rugosidad desde referencia satelital',
      ],
      verificationNotes: [
        extraNote,
        'Métricas tomadas de literatura técnica y conjuntos satelitales públicos (SRTM / ArcticDEM).',
      ],
    });

    this.provenanceByRegion['sajama_bolivia'] = earthCandidateProv(
      'sajama_bolivia',
      'SRTMGL1 / SRTMGL1N (~30 m)',
      'Región de altura y relieve volcánico en el Altiplano (Nevado Sajama, 6,542 m).',
    );
    this.provenanceByRegion['atacama_chile'] = earthCandidateProv(
      'atacama_chile',
      'SRTMGL1 / NASA ARADS (~30 m)',
      'Núcleo hiperárido de Yungay utilizado como análogo terrestre.',
    );
    this.provenanceByRegion['death_valley_usa'] = earthCandidateProv(
      'death_valley_usa',
      'SRTMGL1 / USGS Badwater (~30 m)',
      'Cuenca evaporítica de Badwater (-86 m) y abanicos aluviales circundantes.',
    );
    this.provenanceByRegion['haughton_crater_ca'] = earthCandidateProv(
      'haughton_crater_ca',
      'ArcticDEM (PGC; >60° N fuera de cobertura SRTM)',
      'Latitud 75.37° N excede el límite norte de SRTM (60° N); utiliza referencia ArcticDEM.',
    );

    const moonProv = (regionId: string): ProvenanceRecord => ({
      regionId,
      body: 'moon',
      sourceAgency: 'NASA Planetary Data System (PDS)',
      productIds: ['LRO-L-LOLA-4-GDR-V1.0'],
      originalFiles: 'Altimetría láser lunar LRO LOLA',
      processedArtifacts: ['Métricas de referencia NASA LRO LOLA integradas'],
      nativeCrs: 'Moon Simple Cylindrical / Planetocéntrica (0°–360° E)',
      bodyCrs: 'IAU_2015:30100',
      verticalDatum: 'Esfera de referencia lunar (LOLA)',
      referenceRadiusM: 1737400.0,
      processingPipeline: [
        'Registro de coordenadas planetocéntricas en manifest.yaml (IAU_2015:30100)',
        'Integración de parámetros altimétricos y pendientes de referencia NASA LRO LOLA',
      ],
      verificationNotes: [
        'Métricas provenientes de productos y literatura técnica NASA LRO LOLA.',
      ],
    });

    this.provenanceByRegion['shackleton_lola'] = moonProv('shackleton_lola');
    this.provenanceByRegion['tranquillitatis_lola'] = moonProv('tranquillitatis_lola');
  }

  public getDatasets(body?: CelestialBodyId): DatasetRecord[] {
    if (!body) return this.datasets;
    return this.datasets.filter((d) => d.body === body);
  }

  public getRegions(body?: CelestialBodyId): RegionRecord[] {
    if (!body) return this.regions;
    return this.regions.filter((r) => r.body === body);
  }

  public getRegion(regionId: string): RegionRecord | undefined {
    return this.regions.find((r) => r.id === regionId);
  }

  public getResults(regionId?: string): RegionResults[] {
    if (!regionId) return Object.values(this.resultsByRegion);
    const item = this.resultsByRegion[regionId];
    return item ? [item] : [];
  }

  public getResultByRegion(regionId: string): RegionResults | undefined {
    return this.resultsByRegion[regionId];
  }

  public getProvenance(regionId: string): ProvenanceRecord | undefined {
    return this.provenanceByRegion[regionId];
  }

  public getProjectTasks(): ProjectTaskItem[] {
    return [
      {
        id: 1,
        title: 'Inspección de ResultsStore, settings, limitations y schemas',
        status: 'implemented',
        detail: 'Módulos activos y servidos bajo /api/v1.',
      },
      {
        id: 2,
        title: 'Validación del cargador GeoJSON y transformaciones CRS',
        status: 'pending_raw_data',
        detail: 'Validación de manifest.yaml activa; cargador Python/GDAL en repositorio externo.',
      },
      {
        id: 3,
        title: 'Incorporar Jezero al catálogo de regiones y API',
        status: 'implemented',
        detail: 'jezero_25km disponible en /api/v1/regions y /api/v1/results/jezero_25km.',
      },
      {
        id: 4,
        title: 'Mantener separados BODY_CRS y CRS nativo del raster',
        status: 'implemented',
        detail: 'IAU_2015:49900 y CRS nativo MOLA almacenados por separado.',
      },
      {
        id: 5,
        title: 'Exponer fracción interpolada y cobertura observada MOLA',
        status: 'implemented',
        detail: '38.07% observado (1,110) vs 61.93% interpolado (1,806) expuesto en API y UI.',
      },
      {
        id: 6,
        title: 'Validar georreferenciación MOLA (463 m vs 463.058 m/px)',
        status: 'partial',
        detail: 'Discrepancia documentada; verificación directa requiere GeoTIFF local.',
      },
      {
        id: 7,
        title: 'Verificar metadatos y máscaras SRTM NUM',
        status: 'pending_raw_data',
        detail: 'Advertencia de 97.51% activa; archivos NUM no adjuntos en el entorno.',
      },
      {
        id: 8,
        title: 'Pruebas específicas para Marte y calidad de datos',
        status: 'partial',
        detail: 'Motor TS verificado; suite pytest reside en el repositorio Python.',
      },
      {
        id: 9,
        title: 'Conectar resultados reales del backend con el frontend',
        status: 'implemented',
        detail: 'Frontend conectado íntegramente a /api/v1.',
      },
      {
        id: 10,
        title: 'Visualización comparativa 3D y referencias lunares/terrestres',
        status: 'implemented',
        detail: 'Comparación dual 3D 4K, zoom cercano, ACI y referencias NASA SRTM / ArcticDEM / LOLA.',
      },
    ];
  }
}

export const resultsStore = new ResultsStore();
