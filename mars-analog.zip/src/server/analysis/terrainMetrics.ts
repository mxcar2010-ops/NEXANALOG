import type {
  AciRequest,
  AciResult,
  AciVariableBreakdown,
  RegionDatasetMetrics,
} from '../../shared/types.ts';
import { DEFAULT_ACI_PARAMETERS } from '../settings.ts';

/**
 * Riley Terrain Ruggedness Index (TRI) using 8-neighbor differences.
 * Strictly requires all 8 surrounding neighbors AND the center cell to be valid (finite, non-null).
 * Returns null if any cell in the 3x3 window is missing/NaN.
 */
export function computeRileyTriAtCell(
  grid: (number | null)[][],
  row: number,
  col: number,
): number | null {
  const rows = grid.length;
  const cols = grid[0]?.length ?? 0;
  if (row <= 0 || row >= rows - 1 || col <= 0 || col >= cols - 1) {
    return null;
  }

  const center = grid[row][col];
  if (center === null || !Number.isFinite(center)) {
    return null;
  }

  let sumSqDiff = 0;
  for (let dr = -1; dr <= 1; dr++) {
    for (let dc = -1; dc <= 1; dc++) {
      if (dr === 0 && dc === 0) continue;
      const neighbor = grid[row + dr][col + dc];
      if (neighbor === null || !Number.isFinite(neighbor)) {
        return null;
      }
      const diff = neighbor - center;
      sumSqDiff += diff * diff;
    }
  }

  return Math.sqrt(sumSqDiff);
}

/**
 * Horn's 3x3 slope gradient in degrees.
 * Requires all 8 neighbors to be valid to avoid edge artifacts.
 */
export function computeSlopeDegAtCell(
  grid: (number | null)[][],
  row: number,
  col: number,
  cellSizeX: number,
  cellSizeY: number,
): number | null {
  const rows = grid.length;
  const cols = grid[0]?.length ?? 0;
  if (row <= 0 || row >= rows - 1 || col <= 0 || col >= cols - 1) {
    return null;
  }

  const z = (r: number, c: number): number | null => {
    const v = grid[r][c];
    return v !== null && Number.isFinite(v) ? v : null;
  };

  const a = z(row - 1, col - 1);
  const b = z(row - 1, col);
  const c = z(row - 1, col + 1);
  const d = z(row, col - 1);
  const f = z(row, col + 1);
  const g = z(row + 1, col - 1);
  const h = z(row + 1, col);
  const i = z(row + 1, col + 1);

  if (
    a === null ||
    b === null ||
    c === null ||
    d === null ||
    f === null ||
    g === null ||
    h === null ||
    i === null
  ) {
    return null;
  }

  const dzdx = (c + 2 * f + i - (a + 2 * d + g)) / (8 * cellSizeX);
  const dzdy = (g + 2 * h + i - (a + 2 * b + c)) / (8 * cellSizeY);
  const slopeRad = Math.atan(Math.sqrt(dzdx * dzdx + dzdy * dzdy));
  return (slopeRad * 180) / Math.PI;
}

/**
 * Local relief (max - min elevation) within a square focal window of radius `radiusCells`.
 */
export function computeLocalReliefAtCell(
  grid: (number | null)[][],
  row: number,
  col: number,
  radiusCells = 1,
): number | null {
  const rows = grid.length;
  const cols = grid[0]?.length ?? 0;
  if (
    row < radiusCells ||
    row >= rows - radiusCells ||
    col < radiusCells ||
    col >= cols - radiusCells
  ) {
    return null;
  }

  let minVal = Infinity;
  let maxVal = -Infinity;
  for (let dr = -radiusCells; dr <= radiusCells; dr++) {
    for (let dc = -radiusCells; dc <= radiusCells; dc++) {
      const val = grid[row + dr][col + dc];
      if (val === null || !Number.isFinite(val)) {
        return null;
      }
      if (val < minVal) minVal = val;
      if (val > maxVal) maxVal = val;
    }
  }

  return maxVal - minVal;
}

/**
 * Computes the Analog Compatibility Index (ACI) between an Earth reference region
 * and a planetary target region using:
 *   S_j = exp(-|x_{j,Earth} - x_{j,Target}| / s_j)
 *   ACI = 100 * sum(w_j * S_j) / sum(w_j)
 *
 * Missing variables are excluded and weights are renormalized across available variables.
 * Missing values are NEVER substituted with zero.
 */
export function computeAnalogCompatibilityIndex(
  earthMetrics: RegionDatasetMetrics,
  targetMetrics: RegionDatasetMetrics,
  request: AciRequest,
): AciResult {
  const weights = {
    slope: Math.max(0, request.weights?.slope ?? DEFAULT_ACI_PARAMETERS.weights.slope),
    tri: Math.max(0, request.weights?.tri ?? DEFAULT_ACI_PARAMETERS.weights.tri),
    localRelief: Math.max(
      0,
      request.weights?.localRelief ?? DEFAULT_ACI_PARAMETERS.weights.localRelief,
    ),
  };

  const scales = {
    slope: Math.max(0.01, request.scales?.slope ?? DEFAULT_ACI_PARAMETERS.scales.slope),
    tri: Math.max(0.01, request.scales?.tri ?? DEFAULT_ACI_PARAMETERS.scales.tri),
    localRelief: Math.max(
      0.01,
      request.scales?.localRelief ?? DEFAULT_ACI_PARAMETERS.scales.localRelief,
    ),
  };

  const rawVariables: Array<{
    key: 'slope' | 'tri' | 'localRelief';
    label: string;
    unit: string;
    earthVal: number | null;
    targetVal: number | null;
    earthAvail: boolean;
    targetAvail: boolean;
    nominalW: number;
    scale: number;
    missingNote: string;
  }> = [
    {
      key: 'slope',
      label: 'Pendiente media',
      unit: '°',
      earthVal: earthMetrics.slope.mean,
      targetVal: targetMetrics.slope.mean,
      earthAvail: earthMetrics.slope.available,
      targetAvail: targetMetrics.slope.available,
      nominalW: weights.slope,
      scale: scales.slope,
      missingNote: 'Pendiente no disponible en uno o ambos conjuntos.',
    },
    {
      key: 'tri',
      label: 'Rugosidad (TRI Riley)',
      unit: 'm',
      earthVal: earthMetrics.tri.mean,
      targetVal: targetMetrics.tri.mean,
      earthAvail: earthMetrics.tri.available,
      targetAvail: targetMetrics.tri.available,
      nominalW: weights.tri,
      scale: scales.tri,
      missingNote: 'TRI no disponible en uno o ambos conjuntos.',
    },
    {
      key: 'localRelief',
      label: 'Relieve local',
      unit: 'm',
      earthVal: earthMetrics.localRelief.mean,
      targetVal: targetMetrics.localRelief.mean,
      earthAvail: earthMetrics.localRelief.available,
      targetAvail: targetMetrics.localRelief.available,
      nominalW: weights.localRelief,
      scale: scales.localRelief,
      missingNote:
        'Relieve local ausente en el resumen exportado; excluido sin sustituir por cero.',
    },
  ];

  const nominalWeightSum = rawVariables.reduce((acc, v) => acc + v.nominalW, 0);

  const activeVariables = rawVariables.filter(
    (v) =>
      v.earthAvail &&
      v.targetAvail &&
      v.earthVal !== null &&
      v.targetVal !== null &&
      v.nominalW > 0,
  );

  const activeWeightSum = activeVariables.reduce((acc, v) => acc + v.nominalW, 0);
  const renormalized =
    activeVariables.length > 0 &&
    Math.abs(activeWeightSum - nominalWeightSum) > 1e-6;

  let weightedSimilaritySum = 0;

  const breakdown: AciVariableBreakdown[] = rawVariables.map((v) => {
    const isAvailable =
      v.earthAvail && v.targetAvail && v.earthVal !== null && v.targetVal !== null;

    if (!isAvailable || v.earthVal === null || v.targetVal === null) {
      return {
        variable: v.key,
        label: v.label,
        unit: v.unit,
        available: false,
        earthValue: v.earthVal,
        targetValue: v.targetVal,
        absoluteDifference: null,
        scaleSj: v.scale,
        similaritySj: null,
        nominalWeight: v.nominalW,
        appliedWeight: 0,
        weightedContribution: null,
        note: v.missingNote,
      };
    }

    const diff = Math.abs(v.earthVal - v.targetVal);
    const similarity = Math.exp(-diff / v.scale);
    const appliedWeight = activeWeightSum > 0 ? v.nominalW / activeWeightSum : 0;
    const contribution = 100 * appliedWeight * similarity;

    weightedSimilaritySum += appliedWeight * similarity;

    return {
      variable: v.key,
      label: v.label,
      unit: v.unit,
      available: true,
      earthValue: v.earthVal,
      targetValue: v.targetVal,
      absoluteDifference: Number(diff.toFixed(6)),
      scaleSj: v.scale,
      similaritySj: Number(similarity.toFixed(6)),
      nominalWeight: v.nominalW,
      appliedWeight: Number(appliedWeight.toFixed(6)),
      weightedContribution: Number(contribution.toFixed(4)),
      note: `S = exp(-|${v.earthVal.toFixed(4)} - ${v.targetVal.toFixed(4)}| / ${v.scale}) = ${similarity.toFixed(4)}`,
    };
  });

  const finalScore =
    activeWeightSum > 0 ? Number((100 * weightedSimilaritySum).toFixed(2)) : null;

  const explanation: string[] = [
    'Índice experimental morfométrico (no es un índice oficial de NASA).',
    `Variables comparadas: ${activeVariables.length} de ${rawVariables.length}.`,
  ];

  if (renormalized) {
    explanation.push(
      `Variables faltantes excluidas sin cero; pesos activos renormalizados de ${activeWeightSum.toFixed(2)} a 1.00.`,
    );
  }

  if (targetMetrics.includesInterpolation) {
    explanation.push(
      `Advertencia: el destino incluye ${targetMetrics.coverage.interpolatedOrEmptyPercent?.toFixed(2) ?? 'una fracción'}% de bins interpolados o vacíos.`,
    );
  }

  const limitationsApplied = [
    `Disparidad de escala: Tierra ${earthMetrics.pixelScaleM} m/px vs Objetivo ${targetMetrics.pixelScaleM > 0 ? `${targetMetrics.pixelScaleM} m/px` : 'Pendiente LOLA'}.`,
    'Alcance exclusivamente topográfico: no evalúa geología, habitabilidad ni seguridad de aterrizaje.',
  ];

  if (targetMetrics.datasetRole === 'observed_only_dem') {
    limitationsApplied.push(
      'Subconjunto Solo Observaciones: pendiente de ejecución directa sobre GeoTIFF.',
    );
  }

  return {
    earthRegionId: request.earthRegionId,
    targetRegionId: request.targetRegionId,
    targetDatasetRole: targetMetrics.datasetRole,
    score: finalScore,
    isExperimental: true,
    renormalized,
    activeWeightSum: Number(activeWeightSum.toFixed(4)),
    nominalWeightSum: Number(nominalWeightSum.toFixed(4)),
    breakdown,
    explanation,
    limitationsApplied,
  };
}
