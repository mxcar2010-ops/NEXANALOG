import type { LimitationItem } from '../shared/types.ts';

export const SCIENTIFIC_LIMITATIONS: LimitationItem[] = [
  {
    id: 'topographic_scope_only',
    category: 'Alcance',
    severity: 'critical',
    title: 'Solo similitud topográfica (no habitabilidad ni aterrizaje)',
    description:
      'NEXANALOG evalúa únicamente morfometría superficial. Un ACI alto no implica equivalencia geológica, habitabilidad, seguridad de aterrizaje ni viabilidad para bases humanas.',
    affectedBodies: ['earth', 'mars', 'moon'],
  },
  {
    id: 'spatial_scale_mismatch',
    category: 'Resolución',
    severity: 'critical',
    title: 'Diferencia de escala 15.5× entre SRTM (30 m) y MOLA (463 m)',
    description:
      'Uyuni (29.8625 m/px) captura micro-relieve que los bins de Jezero (463.058 m/px) suavizan. Pendiente, TRI y relieve dependen directamente de la escala.',
    affectedBodies: ['earth', 'mars'],
  },
  {
    id: 'mola_interpolation_fraction',
    category: 'Cobertura MOLA',
    severity: 'critical',
    title: '61.93% de Jezero son bins interpolados o sin observaciones',
    description:
      'De 2,916 celdas (54×54), solo 1,110 (38.07%) tienen mediciones directas (counts > 0) y 1,806 (61.93%) son interpoladas. No deben mezclarse ambos conjuntos.',
    affectedBodies: ['mars'],
  },
  {
    id: 'srtm_valid_cells_vs_num',
    category: 'Cobertura SRTM',
    severity: 'warning',
    title: '97.51% de celdas válidas en Uyuni no garantiza 100% mediciones originales',
    description:
      'Las 700,613 celdas válidas indican ausencia de nodata en el raster procesado; la verificación de relleno SRTMGL1N requiere auditar las máscaras NUM.',
    affectedBodies: ['earth'],
  },
  {
    id: 'vertical_datum_and_crs',
    category: 'Geodesia',
    severity: 'warning',
    title: 'CRS y referencias verticales distintas por cuerpo',
    description:
      'Tierra usa EPSG:4326 (EGM96/WGS84); Marte usa IAU_2015:49900 (0°–360° E, radio 3,396 km, areoide GMM3 mgm1025); Luna usa IAU_2015:30100. El CRS nativo se conserva separado.',
    affectedBodies: ['earth', 'mars', 'moon'],
  },
  {
    id: 'exploratory_window_boundaries',
    category: 'Áreas de estudio',
    severity: 'warning',
    title: 'Ventanas exploratorias de 25 × 25 km (no límites oficiales)',
    description:
      'Los rectángulos de Uyuni y Jezero son muestras exploratorias y no delimitan perímetros geológicos oficiales.',
    affectedBodies: ['earth', 'mars'],
  },
  {
    id: 'georeferencing_and_lola_pending',
    category: 'Pendientes técnicos',
    severity: 'info',
    title: 'Validación MOLA (463 vs 463.058 m) y GeoTIFF locales pendientes',
    description:
      'Queda pendiente validar 463 vs 463.058 m/px, exportar Local Relief de Uyuni/Jezero y procesar GeoTIFF locales para Sajama, Atacama, Death Valley, Haughton y Luna LOLA (actualmente con métricas satelitales de referencia).',
    affectedBodies: ['earth', 'mars', 'moon'],
  },
];
