import path from 'node:path';
import type { BodyConfig, CelestialBodyId } from '../shared/types.ts';

export const API_PREFIX = '/api/v1';

export const MANIFEST_PATH = path.resolve(process.cwd(), 'data', 'manifest.yaml');

export const BODY_CRS_CONFIG: Record<CelestialBodyId, BodyConfig> = {
  earth: {
    id: 'earth',
    label: 'TIERRA',
    bodyCrs: 'EPSG:4326',
    referenceRadiusM: 6378137.0,
    verticalDatum: 'EGM96 / WGS84',
    longitudeConvention: '-180° a +180° E',
    integrationStatus: 'active',
  },
  mars: {
    id: 'mars',
    label: 'MARTE',
    bodyCrs: 'IAU_2015:49900',
    referenceRadiusM: 3396000.0,
    verticalDatum: 'Areoide GMM3 (mgm1025)',
    longitudeConvention: '0° a 360° E (Planetocéntrica)',
    integrationStatus: 'active',
  },
  moon: {
    id: 'moon',
    label: 'LUNA',
    bodyCrs: 'IAU_2015:30100',
    referenceRadiusM: 1737400.0,
    verticalDatum: 'Esfera de referencia lunar (LOLA)',
    longitudeConvention: '0° a 360° E (Planetocéntrica)',
    integrationStatus: 'staged',
    plannedSource: 'NASA PDS LOLA (Lunar Orbiter Laser Altimeter)',
  },
};

export const DEFAULT_ACI_PARAMETERS = {
  weights: {
    slope: 0.4,
    tri: 0.35,
    localRelief: 0.25,
  },
  scales: {
    slope: 10.0,
    tri: 5.0,
    localRelief: 20.0,
  },
};
