export type CelestialBodyId = 'earth' | 'mars' | 'moon';

export interface BodyConfig {
  id: CelestialBodyId;
  label: string;
  bodyCrs: string;
  referenceRadiusM: number;
  verticalDatum: string;
  longitudeConvention: string;
  integrationStatus: 'active' | 'staged';
  plannedSource?: string;
}

export interface DatasetRecord {
  id: string;
  body: CelestialBodyId;
  regionId: string | null;
  title: string;
  sourceAgency: string;
  productId: string;
  productVersion?: string;
  datasetRole: 'primary_dem' | 'full_dem' | 'observed_only_dem' | 'observation_counts' | 'staged_future_extension';
  nativeCrs: string;
  bodyCrs: string;
  nominalResolutionM: number | null;
  pixelScaleM: number | null;
  georeferencingNote?: string;
  originalFormat: string;
  processedPath: string | null;
  maskVerificationStatus?: string;
  includesInterpolation: boolean;
}

export interface RegionRecord {
  id: string;
  name: string;
  body: CelestialBodyId;
  regionType: string;
  status?: 'active' | 'staged_srtm' | 'staged_lola';
  windowKm: [number, number];
  gridCells?: [number, number];
  centerLat: number;
  centerLon: number;
  bodyCrs: string;
  description: string;
  reason?: string;
  boundaryDisclaimer: string;
}

export interface MetricSummary {
  available: boolean;
  unit: string;
  mean: number | null;
  median: number | null;
  std: number | null;
  min: number | null;
  max: number | null;
  percentiles?: Record<string, number> | null;
  validCells: number | null;
  note: string;
}

export interface CoverageSummary {
  totalCells: number | null;
  validCells: number | null;
  validPercent: number | null;
  observedCells: number | null;
  observedPercent: number | null;
  interpolatedOrEmptyCells: number | null;
  interpolatedOrEmptyPercent: number | null;
  coverageDisclaimer: string;
}

export interface RegionDatasetMetrics {
  datasetId: string;
  datasetRole: 'primary_dem' | 'full_dem' | 'observed_only_dem' | 'observation_counts';
  title: string;
  includesInterpolation: boolean;
  pixelScaleM: number;
  coverage: CoverageSummary;
  elevation: MetricSummary;
  slope: MetricSummary;
  tri: MetricSummary;
  localRelief: MetricSummary;
  dataAvailabilityNote: string;
}

export interface RegionResults {
  regionId: string;
  regionName: string;
  body: CelestialBodyId;
  bodyCrs: string;
  nativeCrs: string;
  verticalDatum: string;
  primaryDatasetId: string;
  datasets: RegionDatasetMetrics[];
}

export interface ProvenanceRecord {
  regionId: string;
  body: CelestialBodyId;
  sourceAgency: string;
  productIds: string[];
  originalFiles: string;
  processedArtifacts: string[];
  nativeCrs: string;
  bodyCrs: string;
  verticalDatum: string;
  referenceRadiusM: number;
  processingPipeline: string[];
  verificationNotes: string[];
}

export interface LimitationItem {
  id: string;
  category: string;
  severity: 'critical' | 'warning' | 'info';
  title: string;
  description: string;
  affectedBodies: CelestialBodyId[];
}

export interface AciVariableConfig {
  weight: number;
  scale: number;
}

export interface AciRequest {
  earthRegionId: string;
  targetRegionId: string;
  targetDatasetRole?: 'full_dem' | 'observed_only_dem';
  weights?: {
    slope?: number;
    tri?: number;
    localRelief?: number;
  };
  scales?: {
    slope?: number;
    tri?: number;
    localRelief?: number;
  };
}

export interface AciVariableBreakdown {
  variable: 'slope' | 'tri' | 'localRelief';
  label: string;
  unit: string;
  available: boolean;
  earthValue: number | null;
  targetValue: number | null;
  absoluteDifference: number | null;
  scaleSj: number;
  similaritySj: number | null;
  nominalWeight: number;
  appliedWeight: number;
  weightedContribution: number | null;
  note: string;
}

export interface AciResult {
  earthRegionId: string;
  targetRegionId: string;
  targetDatasetRole: string;
  score: number | null;
  isExperimental: true;
  renormalized: boolean;
  activeWeightSum: number;
  nominalWeightSum: number;
  breakdown: AciVariableBreakdown[];
  explanation: string[];
  limitationsApplied: string[];
}

export interface ProjectTaskItem {
  id: number;
  title: string;
  status: 'implemented' | 'partial' | 'pending_raw_data' | 'future_extension';
  detail: string;
}

export interface HealthResponse {
  status: 'ok';
  service: string;
  apiPrefix: string;
  manifestLoaded: boolean;
  manifestSchemaVersion: string;
  activeBodies: CelestialBodyId[];
  stagedBodies: CelestialBodyId[];
  registeredRegions: number;
  registeredDatasets: number;
  rawGeoTiffMounted: boolean;
  timestamp: string;
}

export interface CrossPlanetComparisonItem {
  otherRegionId: string;
  otherRegionName: string;
  otherBody: CelestialBodyId;
  aciScore: number | null;
  elevationMeanM: number | null;
  slopeMeanDeg: number | null;
  triMeanM: number | null;
  localReliefMeanM: number | null;
  pixelScaleM: number;
}

export interface RegionCrossComparisonResponse {
  regionId: string;
  regionName: string;
  body: CelestialBodyId;
  comparisons: CrossPlanetComparisonItem[];
}

