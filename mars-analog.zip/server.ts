import express from 'express';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';
import type { AciRequest, CelestialBodyId, HealthResponse } from './src/shared/types.ts';
import { computeAnalogCompatibilityIndex } from './src/server/analysis/terrainMetrics.ts';
import { SCIENTIFIC_LIMITATIONS } from './src/server/limitations.ts';
import { resultsStore } from './src/server/resultsStore.ts';
import { API_PREFIX, BODY_CRS_CONFIG } from './src/server/settings.ts';

const PORT = Number(process.env.PORT || 3000);

async function startServer() {
  const app = express();
  app.use(express.json());

  // ==========================================
  // NEXANALOG Versioned API (/api/v1)
  // ==========================================
  const api = express.Router();

  api.get('/health', (_req, res) => {
    const payload: HealthResponse = {
      status: 'ok',
      service: 'NEXANALOG Geospatial & Topographic API',
      apiPrefix: API_PREFIX,
      manifestLoaded: resultsStore.manifestLoaded,
      manifestSchemaVersion: resultsStore.manifestSchemaVersion,
      activeBodies: ['earth', 'mars'],
      stagedBodies: ['moon'],
      registeredRegions: resultsStore.regions.length,
      registeredDatasets: resultsStore.datasets.length,
      rawGeoTiffMounted: resultsStore.rawGeoTiffMounted,
      timestamp: new Date().toISOString(),
    };
    res.json(payload);
  });

  api.get('/bodies', (_req, res) => {
    res.json({
      bodies: Object.values(BODY_CRS_CONFIG),
    });
  });

  api.get('/limitations', (req, res) => {
    const bodyFilter = req.query.body as CelestialBodyId | undefined;
    const items = bodyFilter
      ? SCIENTIFIC_LIMITATIONS.filter((l) => l.affectedBodies.includes(bodyFilter))
      : SCIENTIFIC_LIMITATIONS;
    res.json({
      scope: 'topographic_comparison_only',
      count: items.length,
      limitations: items,
    });
  });

  api.get('/datasets', (req, res) => {
    const body = req.query.body as CelestialBodyId | undefined;
    const datasets = resultsStore.getDatasets(body);
    res.json({
      count: datasets.length,
      datasets,
    });
  });

  api.get('/regions', (req, res) => {
    const body = req.query.body as CelestialBodyId | undefined;
    const regions = resultsStore.getRegions(body);
    res.json({
      count: regions.length,
      regions,
    });
  });

  api.get('/regions/:regionId', (req, res) => {
    const region = resultsStore.getRegion(req.params.regionId);
    if (!region) {
      res.status(404).json({ error: `Region '${req.params.regionId}' not found in manifest.` });
      return;
    }
    res.json(region);
  });

  api.get('/regions/:regionId/comparisons', (req, res) => {
    const baseRegion = resultsStore.getRegion(req.params.regionId);
    const baseResult = resultsStore.getResultByRegion(req.params.regionId);
    if (!baseRegion || !baseResult || !baseResult.datasets[0]) {
      res.status(404).json({ error: `Region '${req.params.regionId}' not found.` });
      return;
    }

    const baseDataset = baseResult.datasets[0];
    const otherRegions = resultsStore.regions.filter((r) => r.body !== baseRegion.body);

    const comparisons = otherRegions
      .map((other) => {
        const otherResult = resultsStore.getResultByRegion(other.id);
        const otherDataset = otherResult?.datasets[0];
        if (!otherResult || !otherDataset) return null;

        const isBaseEarth = baseRegion.body === 'earth';
        const earthDs = isBaseEarth ? baseDataset : otherDataset;
        const targetDs = isBaseEarth ? otherDataset : baseDataset;

        const aci = computeAnalogCompatibilityIndex(earthDs, targetDs, {
          earthRegionId: isBaseEarth ? baseRegion.id : other.id,
          targetRegionId: isBaseEarth ? other.id : baseRegion.id,
          targetDatasetRole: 'full_dem',
        });

        return {
          otherRegionId: other.id,
          otherRegionName: other.name,
          otherBody: other.body,
          aciScore: aci.score,
          elevationMeanM: otherDataset.elevation.mean,
          slopeMeanDeg: otherDataset.slope.mean,
          triMeanM: otherDataset.tri.mean,
          localReliefMeanM: otherDataset.localRelief.mean,
          pixelScaleM: otherDataset.pixelScaleM,
        };
      })
      .filter((item): item is NonNullable<typeof item> => item !== null)
      .sort((a, b) => (b.aciScore ?? -1) - (a.aciScore ?? -1));

    res.json({
      regionId: baseRegion.id,
      regionName: baseRegion.name,
      body: baseRegion.body,
      comparisons,
    });
  });

  api.get('/results', (_req, res) => {
    const results = resultsStore.getResults();
    res.json({
      count: results.length,
      results,
    });
  });

  api.get('/results/:regionId', (req, res) => {
    const result = resultsStore.getResultByRegion(req.params.regionId);
    if (!result) {
      res.status(404).json({ error: `Results for region '${req.params.regionId}' not found.` });
      return;
    }
    res.json(result);
  });

  api.get('/provenance/:regionId', (req, res) => {
    const provenance = resultsStore.getProvenance(req.params.regionId);
    if (!provenance) {
      res.status(404).json({ error: `Provenance for region '${req.params.regionId}' not found.` });
      return;
    }
    res.json(provenance);
  });

  api.post('/aci/compare', (req, res) => {
    const body = req.body as Partial<AciRequest>;
    const earthRegionId = body.earthRegionId || 'uyuni_25km';
    const targetRegionId = body.targetRegionId || 'jezero_25km';
    const targetDatasetRole = body.targetDatasetRole || 'full_dem';

    const earthResult = resultsStore.getResultByRegion(earthRegionId);
    const targetResult = resultsStore.getResultByRegion(targetRegionId);

    if (!earthResult || earthResult.body !== 'earth') {
      res.status(404).json({ error: `Earth reference region '${earthRegionId}' not found.` });
      return;
    }

    if (!targetResult) {
      res.status(404).json({ error: `Target region '${targetRegionId}' not found.` });
      return;
    }

    const earthDataset = earthResult.datasets[0];
    const targetDataset =
      targetResult.datasets.find((d) => d.datasetRole === targetDatasetRole) ||
      targetResult.datasets[0];

    if (!earthDataset || !targetDataset) {
      res.status(400).json({ error: 'Selected regions lack compatible dataset metrics.' });
      return;
    }

    const aci = computeAnalogCompatibilityIndex(earthDataset, targetDataset, {
      earthRegionId,
      targetRegionId,
      targetDatasetRole,
      weights: body.weights,
      scales: body.scales,
    });

    res.json(aci);
  });

  api.get('/project-status', (_req, res) => {
    res.json({
      tasks: resultsStore.getProjectTasks(),
      rawGeoTiffMounted: resultsStore.rawGeoTiffMounted,
    });
  });

  app.use(API_PREFIX, api);

  // Vite middleware for development or static serving for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`NEXANALOG server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
